// This script is loaded both on the frontend page and in the Visual Builder.

jQuery(function($) {});
