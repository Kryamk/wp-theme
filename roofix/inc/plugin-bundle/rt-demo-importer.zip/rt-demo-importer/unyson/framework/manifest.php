<?php if (!defined('FW')) die('Forbidden');

$manifest = array();

$manifest['name'] = __('Unyson', 'fw');

$manifest['version'] = '2.7.22';
