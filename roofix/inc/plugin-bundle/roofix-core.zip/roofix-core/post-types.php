<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use radiustheme\Roofix\RDTheme;
use \RT_Posts;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Posts' ) ) {
	return;
}

$prefix = ROOFIX_CORE_CPT;
$roofix_post_types = array(
"{$prefix}_team"        => array(
	'title'        => esc_html__( RDTheme::$options['team_admin_menu_title'], 'roofix-core' ),
	'plural_title' => esc_html__( RDTheme::$options['team_admin_menu_title'], 'roofix-core' ),
	'menu_icon'    => 'dashicons-businessman',
	'rewrite'      => RDTheme::$options['team_slug'],
'supports'     => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
	),
	"{$prefix}_projects"        => array(
		'title'        => esc_html__( RDTheme::$options['projects_admin_menu_title'], 'roofix-core' ),
		'plural_title' => esc_html__( RDTheme::$options['projects_admin_menu_title'], 'roofix-core' ),
		'menu_icon'    => 'dashicons-clipboard',
		'supports'     => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' ),
		'rewrite'      => RDTheme::$options['projects_slug'],
		),				
		"{$prefix}_services"   => array(
			'title'           => esc_html__( RDTheme::$options['services_admin_menu_title'], 'roofix-core' ),
			'plural_title'    => esc_html__( RDTheme::$options['services_admin_menu_title'], 'roofix-core' ),
			'menu_icon'       => 'dashicons-sos',
			'rewrite'         => RDTheme::$options['services_slug'],
			'supports'        => array( 'title', 'thumbnail', 'editor','excerpt', 'page-attributes' )
		),
	);
	$roofix_taxonomies = array(
		"{$prefix}_team_category" => array(
			'title'        => esc_html__( RDTheme::$options['team_admin_menu_title'] . ' Category', 'roofix-core' ),
			'plural_title' => esc_html__( 'Categories', 'roofix-core' ),
			'post_types'   => "{$prefix}_team",
			'rewrite'      => array( 'slug' => RDTheme::$options['team_cat_slug'] ),
			),			
		"{$prefix}_projects_category" => array(
			'title'        => esc_html__( RDTheme::$options['projects_admin_menu_title'] . ' Category', 'roofix-core' ),
			'plural_title' => esc_html__( 'Category', 'roofix-core' ),
			'post_types'   => "{$prefix}_projects",
			'rewrite'      => array( 'slug' => RDTheme::$options['projects_cat_slug'] ),
			),

			"{$prefix}_services_category" => array(
				'title'        => esc_html__( RDTheme::$options['services_admin_menu_title'] . ' Category', 'roofix-core' ),
				'plural_title' => esc_html__( 'Categories', 'roofix-core' ),
				'post_types'   => "{$prefix}_services",
				'rewrite'      => array( 'slug' => RDTheme::$options['services_cat_slug'] ),
			),
			
		);

$roofix_Posts = RT_Posts::getInstance();
$roofix_Posts->add_post_types( $roofix_post_types );
$roofix_Posts->add_taxonomies( $roofix_taxonomies );