<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Plugin;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Custom_Widget_Init
{
    public $version;

    public function __construct()
    {
        $this->version = "1.0";
        add_action('elementor/widgets/widgets_registered', array($this, 'init'));
        add_action('elementor/elements/categories_registered', array($this, 'widget_categoty'));

        add_action('elementor/editor/after_enqueue_styles', array($this, 'after_enqueue_styles_elementor_editor'), 10, 1);
        add_filter('elementor/utils/get_placeholder_image_src', array($this, 'set_placeholder_image'));
        add_filter('elementor/icons_manager/additional_tabs', [$this, 'roofix_additional_tabs'], 10, 1);
        add_action('elementor/editor/after_enqueue_styles', array($this, 'editor_style'));

    }


    public function editor_style()
    {
        $img = plugins_url('icon.png', __FILE__);
        wp_add_inline_style('elementor-editor', '.elementor-element .icon .rdtheme-el-custom{content: url(' . $img . ');width: 28px;}');
        wp_add_inline_style('elementor-editor', '.select2-container--default .select2-selection--single {min-width: 126px !important; min-height: 30px !important;}');
    }


    // Placeholder image replacement
    public function set_placeholder_image()
    {
        return ROOFIX_CORE_ASSETS . 'imgs/placeholder.png';
    }

    public function init()
    {
        require_once __DIR__ . '/base.php';
        // Widgets -- filename=>classname /@dev
        $widgets = array(
            'services-content'  => 'rt_service_contant',
            'rt-tab'            => 'RT_Service_Tab',            
            'rt-slider'         => 'Rt_Slider',
            'title'             => 'Title',
            'button'            => 'Button',
            'typed'             => 'Typed',
            'paragraph-title'   => 'Paragraph_Title',
            'text-with-title'   => 'Text_With_Title',
            'video-with-title'  => 'Video_With_Title',
            'image-box'         => 'Image_Box',
            'info-box'          => 'Info_Box',
            'icon-box'          => 'Icon_Box',
            'icon-list'         => 'Icon_List',
            'services-info-box' => 'services_info_box',
            'services-tab'      => 'Services_Tab',
            'banner-tab'      	=> 'Services_Banner_Tab',
            'services-grid'     => 'Services_Grid',
            'services-slider'   => 'Services_Slider',
            'process-box'       => 'Process_Box',
            'testimonial'       => 'Testimonials',
            'counter'           => 'Counter',
            'cta'               => 'CTA',
            'projects-isotope'  => 'Projects_Isotope',
            'projects-grid'     => 'Projects_Grid',
            'projects-slider'   => 'Projects_Slider',
            'blog-post'         => 'Blog_post',
            'logo-slider'       => 'Logo_Slider',
            'team-members'      => 'Team_Members',
            'zoom-gallery'      => 'Zoom_Gallery',
            'contact'           => 'Contact',
			'rt-banner-tab'     => 'RT_Banner_Tab',
			'price-plan'     	=> 'Price_Plan',


        );
        foreach ($widgets as $widget => $class) {
            $template_name = "/elementor-custom/widgets/{$widget}.php";
            if (file_exists(STYLESHEETPATH . $template_name)) {
                $file = STYLESHEETPATH . $template_name;
            } elseif (file_exists(TEMPLATEPATH . $template_name)) {
                $file = TEMPLATEPATH . $template_name;
            } else {
                $file = __DIR__ . '/widgets/' . $widget . '.php';
            }

            require_once $file;

            $classname = __NAMESPACE__ . '\\' . $class;
            Plugin::instance()->widgets_manager->register_widget_type(new $classname);
        }
    }

    public function widget_categoty($class)
    {
        $id = ROOFIX_CORE_THEME . '-widgets'; // Category /@dev
        $properties = array(
            'title' => esc_html__('RadiusTheme Elements', 'roofix-core'),
        );

        Plugin::$instance->elements_manager->add_category($id, $properties);
    }

    public function after_enqueue_styles_elementor_editor()
    {

        wp_enqueue_style('flaticon-elm', Helper::get_font_css('flaticon'));
        wp_enqueue_style('flaticon-fix-elm', Helper::get_font_css('font-fix/flaticon'));
        wp_enqueue_style('main-admin-style', Helper::get_css('style.admin'));
    }


    public function roofix_additional_tabs($tabs)
    {

        $json_url3 = Helper::get_asset_file('flaticon-json/roofix-flaticon.js');

        $flaticon3 = [
            'name'          => 'roofix-flaticon',
            'label'         => esc_html__('Roofix Icons', 'roofix-core'),
            'url'           => false,
            'enqueue'       => false,
            'prefix'        => '',
            'displayPrefix' => '',
            'labelIcon'     => 'fab fa-font-awesome-alt',
            'ver'           => '1.0.0',
            'fetchJson'     => $json_url3,
        ];
        array_push($tabs, $flaticon3);
        return $tabs;
    }


}

new Custom_Widget_Init();