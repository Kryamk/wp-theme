<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
$btn = $attr = '';
if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="btn-fill-xl btn-mouse box-shadow bg-textprimary text-accent mouse-dir pull-right" ' . $attr . '>' . $data['buttontext'] . '<i class="fas fa-angle-right"></i><span class="dir-part"></span></a>';
}
extract( $data );
?>
	<div class="row align-items-center">
	    <div class="col-lg-9 col-12">
	        <div class="action-box-layout1">
				<?php if ( $title ): ?>  
					<h2 class="roofix-animation-txt item-title rt-name"> <?php echo wp_kses_post( $title);?> </h2>
				<?php endif; ?>	 
	        </div>
	    </div>
	    <div class="col-lg-3 col-12 d-flex justify-content-lg-end justify-content-center">
	        <div class="action-box-layout1">
	        	<?php if ( $btn ): ?>
					<?php echo wp_kses_post( $btn );?>		
				<?php endif; ?>	          
	        </div>
	    </div>
	</div>