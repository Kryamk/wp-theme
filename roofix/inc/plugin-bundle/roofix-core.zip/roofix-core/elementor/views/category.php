<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
	namespace radiustheme\Roofix_Core;
	$catsArray = $data['cat_single_tab'];
	$series = get_terms( array(
	        'taxonomy' => 'category',
	        'include' => $catsArray,
	        'hide_empty'  => true, 
	      ) );
	foreach($series as $serie){
	/*check for category having parent or not except category id=1 which is wordpress default category (Uncategorized)*/
	if($serie->term_id != 1){
	echo '<h2 class="link"><a href="'.get_category_link($serie->term_id ).'">'.$serie->name.'</a></h2>';
	break;
	}
	}

?>

