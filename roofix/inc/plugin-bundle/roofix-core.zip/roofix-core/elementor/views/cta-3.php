<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$btn = $attr = '';
extract( $data );
if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="item-btn" ' . $attr . '>' . $data['buttontext'] . '</a>';
}
$size = 'full';
?>
<div class="action-warp-layout1">        
    <div class="row align-items-center">
        <div class="col-xl-9 col-lg-8 col-md-12">
            <div class="action-box-layout1">
                <div class="media">
                    <div class="item-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <div class="media-body">
                        <?php if ( $title ): ?>
                            <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
                        <?php endif; ?> 
                        <?php if ( $subtitle ): ?>
                            <p class="item-sub-title"><?php echo wp_kses_post( $subtitle);?></p>
                        <?php endif; ?> 
                    </div>
                </div>
            </div>
        </div>
         <?php if ( $btn ): ?> 
            <div class="col-xl-3 col-lg-4 col-md-12 mob-tab-center">
                <div class="action-box-layout1 btn-right-clip">
                     <?php echo wp_kses_post( $btn );?>      
                </div>
            </div>
        <?php endif; ?>  
    </div>     
</div>