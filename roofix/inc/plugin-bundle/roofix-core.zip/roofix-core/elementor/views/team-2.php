<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;

$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;
$thumb_size  = "roofix-size-team2";
$args = array(
	'post_type'      => "{$cpt}_team",
	'posts_per_page' => $data['number'],
	'orderby'        => $data['orderby'],
);
if ( !empty( $data['cat'] ) ) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => "{$cpt}_team_category",
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>

<div class="team-wrap-layout1 bg-shape-1 row no-equal-gallery">
	<?php if ( $query->have_posts() ) :?>
		<?php while ( $query->have_posts() ) : $query->the_post();?>
			<?php
					$id            				= get_the_id();				
					$_designation   			= get_post_meta( $id, "{$cpt}_designation", true );
					$content 						 	= Helper::get_current_post_content();				
					$socials       				= get_post_meta( $id, "{$cpt}_team_social", true );
					$social_fields 				= Helper::team_socials();
				?>
				<div class="rtin-item no-equal-item <?php echo esc_attr( $col_class );?>">
					<div class="team-box-layout4">
					<?php
					if ( has_post_thumbnail() ){ ?>									    
						<div class="item-img">                           
							<?php the_post_thumbnail( $thumb_size ); ?>	 
							                           
						</div>
					<?php } ?>
					<div class="item-content">
						<div class="item-heading">
							<h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>		
							<?php if ( !empty( $data['designation_display'] ) ): ?>
								<div class="item-subtitle"><?php echo esc_html($_designation); ?></div>
							<?php endif; ?>
						</div>				            
						<?php if ( !empty( $data['item_social'] ) ): ?>
						<ul class="item-social">
							<?php foreach ( $socials as $key => $social ): ?>
								<?php if ( !empty( $social ) ): ?>
									<li><a target="_blank" href="<?php echo esc_url( $social );?>"><i class="fab <?php echo esc_attr( $social_fields[$key]['icon'] );?>" aria-hidden="true"></i></a></li>
								<?php endif; ?>
							<?php endforeach; ?>
						</ul>
						<?php endif; ?>
					</div>
					</div>
				</div>
			<?php endwhile;?>
		<?php endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>
</div>