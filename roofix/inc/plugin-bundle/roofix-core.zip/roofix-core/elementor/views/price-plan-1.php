<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;

$options = array();
$title 		= $data['title'];
$price 		= $data['price'];
$currency 	= $data['currency'];
$period 	= $data['period'];
$buttontext = $data['buttontext'];
$buttonurl 	= $data['buttonurl'];
foreach ( $data['options'] as $option ) {
	$options[] = array(				
		'option_title'   => $option['option_title'],
        'icon'          => $option['icon'],
	);
}

$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'info_image_size', 'info_image' );


?>
<div class="price-table-layout1">
    <div class="price-item">
        <div class="header-wrap">
			<?php echo wp_kses_post($getimg);?>
            <div class="rtin-header">
				<h3 class="rtin-title"><?php echo wp_kses_post( $title );?></h3>
				<div class="rtin-price"><span class="currency"><?php echo esc_attr($currency); ?></span>
                <span class="amount"><?php echo esc_attr($price); ?></span></div>                
                <span class="period"> <?php echo esc_attr($period); ?></span>
            </div>
        </div>
        <ul class="rtin-list-item">                
		<?php foreach ( $options as $option ): ?>                                          
		   <li>                   
			   <span class="rtin-body-item-content"><?php if( !empty($data['icon_display']) == 'yes' ) { ?><i class="<?php echo esc_attr( $option['icon'] );?>" aria-hidden="true"></i><?php } ?><?php echo wp_kses_post( $option['option_title'] );?></span>
		   </li>
	   <?php endforeach; ?>
		</ul>
		<?php if( !empty($data['buttontext']) ) { ?>
        <div class="rtin-footer">
            <a href="<?php echo esc_url($buttonurl);?>" class="item-btn"><?php echo esc_html( $buttontext);?></a>
        </div><?php } ?>
    </div>
 </div>