<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img    = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$getimg = $img;
?>

<div class="about-box-layout7-new">
    <div class="item-img">
        <?php echo wp_kses_post( $getimg );?> 
        <div class="item-experience media progress-circular-layout">           
            <div class="progress-circular">                
                <input type="text" class="knob knob-percent dial" value="0" 
                    data-max        ="100" 
                    data-rel        ="<?php echo esc_attr( $data['number'] );?>" 
                    data-linecap    ="round" 
                    data-width      ="<?php echo esc_attr( $data['circle_width'] );?>"
                    data-height     ="<?php echo esc_attr( $data['circle_height'] );?>" 
                    data-bgcolor    ="<?php echo esc_attr( $data['bgcolor_color'] );?>" 
                    data-fgcolor    ="<?php echo esc_attr( $data['fgcolor_color'] );?>" 
                    data-thickness  ="<?php echo esc_attr( $data['circle_border'] );?>" 
                    data-readonly   ="true" 
                    data-rtspeed    ="<?php echo esc_attr( $data['speed'] );?>" 
                    data-rtsteps    ="<?php echo esc_attr( $data['steps'] );?>" disabled>
                </div>           
                <div class="item-title media-body">
            	<h4 class="rtin-title"><?php echo wp_kses_post( $data['title'] );?></h4>
            	<p class="rtin-content"><?php echo wp_kses_post( $data['subtitle'] );?></p>            		
            </div>
        </div>
    </div>
</div>