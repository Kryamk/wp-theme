<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

extract( $data );

$lists = array();
foreach ( $data['list'] as $list ) {
	$lists[] = array(	
		'list_title'     	=> $list['list_title'],			
	);
}

?>
  
<div class="typed-box-layout1">
    <?php if ( $title ): ?>
		<?php
		$title_animation = $title_animation;
		$title_animation = explode(',', $title_animation);
		$title_animation = array_map('trim', $title_animation);
		$title_animation = json_encode($title_animation);
		?>
		<h2 class="roofix-animation-txt item-title rt-typed" data-title="<?php echo esc_attr($title_animation) ?>" > 
			<?php echo wp_kses_post( $title);?> <span class="animation-txt-word-holder"></span>
		</h2>
	<?php endif; ?>	 
</div>




