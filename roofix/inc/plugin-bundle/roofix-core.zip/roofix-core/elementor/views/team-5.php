<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;

$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;
$thumb_size  = "roofix-size-team1";
$args = array(
	'post_type'      => "{$cpt}_team",
	'posts_per_page' => $data['number'],
	'orderby'        => $data['orderby'],
);

if ( !empty( $data['cat'] ) ) {
	$args['tax_query'] = array(
		array(
			'taxonomy' => "{$cpt}_team_category",
			'field' => 'term_id',
			'terms' => $data['cat'],
		)
	);
}

switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}

$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="team-wrap-layout2 row">
	<?php if ( $query->have_posts() ) :?>
		<?php while ( $query->have_posts() ) : $query->the_post();?>
			<?php
					$id            				= get_the_id();				
					$_designation   			= get_post_meta( $id, "{$cpt}_designation", true );
					$content 					= Helper::get_current_post_content();				
					$socials       				= get_post_meta( $id, "{$cpt}_team_social", true );
					$social_fields 				= Helper::team_socials();
					$content = Helper::get_current_post_content();
					$content = wp_trim_words( $content, $data['count'] );
					$content = "<p>$content</p>";
				?>
				<div class="rtin-item no-equal-item <?php echo esc_attr( $col_class );?>">
					<div class="team-box-layout1-new">		

						<?php
						if ( has_post_thumbnail() ): ?>									    
							<div class="item-img">                           
								<?php the_post_thumbnail( $thumb_size ); ?>	  

							 <div class="item-icon">
						        <a href="<?php the_permalink();?>" class="item-icon"><i class="fas fa-plus"></i></a>
						    </div>

						</div>
						<?php endif; ?>

					    <div class="item-content">
					        <h3 class="item-title"><?php the_title();?></h3>
					        <div class="item-subtitle"><?php echo esc_html($_designation); ?></div>
					    </div>
					</div>
				</div>
			<?php endwhile; ?>
		<?php endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>
</div>
