<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */


namespace radiustheme\Roofix_Core;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;
extract($data);
$thumb_size = 'roofix-size1';
?> 

<div class="rtin-insurance-tab">
	<div class="feature-tab-layout">
		<ul class="nav nav-tabs tab-nav-list">
		<?php $i = 1;
	    foreach ( $data['tab_items'] as $tab_item_list ) { ?>
			<li class="nav-item"><a class="<?php if ( $i == 1 ) { ?>active<?php } ?>" href="#nav-<?php echo esc_html( $i ); ?>" data-toggle="tab" aria-expanded="false">			
				<span><?php echo wp_kses_post( $tab_item_list['title'] ); ?></span></a>
			</li>
			<?php $i++; } ?>
		</ul>
		<div class="tab-content">
			<?php $i = 1;
			foreach ( $data['tab_items'] as $tab_item_list ) { ?>
			<div class="tab-pane fade <?php if ( $i == 1 ) { ?>active<?php } ?> show" id="nav-<?php echo esc_html( $i ); ?>">
				<div class="rtin-item row no-gutters align-items-center">
					<div class="col-lg-6 col-md-6">	
					<div class="rtin-img"><?php 
						//echo Group_Control_Image_Size::get_attachment_image_html( $tab_item_list, 'roofix-size1', 'image' );
						echo wp_get_attachment_image($tab_item_list['image']['id'],'roofix-size1');
					?>
						</div>	
					</div>
					<div class="col-lg-6 col-md-6">	
					<div class="rtin-content">
						<div class="rtin-text">						
							<div>
								<h3 class="rtin-title"><?php echo wp_kses_post( $tab_item_list['ctitle'] ); ?></h3>
								<?php echo wp_kses_post( $tab_item_list['content'] ); ?>
								
							</div>
							</div>

						</div>
					</div>
				</div>
			</div>
			<?php $i++; } ?>
		</div>		
		
	</div>
</div>