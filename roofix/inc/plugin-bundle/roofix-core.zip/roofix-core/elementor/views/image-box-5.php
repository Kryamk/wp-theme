<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$getimg = $img;
?>

<div class="about-box-layout1-new">
    <div class="item-img">
         <?php echo wp_kses_post( $getimg );?>  
    </div>
</div>
