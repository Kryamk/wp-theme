<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
?>

<div class="widget-contact-info">
  <?php if( $data['title'] ){?>
          <h3 class="item-title"><?php echo wp_kses_post( $data['title'] ); ?></h3>
   <?php } ?>
    <div class="media">
        <?php if( $data['phone_label'] ){?>   
        <div class="item-icon">
            <i class="fas fa-phone-square-alt"></i>
        </div>
              <?php } ?>
        <div class="media-body space-md">
             <?php 	if( $data['phone_label'] ){?>
							<h4 class="lab-title"><?php echo wp_kses_post( $data['phone_label'] ); ?></h4>
						<?php } ?>
            <ul class="content-style">
							<?php if( $data['phone'] ){?>
								<li><?php echo wp_kses_post( $data['phone'] ); ?></li>
							<?php } ?>
							<?php if( $data['phone2'] ){?>
								<li><?php echo wp_kses_post( $data['phone2'] ); ?></li>
							<?php } ?>
            </ul>
        </div>
    </div>
    <div class="media">
      <?php if( $data['email_label'] ){?>    
        <div class="item-icon">
          <i class="fas fa-envelope-open"></i>
        </div>
        <?php } ?>
        <div class="media-body space-md">
           <?php 	if( $data['email_label'] ){?>
							<h4 class="lab-title"><?php echo wp_kses_post( $data['email_label'] ); ?></h4>
						<?php } ?>
            <ul class="content-style">
							<?php if( $data['email'] ){?>
								<li><?php echo wp_kses_post( $data['email'] ); ?></li>
							<?php } ?>
							<?php if( $data['email2'] ){?>
								<li><?php echo wp_kses_post( $data['email2'] ); ?></li>
							<?php } ?>
            </ul>
        </div>
    </div>
      <div class="media">
        <?php if( $data['address_label'] ){?>    
            <div class="item-icon">
                <i class="flaticon-maps-and-flags"></i>
            </div>
        <?php } ?>
          <div class="media-body space-md">
							<?php if( $data['address_label'] ){?>
								<h4 class="lab-title"><?php echo wp_kses_post( $data['address_label'] ); ?></h4>
							<?php } ?>
              <ul class="content-style">
								<?php if( $data['address'] ){?>
									<li><?php echo wp_kses_post( $data['address'] ); ?></li>
								<?php } ?>
								<?php if( $data['address2'] ){?>
									<li><?php echo wp_kses_post( $data['address2'] ); ?></li>
								<?php } ?>
              </ul>
          </div>
      </div>
  </div>
