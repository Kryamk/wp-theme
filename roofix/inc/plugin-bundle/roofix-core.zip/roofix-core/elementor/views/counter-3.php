<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract($data);

$final_icon       = " fas fa-thumbs-up";
$final_icon_image_url   = '';
if ( is_string( $icon['value'] ) && $dynamic_icon =  $icon['value']  ) {
  $final_icon     = $dynamic_icon;
}
if ( is_array( $icon['value'] ) ) {
  $final_icon_image_url = $icon['value']['url'];
}

?>

<div class="progress-box-layout1-new">

<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <path fill="" d="M51.2,-50.8C67,-35.3,81.2,-17.6,82.2,1C83.2,19.7,71.2,39.5,55.3,51.1C39.5,62.7,19.7,66.2,-1.4,67.6C-22.5,69,-45.1,68.3,-54.2,56.7C-63.3,45.1,-59,22.5,-53.8,5.2C-48.5,-12.1,-42.4,-24.2,-33.3,-39.7C-24.2,-55.2,-12.1,-74,2.8,-76.8C17.6,-79.5,35.3,-66.2,51.2,-50.8Z" transform="translate(100 100)" />
</svg>
<div class="progress-box-counter">
		<div class="counter rt-el-counter count-number counting-text"><span class="rt-counter-num" data-num="<?php echo esc_attr( $data['number'] );?>" data-rtspeed="<?php echo esc_attr( $data['speed'] );?>" data-rtsteps="<?php echo esc_attr( $data['steps'] );?>"><?php echo esc_html( $data['number'] );?></span><?php echo esc_html( $data['suffix'] );?>
		</div>
		  <div class="item-title"><?php echo wp_kses_post( $data['title'] );?></div>

	</div>
</div>
