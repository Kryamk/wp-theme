<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Group_Control_Image_Size;
use Elementor\Icons_Manager;

$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr .= 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$title = '<a ' . $attr . '>' . $data['title'] . '</a>';
}
else {
	$title = $data['title'];
}

if ( $attr ) {
  $getimg = '<a ' . $attr . '>' .Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size' , 'image' ).'</a>';
}
else {
    $getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
}
$lists = array();
foreach ( $data['list'] as $list ) {
    $lists[] = array(   
        'list_title'        => $list['list_title'],
        'url'               => $list['url'],        
    );
}
?>
<div class="service-box-layout5">
    <div class="item-heading">
    	<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post($data['title']);?> </<?php echo esc_html( $data['title_tag'] );?>>    
        <?php  if ($data['title_style']) { ?>
            <div class="title-style"></div>             
        <?php } ?>   
    </div>
     
     <?php if ( $data['image_icon_active']== 'yes'  ) { ?>
         <?php if ( !empty( $data['icontype']== 'image' ) ) { ?>
        <div class="item-img">
             <span class="border-hover"></span>
                 <?php echo wp_kses_post($getimg);?>        
        </div>  
        <?php }else{?>
            <div class="item-icon">
                <?php Icons_Manager::render_icon( $data['icon_class'], [ 'aria-hidden' => 'true' ] ); ?>
            </div>
        <?php }  ?>
    <?php }  ?>
    
    <?php if ($data['content']) {  ?>
        <p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
    <?php } ?>  
    
    <ul class="service-list">
        <?php foreach ( $lists as $list ): ?>
            <li><i class="fas fa-chevron-circle-right"></i>
                <?php 
                $attr = '';
                if ( !empty( $list['url']['url'] ) ) {
                    $attr  = 'href="' . $list['url']['url']. '"';
                    $attr .= !empty( $list['url']['is_external'] ) ? ' target="_blank"' : '';
                    $attr .= !empty( $list['url']['nofollow'] ) ? ' rel="nofollow"' : '';
                    $rlist = '<a ' . $attr . '>' . $list['list_title'] . '</a>';
                }
                else {
                    $rlist = $list['list_title'];
                } ?>
                <?php echo wp_kses_post( $rlist );?>
            </li>
        <?php endforeach; ?>
        </ul>
        <?php  if ($data['is_button_active'] == 'yes') { ?>
            <?php  if ($data['button_icon_position'] == 'after') { ?>
                <div class="btn-set">
                    <a href="<?php echo esc_attr( $data['url']['url'] );?>" class="icon-after btn-fill-lg bg-textprimary text-accent mg-t-5">
                    <?php echo esc_attr( $data['url_text'] );?> <i class="fas <?php echo esc_attr( $data['button_icon'] );?>"></i></a>
                </div>
            <?php 
            } else { ?>
                <div class="btn-set">
                    <a href="<?php echo esc_url( $data['url']['url'] );?>" class="icon-before btn-fill-lg bg-textprimary text-accent mg-t-5">
                    <i class="fas <?php echo esc_attr( $data['button_icon'] );?>"></i> <?php echo esc_attr( $data['url_text'] );?> </a>
                </div>
            <?php            
            } 
        } ?>

</div>

