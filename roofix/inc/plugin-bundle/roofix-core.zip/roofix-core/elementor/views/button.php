<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

$attr = '';
if (!empty($data['url']['url'])) {
    $attr = 'href="' . $data['url']['url'] . '"';
    $attr .= !empty($data['url']['is_external']) ? ' target="_blank"' : '';
    $attr .= !empty($data['url']['nofollow']) ? ' rel="nofollow"' : '';
}
if ($data['btntext']) {
    $btn = '<a class="non-ghost-btn-md btn-fill" ' . $attr . '>' . $data['btntext'] . '<span><i class="fas fa-caret-right"></i></span></a>';
}
if ($data['btntext']) {
    $btn2 = '<a class="rten-button-lg" ' . $attr . '><span>' . $data['btntext'] . '</span></a>';
}

switch ($data['style']) {
    case '2':
        if ($btn):
            echo wp_kses_post($btn);
        endif;
        break; 
    case '3':
        if ($btn2):
            echo wp_kses_post($btn2);
        endif;
        break;
    default: ?>
        <div class="item-btn rtin-style-<?php echo esc_attr($data['style']); ?>">
            <a <?php echo $attr; ?>><?php echo esc_html($data['btntext']); ?><i class="fas fa-long-arrow-alt-right"></i></a>
        </div>
        <?php break;
} ?>