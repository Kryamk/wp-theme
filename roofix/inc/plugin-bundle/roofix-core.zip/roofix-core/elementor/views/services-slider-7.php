<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$prefix             = ROOFIX_CORE_THEME;
$cpt                = ROOFIX_CORE_CPT;
$thumb_size         = "roofix-size-md";
$thumb_icon_size    = "roofix-size-xs";
extract( $data );

$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}
$args = array(
    'post_type'      => "{$cpt}_services",
    'posts_per_page' => $data['number'],
    'orderby'        => $data['orderby'],
    'paged'          =>  $paged
);

if ( !empty( $data['cat'] ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => "{$cpt}_services_category",
            'field' => 'term_id',
            'terms' => $data['cat'],
        )
    );
}
switch ( $data['orderby'] ) {
    case 'title':
    case 'menu_order':
    $args['order'] = 'ASC';
    break;
}

$query = new WP_Query( $args );
$class = $data['slider_nav'] == 'yes' ? ' slider-nav-enabled' : '';
$temp = Helper::wp_set_temp_query( $query );
$i = 1; 
?>

<div class="service-slider-new-area service-wrap-layout1 rt-el-blgo-post owl-wrap nav-control-layout-top rt-owl-dot  <?php echo esc_attr( $class );?>">
  <div class="owl-theme owl-carousel rt-owl-carousel" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
	<?php if ( $query->have_posts() ) :	
		 while ( $query->have_posts() ) : $query->the_post();		
  			$post_id       		= get_the_id();	
        $content          = "";     
        if ( !empty( $data['services_content'] ) ): 
          $content  		= Helper::get_current_post_content();
          $content  		= wp_trim_words( $content, $data['count'] );
          $content  		= "<p>$content</p>";
        endif;
        $service_icon                  = get_post_meta( $post_id, "roofix_service_icon", true );  
        $service_image_id              = get_post_meta( $post_id, "roofix_service_image", true ); 
        $service_image_url             = wp_get_attachment_image_src( $service_image_id, $thumb_icon_size, true );
        if ( $service_image_id) {
          $tabs_icon                   = '<img class="icon-image non-hover" src=" '.esc_url($service_image_url[0]) .'" alt="">'; 
        } elseif($service_icon) { 
          $tabs_icon                   = '<i class="'.esc_attr($service_icon).'"></i> ';
        }else{
          $tabs_icon                   = get_the_post_thumbnail( $post_id, $thumb_icon_size );  
        }
        $img                          = get_the_post_thumbnail_url( $post_id, $thumb_size );
      ?>		
      <div class="list-item-slider">
          <div  style="background-image: url('<?php  echo esc_url( $img ); ?>');" class="service-box-layout7-new">   
              <div class="box-layout7-content">
                <h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                <?php if ( !empty( $data['services_content'] ) ): ?>
                    <?php echo wp_kses_post( $content );?>
                <?php endif; ?>  
                 <ul class="item-icon">
                 <li><?php  echo wp_kses_post( $tabs_icon ); ?></li>
                 <li><span><?php echo esc_attr($i); ?></span></li>
                </ul>
            </div>
          </div>
	    </div>
		<?php $i++; endwhile;?>
      
	<?php endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>	
	</div>
</div>