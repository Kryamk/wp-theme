<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$btn = $attr = '';

if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="item-btn" ' . $attr . '>' . $data['buttontext'] . '</a>';
}
?>

<div class="action-box-layout2-new">
    <div class="media">
        <div class="item-icon">
           <i class="far fa-comments"></i>
        </div>
        <div class="media-body">
            <?php if ( $data['title'] ): ?>
                 <h2 class="item-title"><?php echo wp_kses_post( $data['title'] );?></h2>
            <?php endif; ?> 
            <?php if ( $data['subtitle'] ): ?>
                <p class="item-sub-title"><?php echo wp_kses_post( $data['subtitle'] );?></p>
            <?php endif; ?>  

        </div>
    </div>
</div>