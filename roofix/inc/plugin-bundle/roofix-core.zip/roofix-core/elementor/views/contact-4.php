<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
?>

  
  <div class="contact-box-layout1-new2">
     <?php if( $data['title'] ){?>
      <h3 class="item-title"><?php echo wp_kses_post( $data['title'] ); ?></h3>
          <?php } ?>
      <div class="media">
          <div class="item-icon">
              <i class="fas fa-map-marker-alt"></i>
          </div>
          <div class="media-body space-md">
              <ul class="content-style">
            <?php if( $data['address'] ){?>
              <li><?php echo wp_kses_post( $data['address'] ); ?></li>
            <?php } ?>
            <?php if( $data['address2'] ){?>
              <li><?php echo wp_kses_post( $data['address2'] ); ?></li>
            <?php } ?>
          </ul>
          </div>
      </div>
      <div class="media">
          <div class="item-icon">
              <i class="fas fa-phone-volume"></i>
          </div>
          <div class="media-body space-md">
            
              <ul class="content-style">
            <?php if( $data['phone'] ){?>
              <li><?php echo wp_kses_post( $data['phone'] ); ?></li>
            <?php } ?>
            <?php if( $data['phone2'] ){?>
              <li><?php echo wp_kses_post( $data['phone2'] ); ?></li>
            <?php } ?>
          </ul>
          </div>
      </div>
      <div class="media">
          <div class="item-icon">
              <i class="far fa-envelope"></i>
          </div>
          <div class="media-body space-md">
         <ul class="content-style">
            <?php if( $data['email'] ){?>
              <li><?php echo wp_kses_post( $data['email'] ); ?></li>
            <?php } ?>
            <?php if( $data['email2'] ){?>
              <li><?php echo wp_kses_post( $data['email2'] ); ?></li>
            <?php } ?>
          </ul>
          </div>
      </div>
  </div>
