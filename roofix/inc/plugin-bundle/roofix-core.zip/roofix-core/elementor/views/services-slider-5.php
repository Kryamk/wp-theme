<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$prefix             = ROOFIX_CORE_THEME;
$cpt                = ROOFIX_CORE_CPT;
$thumb_size         = "roofix-size-blog3";
$thumb_icon_size    = 'roofix-size-xs';
extract( $data );

$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$args = array(
    'post_type'      => "{$cpt}_services",
    'posts_per_page' => $data['number'],
    'orderby'        => $data['orderby'],
    'paged'          =>  $paged
);
if ( !empty( $data['cat'] ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => "{$cpt}_services_category",
            'field' => 'term_id',
            'terms' => $data['cat'],
        )
    );
}
switch ( $data['orderby'] ) {
    case 'title':
    case 'menu_order':
    $args['order'] = 'ASC';
    break;
}

$query = new WP_Query( $args );
$class = $data['slider_nav'] == 'yes' ? ' slider-nav-enabled' : '';
$temp = Helper::wp_set_temp_query( $query );
?>

<div class="service-slider-new-area service-box-area rt-el-blgo-post owl-wrap nav-control-layout-top rt-owl-dot  <?php echo esc_attr( $class );?>">
  <div class="owl-theme owl-carousel rt-owl-carousel" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">  
  	<?php if ( $query->have_posts() ) :	
  		 while ( $query->have_posts() ) : $query->the_post();		
  			$post_id       		= get_the_id();	
        $content = "";     
      if ( !empty( $data['services_content'] ) ): 
        $content  		= Helper::get_current_post_content();
        $content  		= wp_trim_words( $content, $data['count'] );
        $content  		= "<p>$content</p>";
      endif;
        $service_icon                = get_post_meta( $post_id, "roofix_service_icon", true );  
        $service_image_id            = get_post_meta( $post_id, "roofix_service_image", true ); 
        $service_image_url           = wp_get_attachment_image_src( $service_image_id, $thumb_icon_size, true );
      if ( $service_image_id) {
        $tabs_icon                   = '<img class="icon-image non-hover" src=" '.esc_url($service_image_url[0]) .'" alt="">'; 
      } elseif($service_icon) { 
        $tabs_icon                   = '<i class="'.esc_attr($service_icon).'"></i> ';
      }else{
        $tabs_icon                   = get_the_post_thumbnail( $post_id, $thumb_icon_size );  
      }
		?>			
      <div class="rtin-item">         
         <div class="service-box-layout2-new">
             <?php if ( has_post_thumbnail() ){ ?>   
                  <div class="item-img">
                     <?php  the_post_thumbnail( $thumb_size ); ?>      
                      
                  </div>
                <?php } ?>
              <div class="item-content">
                   <h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>      
                  <?php  if ($data['title_style'] == 'yes') { ?>
                    <div class="title-style"></div>       
                  <?php } ?> 
                  <?php if ( !empty( $data['services_content'] ) ): ?>
                    <div class="item-category">
                      <?php echo wp_kses_post( $content );?>
                    </div>
                  <?php endif; ?>  
              </div>
          </div>
	    </div>

		<?php endwhile;?>
   
	<?php endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>	

	</div>
</div>