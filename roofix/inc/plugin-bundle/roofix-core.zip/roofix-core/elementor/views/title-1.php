<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
?>
<div class="heading-layout1">			
	<?php  if ($data['beforetitle']) { ?>
		<div class="item-beforetitle item-subtitle"><?php echo wp_kses_post( $data['beforetitle'] );?></div>		
	<?php } ?>
	<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $data['title'] );?> </<?php echo esc_html( $data['title_tag'] );?>>
	<?php  if ($data['title_style'] == "yes") { ?>
			<div class="title-style"></div>				
	<?php } ?>
	<?php  if ($data['subtitle']) { ?>
		<p class="section-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></p>
	<?php } ?>
</div>
