<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Group_Control_Image_Size;

$img 		= Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$lists = array();
foreach ( $data['list'] as $list ) {
	$lists[] = array(
		'list_title'     	=> $list['list_title'],
		'url'    					=> $list['url'],
	);
}

?>

<div class="about-box-layout-viedo">
	<div class="media">
		 <div class="item-img">
		       <?php echo wp_kses_post($img); ?>
		      <div class="item-icon">
		          <a class="play-btn popup-video popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
					<svg
					  width="24"
					  height="24"
					  viewBox="0 0 24 24"
					  fill="none"
					  xmlns="http://www.w3.org/2000/svg"
					>
					  <path d="M15 12.3301L9 16.6603L9 8L15 12.3301Z" fill="currentColor" />
					</svg>
		          </a>
		      </div>
		  </div>
		  <div class="item-content media-body">
			<h2 class="item-title"><?php echo wp_kses_post( $data['title'] );?></h2>
			<?php  if ($data['subtitle']) { ?>
				<div class="item-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></div>
			<?php } ?>
	     	<p><?php echo wp_kses_post( $data['content'] );?></p>
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" width="368" height="46" viewBox="0 0 368 46">
			  <defs>
			  </defs>
			  <path d="M-0.000,43.000 C-0.000,43.000 108.297,13.000 168.229,20.000 C214.386,25.391 338.560,55.500 368.000,0.000 L368.000,43.000 L-0.000,46.000 " class="cls-1"/>
			</svg>

		  </div>
	</div>
</div>