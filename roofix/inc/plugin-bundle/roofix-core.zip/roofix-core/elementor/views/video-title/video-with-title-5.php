<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );

?>

<div class="about-box-layout8r content-slide-new">
	 <div class="item-img">
       <?php echo wp_kses_post($img); ?>
      <div class="item-icon">
          <a class="play-btn popup-video popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
         <svg
				  width="24"
				  height="24"
				  viewBox="0 0 24 24"
				  fill="none"
				  xmlns="http://www.w3.org/2000/svg"
				>
				  <path d="M15 12.3301L9 16.6603L9 8L15 12.3301Z" fill="currentColor" />
				</svg>
          </a>
      </div>
	  </div>
	  <div class="item-content video-box-slide">
	  	<div class="swiper-container">
		  	<div class="swiper-wrapper">
		   		<?php foreach ( $data['content_slide_item'] as $list ){ ?>
				  	<div class="list-item-slide swiper-slide">
							<?php  if ($list['subtitle']) { ?>
								<div class="subtitle-style"><?php echo wp_kses_post( $data['subtitle'] );?></div>
							<?php } ?>
							<?php  if ($list['title']) { ?>
								<h2 class="item-title"><?php echo wp_kses_post( $data['title'] );?></h2>
							<?php } ?>
							<?php  if ($list['title']) { ?>
					     		<p><?php echo wp_kses_post( $list['content'] );?> </p>
					     	<?php } ?>
					     	<?php echo wp_kses_post( $list['content_list'] );?>
				  	</div>
				<?php } ?>
			</div>
		</div>
		<div class="swiper-pagination"></div>
  	</div>
</div>