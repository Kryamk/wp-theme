<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Group_Control_Image_Size;

$img 		= Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
?>

<div class="about-box-layout9r content-slide-new">
	 <div class="item-img">
       <?php echo wp_kses_post($img); ?>
      <div class="item-icon">
          <a class="play-btn popup-video popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
         <svg width="24"
				  height="24"
				  viewBox="0 0 24 24"
				  fill="none"
				  xmlns="http://www.w3.org/2000/svg"
				>
				  <path d="M15 12.3301L9 16.6603L9 8L15 12.3301Z" fill="currentColor" />
				</svg>
          </a>
      </div>
	  </div>
</div>