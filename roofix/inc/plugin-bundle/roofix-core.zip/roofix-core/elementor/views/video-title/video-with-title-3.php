<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Group_Control_Image_Size;

$img 		= Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$lists = array();
foreach ( $data['list'] as $list ) {
	$lists[] = array(
		'list_title'     	=> $list['list_title'],
		'url'    					=> $list['url'],
	);
}

?>
<div class="about-box-layout8r">
	 <div class="item-img">
       <?php echo wp_kses_post($img); ?>
      <div class="item-icon">
          <a class="play-btn popup-video popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
              <i class="fas fa-play"></i>
          </a>
      </div>
	  </div>
	  <div class="item-content <?php echo wp_kses_post( $itemcontent );?>">
			<?php  if ($data['subtitle']) { ?>
				<div class="subtitle-style"><?php echo wp_kses_post( $data['subtitle'] );?></div>
			<?php } ?>
			<h2 class="item-title"><?php echo wp_kses_post( $data['title'] );?></h2>
	     	<p><?php echo wp_kses_post( $data['content'] );?></p>
				   <ul class="list-item">
				   <?php foreach ( $lists as $list ): ?>
						<li><i class="fas fa-check"></i>
							<?php
								$attr = '';
									if ( !empty( $list['url']['url'] ) ) {
										$attr  = 'href="' . $list['url']['url']. '"';
										$attr .= !empty( $list['url']['is_external'] ) ? ' target="_blank"' : '';
										$attr .= !empty( $list['url']['nofollow'] ) ? ' rel="nofollow"' : '';
										$rlist = '<a ' . $attr . '>' . $list['list_title'] . '</a>';
									}
									else {
										$rlist = $list['list_title'];
									} ?>
								<?php echo wp_kses_post( $rlist );?>
						</li>
					<?php endforeach; ?>
			 </ul>
	  </div>
</div>