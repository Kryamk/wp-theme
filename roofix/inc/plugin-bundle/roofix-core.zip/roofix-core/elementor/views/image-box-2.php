<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$getimg = $img;

if ( !empty( $data['alignment'] ) ) { ?>
    <div class="about-box-layout5">
        <div class="about-box-img">
            <div class="item-img">
               <?php echo wp_kses_post( $getimg );?>
                 <div class="item-icon video-wrapper-inner">
                <a class="play-btn popup-youtube popup-video clearfix" href="<?php echo esc_url( $data['videourl']);?>">
                 <i class="fas fa-play"></i>
                    <div class="player-wave popup-video-inner">
                            <div class="waves wave-1"></div>
                            <div class="waves wave-2"></div>
                            <div class="waves wave-3"></div>
                    </div>
                </a>
            </div>
            </div>
            <div class="sl-number left"><?php echo esc_attr( $data['pnumber'] );?></div>
        </div>
    </div> 
<?php } else{ ?>
<div class="about-box-layout5">
    <div class="about-box-img">
        <div class="item-img">
           <?php echo wp_kses_post( $getimg );?>
            <div class="item-icon video-wrapper-inner">
                <a class="play-btn popup-youtube popup-video clearfix" href="<?php echo esc_url( $data['videourl']);?>">
                 <i class="fas fa-play"></i>
                    <div class="player-wave popup-video-inner">
                            <div class="waves wave-1"></div>
                            <div class="waves wave-2"></div>
                            <div class="waves wave-3"></div>
                    </div>
                </a>
            </div>
        </div>
        <div class="sl-number"><?php echo esc_attr( $data['pnumber'] );?></div>
    </div>
</div> 
<?php } ?>
