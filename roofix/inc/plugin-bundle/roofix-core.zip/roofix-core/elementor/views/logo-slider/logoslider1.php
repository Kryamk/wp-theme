<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
?>
<div class="brand-box-layout-wrp">
	<div class="rt-el-logo-slider">
		<?php if ( !empty($data['title']) ): ?>
			<div class="sponsonrs-type-title">
			    <h3><?php echo esc_attr( $data['title'] );?></h3>
			</div>
		<?php endif; ?>
		<div class="logo-slider-grid row">
			<?php foreach ( $data['logos'] as $logo ): ?>
				<?php if ( empty( $logo['image']['id'] ) ) continue; ?>
					<?php if ( !empty( $logo['url'] ) ): ?>
						<div class="rtin-item post-each <?php echo esc_attr( $col_class );?>">
							<div class="rtin-item sponsonrs-box">
									<div class="brand-box-layout2 grid">
											<div class="item-img">								
												<a href="<?php echo esc_url( $logo['url'] );?>" target="_blank"><?php echo wp_get_attachment_image( $logo['image']['id'], 'full' );?></a>
										</div>					
									</div>					
							</div>					
						</div>					
					<?php else: ?>
						<div class="rtin-item <?php echo esc_attr( $col_class );?>">
							<div class="brand-box-layout2 grid">
								<div class="item-img">					
									<?php echo wp_get_attachment_image( $logo['image']['id'], 'full' );?>
								</div>
							</div>
						</div>
					<?php endif; ?>
			<?php endforeach; ?>
				</div>
		</div>
</div>
