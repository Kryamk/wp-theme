<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

?>
<div class="brand-box-layout-wrp">
	<div class="rt-el-logo-slider slider-nav-enabled swiper-container">
	<?php if ( !empty($data['title']) ): ?>
		<div class="sponsonrs-type-title">
		    <h3><?php echo esc_attr( $data['title'] );?></h3>
		</div>
	<?php endif; ?>
		<div class="rt-logo-carousel swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
			<?php foreach ( $data['logos'] as $logo ): ?>
				<?php if ( empty( $logo['image']['id'] ) ) continue; ?>

					<?php if ( !empty( $logo['url'] ) ): ?>
						<div class="rtin-item sponsonrs-box swiper-slide">
								<div class="brand-box-layout2 grid slider">
										<div class="item-img">
											<a href="<?php echo esc_url( $logo['url'] );?>" target="_blank"><?php echo wp_get_attachment_image( $logo['image']['id'], 'full' );?></a>
									</div>
								</div>
						</div>
					<?php else: ?>
						<div class="brand-box-layout2 grid slider swiper-slide">
							<div class="item-img">
								<?php echo wp_get_attachment_image( $logo['image']['id'], 'full' );?>
							</div>
						</div>
					<?php endif; ?>
			<?php endforeach; ?>
				</div>
		</div>
	</div>