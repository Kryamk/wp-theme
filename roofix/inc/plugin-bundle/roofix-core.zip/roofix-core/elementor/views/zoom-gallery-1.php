<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
?>
	<div class="zoom-gallery-box">
			<div class="tab-content">
			   	<?php foreach ( $data['imagegrid_list'] as $key => $zoom_image ): 		
			     	   $zoomimg             = wp_get_attachment_image_src($zoom_image['zoom_image']['id'], 'roofix-size-project', true );	   	
			   		?>
			   		<?php $class = $key == 0 ? 'show active' : '' ?> 
					    <div class="tab-pane fade <?php echo esc_attr( $class ) ?>" id="<?php echo esc_attr("random-" . $zoom_image['_id']) ?>" role="tabpanel">
								
								<img class="zoom_01" src="<?php echo esc_url($zoomimg['0']) ;?>" data-zoom-image="<?php echo esc_url($zoom_image['zoom_image']['url']) ;?>" alt="service">				    						    	

					    </div>
			   	<?php endforeach; ?>
			</div>
			<ul class="nav nav-tabs tab-nav-list" role="tablist">
			    	<?php foreach ( $data['imagegrid_list'] as $key => $zoom_image ): ?>

				    <li class="nav-item">
				    	  <?php $class = $key == 0 ? 'active' : '' ?>
				        <a class="nav-link <?php echo	esc_attr( $class ) ?>" data-toggle="tab" href="#<?php echo esc_attr("random-" . $zoom_image['_id']) ?>" role="tab" aria-selected="true">

											<?php echo wp_get_attachment_image( $zoom_image['zoom_image']['id'], 'roofix-size-project-zoom' );?>

				        </a>
				    </li>
			   	<?php endforeach; ?>
			</ul>

	</div>

