<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$thumb_size = 'roofix-size-6';
$args = array(
	'posts_per_page' => $data['number'],
	'category_name'  => !empty($data['cat']) && is_array($data['cat']) ? implode(',', $data['cat']) : '',
	'orderby'        => $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}

$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="rt-el-blgo-post row">
<?php if ( $query->have_posts() ) :
	$html = '';
	$count = 1;
	?>
		<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php
				$content = Helper::get_current_post_content();
				$content = wp_trim_words( $content, $data['count'] );
				$content = "<p class='item-content-p'>$content</p>";
				$comments_number = number_format_i18n( get_comments_number() );
				$comments_html   = $comments_number < 2 ? esc_html__( 'Comment' , 'roofix-core' ) : esc_html__( 'Comments' , 'roofix-core' );
				$comments_html  .= ': '. $comments_number;
				$has_entry_meta_1  = RDTheme::$options['blog_date'] || ( RDTheme::$options['blog_cats'] && has_category() ) ? true : false;
				$has_entry_meta_2  = RDTheme::$options['blog_author_name'] || RDTheme::$options['blog_comment_num'] ? true : false; 
				?>
				<div class="blog-box-wrp rtin-item post-each <?php echo esc_attr( $col_class );?>">		
					<div class="blog-box-layout6-new">
					<?php if ( has_post_thumbnail() ){ ?>
						  <div class="item-img">
							<a href="<?php the_permalink();?>" rel="bookmark">
								<?php the_post_thumbnail( $thumb_size );?>								
							</a>
							<?php if ( $data['meta']  == 'yes' ): ?>	
					    		<div class="item-date"><i class="fas fa-calendar-alt"></i><?php the_time( get_option( 'date_format' ) );?></div>	
						<?php endif; ?>		
						</div>
					<?php }	?>

					    <div class="item-content">				    				
					        <h3 class="item-title">
					           <a href="<?php the_permalink();?>" class="entry-title" rel="bookmark"><?php the_title();?></a>
					        </h3>

					        <?php if ( $data['meta']  == 'yes' ): ?>	
							<ul class="entry-meta">
								<?php if ( RDTheme::$options['blog_author_name'] ): ?>
									<li class="vcard-author"><i class="fa fa-user" aria-hidden="true"></i> <span class="vcard author"><?php the_author_posts_link();?></span></li>
								<?php endif; ?>					
								<?php if ( RDTheme::$options['blog_comment_num']): ?>
									<li class="vcard-comments"> <i class="fa fa-comments" aria-hidden="true"></i> <?php echo wp_kses_post( $comments_html );?></li>
								<?php endif; ?>		
							</ul>
						<?php endif; ?>

					        <?php if ( $data['show_content']  == 'yes' ): ?>	
								<?php echo wp_kses_post( $content );?>
							<?php endif ?>
							<?php if ( $data['url_text'] ): ?>						   
							    <a href="<?php the_permalink();?>" class="non-ghost-btn-md"><?php echo esc_attr($data['url_text']); ?><span><i class="fas fa-caret-right"></i></span></a>
							<?php endif ?>
					    </div>
					</div>	
				</div>	
			<?php 
			endwhile;		
		endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>
</div>