<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html($data, 'image_size', 'image');
$lists = array();
foreach ($data['content_items'] as $list) {
    $lists[] = array(
        'list_title'   => $list['title'],
        'list_content' => $list['content'],
        'list_count'   => $list['count'],
    );
}
?>
<div class="services-list-layout2">
    <div class="item-content">
        <div class="stitle-holder">
            <?php if (!empty($data['stitle'])) { ?>
                <h3 class="s-title"><?php echo esc_attr($data['stitle']); ?></h3>
            <?php } ?>
        </div>
        <ul class="list-item">
            <?php foreach ($lists as $list): ?>
                <li>
                    <?php if (!empty($list['list_title'])) { ?>
                        <h3 class="list-title"><?php echo esc_attr($list['list_title']); ?></h3>
                    <?php } ?>
                    <?php if (!empty($list['list_title'])) { ?>
                        <span class="count"><?php echo esc_attr($list['list_count']); ?></span>
                    <?php } ?>
                    <?php if (!empty($list['list_content'])) { ?>
                        <p class="sr-content"><?php echo esc_attr($list['list_content']); ?></p>
                    <?php } ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
