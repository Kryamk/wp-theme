<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$btn = $attr = '';
if ( !empty( $data['buttonurl']['url'] ) ) {
	$attr  = 'href="' . $data['buttonurl']['url'] . '"';
	$attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( !empty( $data['buttontext'] ) ) {
	$btn = '<a class="btn-fill-xl bg-textprimary text-primarytext" ' . $attr . '>' . $data['buttontext'] . '<i class="fas fa-angle-right"></i></a>';
}
?>

	<div class="about-box-layout1d">
	  <div class="about-box-content">
	      <div class="item-header">
					<div class="experience-year">
						<?php if($data['title']){ ?>
								<h2 class="item-title"><?php echo wp_kses_post( $data['title'] );?></h2>
						<?php } ?>
				</div>
	      </div>
	      <?php if($data['subtitle']){ ?>
					<div class="item-subtitle"><?php echo wp_kses_post( $data['subtitle'] );?></div>
				<?php } ?>
				<?php if($data['content']){ ?>
						<div class="rtr-content"><?php echo wp_kses_post( $data['content'] );?></div>
				<?php } ?>
				<?php if ( $btn ): ?>
					<div class="rtin-button"><?php echo wp_kses_post( $btn );?></div>		
				<?php endif; ?>	      
	  </div>
	</div>