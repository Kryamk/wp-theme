<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;

$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;

extract( $data );
$args = array(
	'post_type'        	=> "{$cpt}_projects",
	'posts_per_page'   	=> $data['number'],
	'suppress_filters' 	=> false,
	'orderby'          	=> $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$bool = isset($data['category_list']);
$bool = $bool && is_array($data['category_list']);
$bool = $bool && count($data['category_list']) ;
if ($bool) {
  $args['tax_query'] = array(
    array(
      'taxonomy' 					=> "{$prefix}_projects_category",
      'terms' 						=> $data['category_list'], // Where term_id of Term 1 is "1".
      'include_children'	=> false
    )
  );
}
$posts 		= get_posts( $args );
$uniqueid = time() . rand( 1, 99 );
$project 	= array();
$cats    	= array();
$thumb_size2  = 'roofix-size-2';
$thumb_size3  = 'roofix-size-3';

foreach ( $posts as $post ) {
	$cats_comma       = array();
	$terms            = get_the_terms( $post, "{$cpt}_projects_category" );
	$terms            = $terms ? $terms : array();
 	$image_id 				= get_post_thumbnail_id($post);
	$col_lg 	      = get_post_meta( $post->ID, "roofix_col_lg", true );
	$col_md 	  	  = get_post_meta( $post->ID, "roofix_col_md", true );
	$col_sm 	  	  = get_post_meta( $post->ID, "roofix_col_sm", true );
	$img_2  = get_the_post_thumbnail_url( $post, $thumb_size2 );		
	$img_3  = get_the_post_thumbnail_url( $post, $thumb_size3 );	

	$terms_html       = '';
	$terms_comma_html = '';
	if ( !$terms ) {
		continue;
	}

	foreach ( $terms as $term ) {
		$terms_html  .= " {$uniqueid}-{$term->slug}";
		$cats_comma[] = $term->name;
		if ( !isset( $cats[$term->slug] ) ) {
			$cats[$term->slug] = $term->name;
		}
	}

 	if ( has_excerpt($post) ) {
     $final_content =  wp_trim_words( get_the_excerpt($post->ID), $no_of_excerpt_words, '');
    }else{
        $content = wp_strip_all_tags($post->post_content);
        $final_content = wp_trim_words( $content, $no_of_excerpt_words, '' );
    }


	$project[] = array(
		'img2'        	=> $img_2,
		'img3'        	=> $img_3,
		'alt' 			=> Helper::roofix_get_attachment_alt($image_id),
		'title'      	=> $post->post_title,
		'url'        	=> get_the_permalink( $post ),
		'cats'       	=> $terms_html,
		'cats_comma' 	=> implode(", ", $cats_comma ),
		'postID'     	=> $post->ID,
		'excerpt'   	=>  $final_content,
    	'link_text' 	=> $url_text,

		'col_lg' 		 	=> $col_lg == '' ? '3' : $col_lg, 
		'col_md' 		 	=> $col_md == '' ? '6' : $col_md, 
		'col_sm' 		 	=> $col_sm == '' ? '12' : $col_sm, 

   
	);
}
?>
<div class="rt-el-projects-1 projects-isotope-masonry rt-isotope-wrapper">
	
	<?php if($data['filter'] == 'yes'){ ?>
		<div class="rt-isotope-tab-wrp"> 
			<div class="rt-isotope-tab isotope-classes-tab isotop-btn "> 
				<a href="#" data-filter="*" class="current"><?php esc_html_e( 'All Projects', 'roofix-core' );?></a>
				<?php foreach ( $cats as $key => $value): ?>
					<?php $cat_filter = "{$uniqueid}-{$key}";?>
					<a href="#" data-filter=".<?php echo esc_attr( $cat_filter );?>"><?php echo esc_html( $value );?></a>
				<?php endforeach; ?>
			</div>
		</div>
	<?php  } ?>

	<div class="row gutters-2 rt-isotope-content">	
		<?php foreach ( $project as $project_each ):
			$col_class = "col-lg-{$project_each['col_lg']} col-md-{$project_each['col_md']} col-{$project_each['col_sm']}";
		 ?>				
			<div class="<?php echo esc_attr( $col_class . $project_each['cats'] );?> ">
				<div class="project-box-layout6">						
					 <div class="item-excerpt">									
						 <div class="item-heading">	
							<?php if( $category_display == 'yes'){ ?>	
								<div class="item-tag item-subtitle"><?php Helper::rt_get_projects_cat($project_each['postID']); ?></div>
							<?php } ?>
							<?php if( $title_style == 'yes'){ ?>		
							<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <a href="<?php echo esc_url( $project_each['url'] );?>"><?php echo esc_html( $project_each['title'] );?></a> </<?php echo esc_html( $data['title_tag'] );?>>		            
							<?php  }else{
								?>
								<h3 class="item-title">
									<a href="<?php echo esc_url( $project_each['url'] );?>">
										<?php echo esc_html( $project_each['title'] );?>											
									</a>
								</h3>			 
							<?php  } ?>
							<?php if( $excerpt_display == 'yes'){ ?>
								<p class="project-excerpt"><?php echo esc_html(  $project_each['excerpt'] ); ?></p>
							<?php } ?>	
							<?php if( $btn_display == 'yes'){ ?>
							   <a href="<?php echo esc_url( $project_each['url'] );?>" class="rt-button-sp">
							   	<span><?php echo esc_attr( $data['url_text'] );?></span>
							   </a>	
							<?php } ?>	
			      		</div>
					</div>
				  	<div class="item-img">
					  	<?php if($project_each['col_lg'] == '6'){
							echo get_the_post_thumbnail( $project_each['postID'], $thumb_size2, array( 'class' => 'img-6' ) ); 
							?>
					  	<?php }else{
							echo get_the_post_thumbnail( $project_each['postID'], $thumb_size3, array( 'class' => 'img-3' ) );   
							?>
					  	<?php } ?>
					</div>
					  <div class="item-content">
					      <div class="item-heading">	
							<?php if( $category_display == 'yes'){ ?>	
								<div class="item-tag item-subtitle"><?php echo Helper::rt_get_projects_cat($project_each['postID']); ?></div>
							<?php } ?>	
								<?php if( $title_style == 'yes'){ ?>		
								<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <a href="<?php echo esc_url( $project_each['url'] );?>"><?php echo esc_html( $project_each['title'] );?></a> </<?php echo esc_html( $data['title_tag'] );?>>		            
								<?php  }else{ ?>
									<h3 class="item-title"><a href="<?php echo esc_url( $project_each['url'] );?>"><?php echo esc_html( $project_each['title'] );?></a></h3>			 
								<?php  } ?>										 	
				      		</div>					      		
					  </div>
					</div>   
				</div>
			<?php endforeach;?>
		</div>
	</div>