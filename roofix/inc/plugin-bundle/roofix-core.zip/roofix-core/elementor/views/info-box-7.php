<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;

$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$title = '<a ' . $attr . '>' . $data['title'] . '</a>';
}
else {
	$title = $data['title'];
}

if ( $attr ) {
  $getimg = '<a ' . $attr . '>' .Group_Control_Image_Size::get_attachment_image_html( $data, 'info_image_size' , 'info_image' ).'</a>';
}
else {
	$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'info_image_size', 'info_image' );
}
?>
<div class="service-box-layout7media">
      <div class="item-icon">
			<?php echo wp_kses_post( $title );?>
      </div>           	 
		<?php  if ($data['content']) { ?>
			<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
		<?php } ?>        
</div>