<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract($data);

$final_icon       = " fas fa-thumbs-up";
$final_icon_image_url   = '';
if ( is_string( $icon['value'] ) && $dynamic_icon =  $icon['value']  ) {
  $final_icon     = $dynamic_icon;
}
if ( is_array( $icon['value'] ) ) {
  $final_icon_image_url = $icon['value']['url'];
}
$title = $data['title'];
$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'info_image_size', 'info_image' );
?>


<div class="process-box-layout1new">
    <div class="process-box-holder">
        <div class="item-icon">
            <?php if ( $data['icontype'] == 'image' ): ?>
                <?php
                    if ( !empty( $data['image']['id'] ) ) {
                        echo Group_Control_Image_Size::get_attachment_image_html( $data, 'info_image_size', 'info_image' );
                    }
                ?>
            <?php else: ?>      
                <?php if ( $final_icon_image_url ): ?>
                <img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
                <?php else: ?>
                <i class="<?php  echo esc_attr( $final_icon ); ?>"></i>
                <?php endif ?>
            <?php endif; ?>       
        </div>
        <h3 class="item-title"><?php echo wp_kses_post( $data['number'] );?></h3>
        <div class="item-subtitle"><?php echo wp_kses_post( $title );?></div>
        <?php if ( $content ): ?>
            <p class="rt-content"><?php echo wp_kses_post( $content );?></p>
        <?php endif; ?>
        <?php  if ($data['title_style']) { ?> 
            <div class="right-side-dot"></div>
        <?php } ?>
    </div>
</div>

