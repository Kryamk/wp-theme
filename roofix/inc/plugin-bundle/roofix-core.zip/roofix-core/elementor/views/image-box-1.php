<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$getimg = '<a ' . $attr . '>' . $img  . '</a>';
}else{
	$getimg = $img;
}
if ( !empty( $data['alignment'] ) ) { ?>
    <div class="about-box-layout4">
        <div class="about-box-img">
            <div class="item-img">
                 <?php echo wp_kses_post( $getimg );?>
            </div>
            <div class="sl-number"><?php echo esc_attr( $data['pnumber'] );?></div>
        </div>
    </div>
<?php } else{ ?>
<div class="about-box-layout5">
     <div class="about-box-img">
        <div class="item-img">
             <?php echo wp_kses_post( $getimg );?>
        </div>
        <div class="sl-number"><?php echo esc_attr( $data['pnumber'] );?></div>
    </div>
</div>
<?php } ?>
