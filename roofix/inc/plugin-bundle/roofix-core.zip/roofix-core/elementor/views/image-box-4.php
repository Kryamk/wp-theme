<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img = Group_Control_Image_Size::get_attachment_image_html( $data, 'image_size', 'image' );
$getimg = $img;
?>
<div class="item-single-image"> 
    <div class="item-img popup-overlay">
          <?php echo wp_kses_post( $getimg );?>       
           <?php  if ( $data['videourl'] != "" ) { ?>
            <div class="item-icon">
                <a class="play-btn popup-youtube" href="<?php echo esc_url( $data['videourl']);?>">
                     <i class="fas fa-play"></i>
                </a>
            </div>
        <?php } ?>
    </div>
</div>
           