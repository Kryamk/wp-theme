<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$thumb_size = 'roofix-size-blog3';
$args = array(
	'posts_per_page' => $data['number'],
	'category_name'  => !empty($data['cat']) && is_array($data['cat']) ? implode(',', $data['cat']) : '',
	'orderby'        => $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}

$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="rt-el-blgo-post row">
	<?php if ( $query->have_posts() ) :?>
		<?php while ( $query->have_posts() ) : $query->the_post();			
			$content = Helper::get_current_post_content();
			$content = wp_trim_words( $content, $data['count'] );
			$content = "<p class='item-content-p'>$content</p>";
			$comments_number = number_format_i18n( get_comments_number() );
			$comments_html   = $comments_number < 2 ? esc_html__( 'Comment' , 'roofix-core' ) : esc_html__( 'Comments' , 'roofix-core' );
			$comments_html  .= ': '. $comments_number;	?>					
			<div class="rtin-item  <?php echo esc_attr( $col_class );?>">
				<div class="blog-box-layout3 blog-box-wrp">						   
					<?php if ( has_post_thumbnail() ){?>  
				    	<div class="item-img">
							<a href="<?php the_permalink();?>" rel="bookmark">
									<?php the_post_thumbnail( $thumb_size );?>								
							</a>
							<?php if ( $data['meta']  == 'yes' ): ?>							 
								<?php if ( RDTheme::$options['blog_date'] ): ?>
									<div class="top-item">
										<div class="item-date">
											<?php 
												$date 	= strtotime( get_the_date() );
												$day  	= date( 'j', $date );
												$month  = date( 'M', $date );?>
												<span class="days"><?php echo esc_attr($day) ?></span>
												<span class="month"><?php echo esc_attr($month) ?></span>	
										</div>
									</div>
								<?php endif; ?>		
							<?php endif ?>
						</div>
						<?php }else{ ?>
						<?php if ( $data['meta']  == 'yes' ): ?>							 
							<?php if ( RDTheme::$options['blog_date'] ): ?>
							 <div class="item-non-img">
								<div class="top-item">
									<div class="item-date">
									<?php 
										$date 		= strtotime( get_the_date() );
										$day  		= date( 'j', $date );
										$month  	= date( 'M', $date );?>
									<span class="days"><?php echo esc_attr($day) ?></span>
									<span class="month"><?php echo esc_attr($month) ?></span>	
									</div>
								</div>
							</div>									
							<?php endif; ?>		
						<?php endif ?>
						<?php } ?>	
				    	<div class="item-content">
							<h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>							       
							<?php if ( $data['meta']  == 'yes' ): ?>							 
							<?php if ( RDTheme::$options['blog_date'] ): ?>	
								<ul class="entry-meta">
									<?php if ( RDTheme::$options['blog_author_name'] ): ?>
									<li class="vcard-author"><span class="vcard author">
										<?php echo esc_html__( 'by', 'roofix-core' ); ?>
										<?php the_author_posts_link();?></span>
									</li>
									<?php endif; ?>					
									<?php if ( RDTheme::$options['blog_comment_num']): ?>
										<li class="vcard-comments"><?php echo wp_kses_post( $comments_html );?></li>
									<?php endif; ?>
								</ul>
							<?php endif; ?>		
							<?php endif ?>
						<?php if ( $data['show_content']  == 'yes' ): ?>	
							<?php echo wp_kses_post( $content );?>
						<?php endif ?>
					</div>
				</div>
			</div>	
			<?php 
			endwhile;		
		endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>
</div>