<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
$title = $data['title'];
?>
<div class="more-info-box">
    <div class="item-content">
        <div class="process-list">           
            <div class="sl-number"><?php echo wp_kses_post( $data['number'] );?></div>
           <<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $title );?> </<?php echo esc_html( $data['title_tag'] );?>>

				<?php  if ($data['title_style']) { ?>
					<div class="title-style"></div>				
				<?php } ?>

            <p class="rtin-text item-content"><?php echo wp_kses_post( $data['content'] );?></p>            
        </div>
    </div>
</div>