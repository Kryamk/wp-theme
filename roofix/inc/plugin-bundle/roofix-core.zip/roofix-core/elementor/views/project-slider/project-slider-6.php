<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;
$thumb_size  = "roofix-size-5";
$args = array(
    'post_type'      => "{$cpt}_projects",
    'posts_per_page' => $data['number'],
    'orderby'        => $data['orderby'],
    'paged' => 1
);

if ( !empty( $data['cat'] ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => "{$cpt}_projects_category",
            'field' => 'term_id',
            'terms' => $data['category_list'],
        )
    );
}
switch ( $data['orderby'] ) {
    case 'title':
    case 'menu_order':
    $args['order'] = 'ASC';
    break;
}
$query = new WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );

?>

<div style="display:none" class="project-box-layout6-new rt-porject-slide swiper-container">
	<div class="swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
		<?php if ( $query->have_posts() ) : ?>
				<?php while ( $query->have_posts() ) : $query->the_post();?>
				<?php $postID = get_the_id();?>
				<div class="project-box swiper-slide">
				   <?php if ( has_post_thumbnail()) { ?>
					 <div class="item-img"><?php  the_post_thumbnail( $thumb_size ); ?>	</div>
					<?php } ?>
				    <div class="item-content">
					<?php if($data['show_category'] == 'yes') { ?>
					<div class="item-subtitle"><?php echo Helper::rt_get_projects_cat($postID); ?></div><?php } ?>
				         <h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>

				        <?php if ( 'yes' === $data['details_btn']): ?>
					        <div class="item-btn-holder">
					        	<a href="<?php the_permalink();?>" class="item-btn non-ghost-btn-md">
					        		<?php echo wp_kses_post( $data['buttontext'] );?><span><i class="fas fa-caret-right"></i></span>
					        	</a>
					    	</div>
					    <?php endif; ?>

				    </div>
				</div>
			<?php endwhile;?>
		<?php endif;?>
		<?php Helper::wp_reset_temp_query( $temp );?>
	</div>
</div>
