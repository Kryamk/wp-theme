<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;

$testimonials = [];
foreach ($data['testimonials'] as $testimonial) {

    $testimonials[] = array(
        'id'    => $testimonial['image']['id'] ? $testimonial['image']['id'] : "",
        'title'    => $testimonial['title'],
        'subtitle' => $testimonial['subtitle'],
        'content'  => $testimonial['content'],
        'rating'   => $testimonial['rating'],
    );
}

?>
<div style="display:none;" class="testimonial-box-layout8-new swiper-container rt-testimonial">
        <div class="swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
            <?php foreach ($testimonials as $testimonial):
                $rating = $testimonial['rating'];
                $nonrating = 5 - (int)$rating;
                ?>
                 <div class="slide-content swiper-slide">
                     <div class="slide-content-media media">
                        <?php if (!empty($testimonial['id'])): ?>
                            <div class="nav-item">
                                <?php echo wp_get_attachment_image( $testimonial['id'],'full', "", array( "class" => "media-img-auto" ) );  ?>
                            </div>
                        <?php endif; ?>
                        <div class="slide-content media-body">
                            <p class="item-paragraph tcontent"><?php echo wp_kses_post($testimonial['content']); ?></p>
                            <div class="media-body-footer">
                                <h3 class="item-title"><?php echo wp_kses_post($testimonial['title']); ?></h3>
                                <div class="item-subtitle"><?php echo wp_kses_post($testimonial['subtitle']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
    </div>
    <div class="navigation">
        <span class="rt-prev rt-arrow"><span><i class="fas fa-sort-up"></i></span></span>
        <span class="rt-next rt-arrow"><span><i class="fas fa-sort-down"></i></span></span>
    </div>
</div>

