<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$size 				= 'full';
$img 				= wp_get_attachment_image( $data['iconimage']['id'], $size );
$rating  			= $data['rating'];
$nonrating 			= 5 - (int)$rating;

?>
<?php if ($data['alignment']) { ?>
	<div class="testimonial-box left-alignment">
		<div class="media testimonial-img">
		  <?php echo wp_kses_post($img);?>
		  <div class="media-body">
			  <ul class="rating-inline d-inline">
		        <?php foreach (range(1, $rating) as $key): ?>
		          <li class="has-rating"><i class="fa fa-star"></i></li>
		        <?php endforeach; ?>
		        <?php for ($i=1; $i <= $nonrating; $i++): ?>
		          <li class="nonrating"><i class="fa fa-star"></i></li>
		        <?php endfor; ?>
		      </ul>	
				<p class="mt-0 testimonial-text tcontent"><?php echo wp_kses_post( $data['content'] );?></p>
				<h3 class="mb-0 testimonial-title item-title"> <?php echo wp_kses_post( $data['title']);?></h3>
		  </div>
		</div>
	</div>
	<?php } else{ ?>
	<div class="testimonial-box right-alignment">
		<div class="media testimonial-img">	 
		  <div class="media-body">
			<ul class="rating-inline d-inline">
			<?php foreach (range(1, $rating) as $key): ?>
				<li class="has-rating"><i class="fa fa-star"></i></li>
			<?php endforeach; ?>
			<?php for ($i=1; $i <= $nonrating; $i++): ?>
				<li class="nonrating"><i class="fa fa-star"></i></li>
			<?php endfor; ?>
			</ul>	
				<p class="mt-0 testimonial-text"><?php echo wp_kses_post( $data['content'] );?></p>
				<h3 class="mb-0 testimonial-title"> <?php echo wp_kses_post( $data['title']);?></h3>
		  </div>
		   <?php echo wp_kses_post($img);?>
		</div>
	</div>
<?php } ?> 
