<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Group_Control_Image_Size;
$testimonials = array();
foreach ($data['testimonials'] as $testimonial) {
    $testimonials[] = array(
        'id'       => 'testimonial-' . time() . rand(1, 99),
        'image_id'    => $testimonial['image']['id'] ? $testimonial['image']['id'] : "",
        'title'    => $testimonial['title'],
        'subtitle' => $testimonial['subtitle'],
        'content'  => $testimonial['content'],
        'rating'   => $testimonial['rating'],
    );
}

?>

<div class="testimonial-box-layout9-new swiper-container rt-testimonial">
    <div class="slick-carousel-content9 swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
        <?php foreach ($testimonials as $testimonial):
            $rating = $testimonial['rating'];
            $nonrating = 5 - (int)$rating;
            ?>
             <div class="slide-content swiper-slide">
                 <div class="slide-content-media media">
                    <?php if (!empty($testimonial['image_id'])): ?>
                        <div class="nav-item">
                            <?php echo wp_get_attachment_image($testimonial['image_id'],'full');?>
                        </div>
                    <?php endif; ?>
                    <div class="slide-content media-body">
                        <p class="item-paragraph tcontent"><?php echo wp_kses_post($testimonial['content']); ?></p>
                        <div class="media-body-footer">
                            <h3 class="item-title"><?php echo wp_kses_post($testimonial['title']); ?></h3>
                            <div class="item-subtitle"><?php echo wp_kses_post($testimonial['subtitle']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="swiper-pagination"></div>
</div>