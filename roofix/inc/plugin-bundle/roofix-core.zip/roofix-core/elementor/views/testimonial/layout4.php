<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
	use radiustheme\Roofix\Helper;
	$testimonials = array();
		foreach ( $data['testimonials'] as $testimonial ) {
			$testimonials[] = array(
				'id'           		=> 'testimonial-' . time().rand( 1, 99 ),
				'image'        		=> $testimonial['image']['id'] ? $testimonial['image']['id'] : "",
				'title'        		=> $testimonial['title'],
				'subtitle'     		=> $testimonial['subtitle'],
				'content'        	=> $testimonial['content'],
				'rating'   			=> $testimonial['rating'],
			);
		}

?>
<div class="swiper-container rt-testimonial layout4">
	<div class="swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
		<?php foreach ( $testimonials as $testimonial ):
			$rating  		= $testimonial['rating'];
			$nonrating 		= 5 - (int)$rating ;
			?>
				<div class="testimonial-box-layout1 layout-4 swiper-slide">
	            <div class="media media-none--xs">
				<?php if ( !empty( $testimonial['image']) ): ?>
					<div class="item-img">
							<?php echo wp_get_attachment_image($testimonial['image'],'full');?>
					</div>
					<?php endif; ?>
					<div class="media-body">
						<h3 class="item-title"><?php echo wp_kses_post( $testimonial['title'] );?></h3>
						<div class="item-subtitle"><?php echo wp_kses_post( $testimonial['subtitle'] );?></div>
							<ul class="item-rating">
								<?php foreach (range(1, $rating) as $key): ?>
									<li class="has-rating"><i class="fa fa-star"></i></li>
								<?php endforeach; ?>
								<?php for ($i=1; $i <= $nonrating; $i++): ?>
									<li class="nonrating"><i class="fa fa-star"></i></li>
								<?php endfor; ?>
							</ul>
					</div>
	            </div>
	            <p class="tcontent">“ <?php echo wp_kses_post( $testimonial['content'] );?> ”</p>
	        </div>
		<?php endforeach; ?>
	</div>
	<div class="swiper-pagination"></div>
</div>

