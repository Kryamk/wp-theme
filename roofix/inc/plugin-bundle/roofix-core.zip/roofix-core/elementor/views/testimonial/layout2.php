<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
	$testimonials = array();
	foreach ( $data['testimonials'] as $testimonial ) {
		$testimonials[] = array(
			'id'           			=> 'testimonial-' . time().rand( 1, 99 ),
			'image'        		 	=> $testimonial['image']['id'] ? $testimonial['image']['id'] : "",
			'title'        		  	=> $testimonial['title'],
			'subtitle'     			=> $testimonial['subtitle'],
			'content'        		=> $testimonial['content'],
			'rating'   				=> $testimonial['rating'],
		);
	}
	$rating  = $testimonial['rating'];
	$nonrating = 5 - (int)$rating ;
	?>

<div style="display:none;" class="testimonial-box-layout2 swiper-container rt-testimonial">
	<div class="swiper-wrapper" data-carousel-options="<?php echo esc_attr( $data['owl_data'] );?>">
		<?php foreach ( $testimonials as $testimonial ):?>
			<div class="testimonial-box-layout2 swiper-slide">
				<?php if ( !empty( $testimonial['image']) ): ?>
				<div class="item-img">
					<?php echo wp_get_attachment_image($testimonial['image'],'full');?>
				</div>
				<?php endif; ?>
				<div class="item-content">
					<p class="tcontent"> “ <?php echo wp_kses_post( $testimonial['content'] );?> ” </p>
					<?php if($data['rating_display'] == 'yes') { ?>
					<ul class="item-rating">
						<?php foreach (range(1, $rating) as $key): ?>
							<li class="has-rating"><i class="fa fa-star"></i></li>
						<?php endforeach; ?>
						<?php for ($i=1; $i <= $nonrating; $i++): ?>
							<li class="nonrating"><i class="fa fa-star"></i></li>
						<?php endfor; ?>
					</ul>
					<?php } ?>
					<h3 class="item-title"><?php echo wp_kses_post( $testimonial['title'] );?></h3>
					<div class="item-subtitle tcontent"><?php echo wp_kses_post( $testimonial['subtitle'] );?></div>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
    <div class="navigation">
        <span class="rt-prev rt-arrow"><span><i class="fas fa-long-arrow-alt-left"></i></span></span>
        <span class="rt-next rt-arrow"><span><i class="fas fa-long-arrow-alt-right"></i></span></span>
    </div>
</div>