<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use radiustheme\Roofix\Helper;

$testimonials = array();
foreach ($data['testimonials'] as $testimonial) {
    $testimonials[] = array(
        'id'       => 'testimonial-' . time() . rand(1, 99),
        'image'    => $testimonial['image']['url'] ? $testimonial['image']['url'] : "",
        'title'    => $testimonial['title'],
        'subtitle' => $testimonial['subtitle'],
        'content'  => $testimonial['content'],
        'rating'   => $testimonial['rating'],
    );
}

?>
<div class="testimonial-box-layout1-new">
    <div class="testimonial-wrap">
        <div class="testimonial-content">

            <?php foreach ($testimonials as $testimonial):
                $rating = $testimonial['rating'];
                $nonrating = 5 - (int)$rating;
                ?>

                <div class="slide-content">
                    <h3 class="item-title"><?php echo wp_kses_post($testimonial['title']); ?></h3>
                    <div class="item-subtitle"><?php echo wp_kses_post($testimonial['subtitle']); ?></div>

                    <ul class="item-rating">
                        <?php foreach (range(1, $rating) as $key): ?>
                            <li class="has-rating"><i class="fa fa-star"></i></li>
                        <?php endforeach; ?>
                        <?php for ($i = 1; $i <= $nonrating; $i++): ?>
                            <li class="nonrating"><i class="fa fa-star"></i></li>
                        <?php endfor; ?>
                    </ul>

                    <p class="item-paragraph">
                        “ <?php echo wp_kses_post($testimonial['content']); ?> ”
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="testimonial-nav">
            <?php foreach ($testimonials as $testimonial): ?>
                <?php if (!empty($testimonial['image'])): ?>
                    <div class="nav-item">
                        <img src="<?php echo esc_url($testimonial['image']); ?>" class="media-img-auto"
                             alt="<?php echo wp_kses_post($testimonial['title']); ?>">
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>

