<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
	use radiustheme\Roofix\Helper;

	$testimonials = array();
		foreach ( $data['testimonials'] as $testimonial ) {
			$testimonials[] = array(
				'id'           		=> 'testimonial-' . time().rand( 1, 99 ),
				'image'        		=> $testimonial['image']['url'] ? $testimonial['image']['url'] : "",
				'title'        		=> $testimonial['title'],		
				'subtitle'     		=> $testimonial['subtitle'],		
				'content'        	=> $testimonial['content'],
				'rating'   			=> $testimonial['rating'],			
			);
		}

?>

  <div class="testomonial-sec-wrapper v2">                  	
	      <div class="row text-center justify-content-center">
	        <div class="col-xl-10">
	          <!-- Testomonial Slider -->
	           <div class="testimonial-wrap"> 
	          <div class="testomonial-slider-wrapper testomonial-slider-active  ">
	          	<?php foreach ( $testimonials as $testimonial ):		    
					extract($testimonial);
				?>
		            <div class="single-testomonial">
		            	<h2 class="title"><?php echo wp_kses_post( $testimonial['title'] );?></h2>
		              	<p class="text"><?php echo wp_kses_post( $testimonial['content'] );?></p>
		            </div>
					<?php endforeach; ?>
	          </div>
	          <!-- Testomonial Slider end -->
	          <!-- bottom Shape -->
	          <div class="bottom-shape">
	            <span></span>
	          </div>
	        </div>
	        </div>
	        <div class="col-md-5 col-lg-4 col-xl-3  "> 
	        	 <div class="testimonial-wrap"> 
	          <div class="testomonial-slider-nav testomonial-slider-nav-active">
			  
			   <?php foreach ( $testimonials as $testimonial ):		
				extract($testimonial);
				?>

	            <!-- Single Testomonial Nav -->
	            <div class="single-testomonial-nav">
	            	<?php if ( !empty( $testimonial['image']) ): ?>
			       <div class="testomonial-author">         
			           <img src="<?php echo esc_url( $testimonial['image'] );?>" class="media-img-auto" alt="<?php echo wp_kses_post( $testimonial['title'] );?>">
			        </div>
	        	<?php endif; ?>
	        		
	              	<div class="testomonial-author-name">
	                	<h3 class="name"><?php print wp_kses_post( $title ); ?></h3>
		                <span><?php print wp_kses_post( $subtitle ); ?></span>
	              	</div>
	            </div>
	            <?php
				endforeach;
				?>	        
	          </div>	       
	        </div>
	      </div>
	      </div>

 		<div class="testimonial-wrap"> 
	    <!-- Testomonial Slider Nav 2 -->
	    <div class="testomonial-slider-nav2 testomonial-slider-nav2-active">	
		     <?php foreach ( $testimonials as $testimonial ):	
			extract($testimonial);
			?>
			<?php if ( !empty( $testimonial['image']) ):
				$image_src = wp_get_attachment_image_src( $testimonial['id'], 'full' );
				$image_url = $image_src ? $image_src[0] : '';
	 				?>
			       <div class="single-nav">         
			           <img src="<?php echo esc_url( $testimonial['image'] );?>" class="media-img-auto" alt="<?php echo wp_kses_post( $testimonial['title'] );?>">
			        </div>
	        	<?php endif; ?>
		    <?php
			endforeach;
			?>
	    </div>
	  </div>
	  </div>


