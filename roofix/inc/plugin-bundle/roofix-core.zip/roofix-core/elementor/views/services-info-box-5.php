<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr .= 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$title = '<a ' . $attr . '>' . $data['title'] . '</a>';
}
else {
	$title = $data['title'];
}
?>
<div class="benefit-box-layout1">
	<div class="item-content <?php echo esc_attr( $data['design-theme'] );?>">
		<h3 class="item-title"><?php echo wp_kses_post( $title );?> </h3>
		<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
	</div>
</div>

