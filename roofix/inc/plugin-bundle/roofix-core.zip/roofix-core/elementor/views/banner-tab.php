<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;


$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;

$thumb_size         = 'full';
$thumb_icon_size    = 'roofix-size-xs';
$args = array(
    'post_type'      => "{$cpt}_services",
    'posts_per_page' => $data['number'],
    'orderby'        => $data['orderby'],
    'paged' => 1
);

if ( !empty( $data['cat'] ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => "{$cpt}_services_category",
            'field' => 'term_id',
            'terms' => $data['cat'],

        )
    );
}
switch ( $data['orderby'] ) {
    case 'title':
    case 'menu_order':
    $args['order'] = 'ASC';
    break;
}
$query = new WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
?>
<?php if ( $query->have_posts() ) :?>      
        <section class="slick-carousel-wrap slick-slider-wrap-layout1">
            <div class="slick-slider-layout1">
                <?php 
                    $tabs = null;
                    $content= null; 
                        while ( $query->have_posts() ) : $query->the_post();         
                            $post_id = get_the_id();   
                            $bgimgid_holder              = '';  
                            $service_icon                = get_post_meta( $post_id, "{$cpt}_service_icon", true );  
                            $service_image_id            = get_post_meta( $post_id, "{$cpt}_service_image", true );  
                            $service_image_url           = wp_get_attachment_image_src( $service_image_id, $thumb_icon_size, true );                   
                            $_title                      = get_the_title();
                            $_slider_title               = get_post_meta( $post_id, "{$cpt}_slider_title", true );  
                            $_sub_title                  = get_post_meta( $post_id, "{$cpt}_sub_title", true );
                            $short_detail               = get_post_meta( $post_id, "{$cpt}_short_detail", true );
                            $_short_detail               = wp_trim_words( $short_detail, $data['no_of_excerpt_words'] );
                          
                           if ( $service_image_id) {
                             $tabs_icon = '<img class="icon-image non-hover" src=" '.esc_url($service_image_url[0]) .'" alt="">'; 
                           } elseif($service_icon) { 
                               $tabs_icon = '<i class="'.esc_attr($service_icon).'"></i> ';
                           }else{
                                $tabs_icon = get_the_post_thumbnail( $post_id, $thumb_icon_size );  
                           }  
                        if ( $_slider_title == "") {
                           $_slider_title = $_title;
                        }

                ?>   

                <?php    
                $tabs .= '<div class="nav-item">
                    <div class="item-icon">';
                     $tabs .= $tabs_icon;  
                    $tabs .= '</div>
                    <h3 class="item-title">'. $_sub_title.'</h3>
                    
                </div>';
                $content .= '<div class="slick-slider">';        
                    $content .= '<div class="item-img">'.get_the_post_thumbnail( $post_id , $thumb_size, array( 'class' => 'alignleft' ) ).'
                        <div class="item-content">        
                            <div class="big-text">'. $_slider_title .'</div>
                             <p class="short-detail-item-content">'. $_short_detail.'</p>';  

                            if($data['readmore_txt'] ){
                                $content .= '<a href="'. get_the_permalink() .'" class="item-btn" tabindex="0">' . $data['readmore_txt'] . '<i class="fas fa-long-arrow-alt-right"></i></a>'; 
                            }                           

                        $content .= '</div>
                    </div>            
                </div>'; ?>
            <?php endwhile; ?>
            <?php if ($data['services_nav'] == 'style1') { ?>
               <div class="slick-nav-wrap">
                    <div class="container">
                        <div class="slick-carousel-new slick-nav slick-carousel-nav"><?php echo wp_kses_post( $tabs ); ?></div>
                    </div>
                </div>
               <div class="slick-carousel-new slick-content slick-carousel-content"><?php echo wp_kses_post( $content ); ?></div>
               <?php }else{ ?>
               <div class="slick-carousel-new slick-content slick-carousel-content"><?php echo wp_kses_post( $content ); ?></div>
                 <div class="slick-nav-wrap">
                    <div class="container">
                        <div class="slick-carousel-new slick-nav slick-carousel-nav"><?php echo wp_kses_post( $tabs ); ?></div>
                    </div>
                </div>
               <?php } ?>
            <?php endif;?>      
            </div>
        </section>       
    <?php Helper::wp_reset_temp_query( $temp );?>