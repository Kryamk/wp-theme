<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$prefix      = ROOFIX_CORE_THEME;
$cpt         = ROOFIX_CORE_CPT;
$thumb_size  = 'roofix-size-3';

$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}
extract( $data );
$args = array(
	'post_type'        	=> "{$cpt}_projects",
	'posts_per_page'   	=> $data['number'],
	'suppress_filters' 	=> false,
	'orderby'          	=> $data['orderby'],
	'paged'          	  => $paged,
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$bool = isset($data['category_list']);
$bool = $bool && is_array($data['category_list']);
$bool = $bool && count($data['category_list']) ;
if ($bool) {
  $args['tax_query'] = array(
    array(
      'taxonomy' 					=> "{$cpt}_projects_category",
      'terms' 						=> $data['category_list'], // Where term_id of Term 1 is "1".
      'include_children'	=> false
    )
  );
}
$query = new \WP_Query( $args );
$temp = Helper::wp_set_temp_query( $query );
$project 	= array();
while( $query->have_posts() ){
	$query->the_post();
	$post             = get_post();
	$cats_comma       = array();
  $img              = get_the_post_thumbnail_url( $post, $thumb_size );
  $image_id 				= get_post_thumbnail_id($post);
	if ( !$img ) {
			if( !empty( RDTheme::$options['no_preview_image']['id'] ) ) {
				$img = wp_get_attachment_image_src( RDTheme::$options['no_preview_image']['id'], $thumb_size, true );
				$img = $img[0];
			}
			else {
				$img  = Helper::get_img( 'noimage_500x400.jpg' );
			}
		}
	$project[] = array(
		'img'        	=> $img,
		'alt' 			 	=> Helper::roofix_get_attachment_alt($image_id),
		'title'      	=> $post->post_title,
		'url'        	=> get_the_permalink( $post ),
		'postID'     	=> $post->ID,
		'excerpt'   	=> Helper::roofix_generate_excerpt( $post, $no_of_excerpt_words ),
    'link_text' 	=> $url_text

	);
}

$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
?>
<div class="rt-el-projects-3">
	<div class="row">
		<?php foreach ( $project as $project_each ): ?>
				<div class="<?php echo esc_attr( $col_class);?>">
					<div class="project-box-layout2">
					    <div class="item-img">
					         <?php echo get_the_post_thumbnail($project_each['postID'],$thumb_size);?>
					    </div>
						    <div class="item-content">
						        <div class="item-heading">
												<?php if( $title_style == 'yes'){ ?>
												<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <a href="<?php echo esc_url( $project_each['url'] );?>"><?php echo esc_html( $project_each['title'] );?></a> </<?php echo esc_html( $data['title_tag'] );?>>
												<?php  }else{ ?>
														<h3 class="item-title"><a href="<?php echo esc_url( $project_each['url'] );?>"><?php echo esc_html( $project_each['title'] );?></a></h3>
												<?php  } ?>
												<?php if( $category_display == 'yes'){ ?>
														<div class="item-subtitle"><?php echo Helper::rt_get_projects_cat($project_each['postID']); ?></div>
												<?php } ?>
						        </div>
										<?php if( $btn_display == 'yes'){ ?>
												<?php if( $button_type == '1'){ ?>
													<div class="item-btn-wrap">
													   <a href="<?php echo esc_url( $project_each['url'] );?>" class="item-btn">
													   <i class="fas fa-plus"></i>
													 </a>
													</div>
												<?php  }else{ ?>
													<div class="item-btn-wrap">
															<?php  if ($data['button_icon_position'] == 'after') { ?>
															<a href="<?php echo esc_url( $project_each['url'] );?>" class="item-btn after">
																<?php echo esc_attr( $data['url_text'] );?>
																	<?php if( $data['btn_display_icon'] == 'yes'){ ?>
																	 	<i class="fas <?php echo esc_attr( $data['button_icon'] );?>"></i>
																	<?php } ?>
																</a>
															<?php
															} else { ?>
															<a href="<?php echo esc_url( $project_each['url'] );?>" class="item-btn before">
																<?php if( $data['btn_display_icon'] == 'yes'){ ?>
																	<i class="fas <?php echo esc_attr( $data['button_icon'] );?>"></i>
																<?php } ?>
															 <?php echo esc_attr( $data['url_text'] );?>

															</a>
															<?php
															} ?>
													</div>
											<?php  } ?>
									<?php  } ?>
						    </div>
						</div>
					</div>
				<?php endforeach;?>
			 <?php if ( $pagination_display == 'yes' ): ?>
					<?php Helper::pagination();?>
			<?php endif ?>
		</div>
		  <?php Helper::wp_reset_temp_query( $temp ); ?>
		</div>
