<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$thumb_size 			 = 'roofix-size-blog1';
extract($data);
$args = array(
	'posts_per_page' => $data['number'],
	'category_name'  => !empty($data['cat']) && is_array($data['cat']) ? implode(',', $data['cat']) : '',
	'orderby'        => $data['orderby'],
);
switch ( $data['orderby'] ) {
	case 'title':
	case 'menu_order':
	$args['order'] = 'ASC';
	break;
}
$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>
<div class="lodemoredat rt-infinity-scroll rt-el-blgo-post row" data-edata="<?php echo htmlspecialchars( wp_json_encode( $data ) );?>"  data-addondata="<?php echo htmlspecialchars( wp_json_encode( $args ) );?>">						
<?php if ( $query->have_posts() ) :		
	?>
	<?php while ( $query->have_posts() ) : $query->the_post();	
		$post_id = get_the_ID();		
		$content = Helper::get_current_post_content();
		$content = wp_trim_words( $content, $data['count'] );
		$content = "<p class='item-content-p'>$content</p>";			
		?>					
			<div class=" rtin-item post-each <?php echo esc_attr( $col_class );?>">	
				<div class="blog-box-layout1 blog-box-wrp">				   
						<?php if ( has_post_thumbnail() ){?>
					    <div class="item-img">	
							<a href="<?php the_permalink();?>">
									<?php the_post_thumbnail( $thumb_size ); ?>
							</a>
							<?php if ( $data['meta']  == 'yes' ): ?>							 
								<?php if ( RDTheme::$options['blog_date'] ): ?>
									<div class="top-item">
										<div class="item-date">
											<?php 
											$date = strtotime( get_the_date() );
											$day  = date( 'j', $date );
											$month  = date( 'M', $date );
											 ?>
										<span class="days"><?php echo esc_attr($day) ?></span>
										<span class="month"><?php echo esc_attr($month) ?></span>
										</div>
									</div>
								<?php endif; ?>		
						<?php endif ?>
						</div>
					<?php } ?>
				    <div class="item-content">
			    		<?php if ( $data['show_category']  == 'yes' ): ?>		
			         		<?php Helper::roofix_category_prepare();?>			
			        <?php endif ?>	  
						<<?php echo esc_html( $data['title_tag'] );?> class="item-title">
						<a href="<?php the_permalink();?>"><?php the_title();?></a>
						</<?php echo esc_html( $data['title_tag'] );?>> 
							<?php if ( $data['show_content']  == 'yes' ): ?>			
								<?php echo wp_kses_post( $content );?>
							<?php endif ?>	
						<?php
						echo Helper::rt_get_post_meta($data, $post_id );
					?>
					</div>
				</div>
   			</div>	
		<?php 
		endwhile;		
		endif;?>
	<?php Helper::wp_reset_temp_query( $temp );?>		
</div>

