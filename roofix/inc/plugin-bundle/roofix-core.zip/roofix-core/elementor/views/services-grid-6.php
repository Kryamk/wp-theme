<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use \WP_Query;
use radiustheme\Roofix\RDTheme;
use radiustheme\Roofix\Helper;
$prefix             = ROOFIX_CORE_THEME;
$cpt                = ROOFIX_CORE_CPT;

$thumb_size         = "roofix-size-blog3";
$thumb_icon_size    = 'roofix-size-xs';
extract( $data );

$paged = 1;
if ( get_query_var('paged') ) {
  $paged = get_query_var('paged');
} else if ( get_query_var('page') ) {
  $paged = get_query_var('page');
}

$args = array(
    'post_type'      => "{$cpt}_services",
    'posts_per_page' => $data['number'],
    'orderby'        => $data['orderby'],
    'paged'          =>  $paged
);
if ( !empty( $data['cat'] ) ) {
    $args['tax_query'] = array(
        array(
            'taxonomy' => "{$cpt}_services_category",
            'field' => 'term_id',
            'terms' => $data['cat'],
        )
    );
}
switch ( $data['orderby'] ) {
    case 'title':
    case 'menu_order':
    $args['order'] = 'ASC';
    break;
}

$query = new WP_Query( $args );
$col_class = "col-lg-{$data['col_lg']} col-md-{$data['col_md']} col-sm-{$data['col_sm']} col-{$data['col_xs']}";
$temp = Helper::wp_set_temp_query( $query );
?>

<div class="service-box-area">  
  <div class="row">    
  <?php if ( $query->have_posts() ) : 
     while ( $query->have_posts() ) : $query->the_post();   
      $post_id          = get_the_id(); 
      $content = "";     
    if ( !empty( $data['services_content'] ) ): 
      $content      = Helper::get_current_post_content();
      $content      = wp_trim_words( $content, $data['count'] );
      $content      = "<p>$content</p>";
    endif;
      $service_icon                = get_post_meta( $post_id, "{$cpt}_service_icon", true );  
      $service_image_id            = get_post_meta( $post_id, "{$cpt}_service_image", true ); 
      $service_image_url           = wp_get_attachment_image_src( $service_image_id, $thumb_icon_size, true );
    if ( $service_image_id) {
      $tabs_icon                   = '<img class="icon-image non-hover" src=" '.esc_url($service_image_url[0]) .'" alt="">'; 
    } elseif($service_icon) { 
      $tabs_icon                   = '<i class="'.esc_attr($service_icon).'"></i> ';
    }else{
      $tabs_icon                   = get_the_post_thumbnail( $post_id, $thumb_icon_size );  
    }
    ?>      

 <div class="rtin-item <?php echo esc_attr( $col_class );?>">
    <div class="service-box-layout6-new">          
          <?php if ( has_post_thumbnail() ){ ?>   
            <div class="item-img">
               <?php  the_post_thumbnail( $thumb_size ); ?>      
            </div>
          <?php } ?>          
            <div class="item-content">
              <?php if ( !empty( $data['services_imgover_icon'] ) ): ?>
                <div class="item-icon">
                  <?php  echo wp_kses_post( $tabs_icon ); ?>
                </div>
              <?php endif; ?> 
                <div class="svg-content">                 
                  <svg class="top-svg"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="374px" height="63px">
                  <path fill-rule="evenodd" 
                  d="M0.000,13.000 C0.000,13.000 72.000,77.250 159.000,59.000 C246.000,40.750 324.750,14.750 370.000,30.000 L370.000,19.000 C370.000,19.000 355.000,-4.750 164.000,47.000 C164.000,47.000 73.250,71.000 0.000,-0.000 L0.000,13.000 Z"/>
                  </svg>
                  <svg class="bottom-svg"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="374px" height="63px">
                  <path fill-rule="evenodd" 
                  d="M0.000,13.000 C0.000,13.000 72.000,77.250 159.000,59.000 C246.000,40.750 324.750,14.750 370.000,30.000 L370.000,19.000 C370.000,19.000 355.000,-4.750 164.000,47.000 C164.000,47.000 73.250,71.000 0.000,-0.000 L0.000,13.000 Z"/>
                  </svg>
                  <svg class="bottom-svgw"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                  width="374px" height="57px">
                  <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                  d="M0.000,0.000 C0.000,0.000 58.000,66.000 150.000,51.000 C150.000,51.000 325.000,1.667 370.000,21.000 L370.000,57.000 L0.000,57.000 "/>
                  </svg>
                </div>
                <h3 class="item-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>                
                  <?php  if ($data['title_style'] == 'yes') { ?>
                    <div class="title-style"></div>       
                  <?php } ?>
                <?php if ( !empty( $data['services_content'] ) ): ?>
                    <?php echo wp_kses_post( $content );?>
                <?php endif; ?>                 
                 <?php if ( !empty( $data['services_btn'] ) ): ?>
                  <div class="details-link">
                    <a href="<?php the_permalink();?>" class="details-ghost-btn-svr hover-btn"><span><?php echo esc_attr($data['buttontext']); ?></span></a>
                </div>
                <?php endif; ?> 
            </div>        
        </div>
      </div>
    <?php endwhile;?>
    <?php if ( $pagination_display == 'yes' ): ?>
          <?php Helper::pagination();?>
      <?php endif ?>     
  <?php endif;?>
  <?php Helper::wp_reset_temp_query( $temp );?> 
  </div>
</div>