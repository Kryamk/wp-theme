<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
$attr = '';
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
$img = wp_get_attachment_image( $data['image']['id'], $data['image_size_size'] );
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$getimg = '<a ' . $attr . '>' . $img  . '</a>';
}else{
	$getimg = $img;
}

?>
<div class="image-box-layout8">
	<div class="item-box">
		<?php echo wp_kses_post( $getimg );?>
		<div class="call-info">
			<div class="icon-box"><i class="fas fa-phone-alt"></i></div>
			<div class="content-wrap">
				<span class="info-text"><?php echo esc_attr( $data['pho_text'] );?></span>
				<span class="info-no"><a href="tel:<?php echo esc_attr( $data['pho_number'] );?>"><?php echo esc_attr( $data['pho_number'] );?></a></span>
			</div>
		</div>
	</div>
</div>
