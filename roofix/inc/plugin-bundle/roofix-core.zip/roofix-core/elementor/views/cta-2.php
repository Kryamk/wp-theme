<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
$btn = $attr = '';
extract( $data );
    if ( !empty( $data['buttonurl']['url'] ) ) {
        $attr  = 'href="' . $data['buttonurl']['url'] . '"';
        $attr .= !empty( $data['buttonurl']['is_external'] ) ? ' target="_blank"' : '';
        $attr .= !empty( $data['buttonurl']['nofollow'] ) ? ' rel="nofollow"' : '';        
    }
    if ( !empty( $data['buttontext'] ) ) {
        $btn = '<a class="btn-fill-xl box-shadow bg-textprimary text-accent" ' . $attr . '>' . $data['buttontext'] . '<i class="fas fa-angle-right"></i></a>';
    }
?>
 <?php switch ( $data['icon-alignment'] ) {
    case 'left': ?>
        <div class="row align-items-center">
            <div class="col-lg-9 col-12">
                <div class="action-box-layout1">
                    <?php if ( $subtitle ): ?>
                        <span class="item-sub-title"><?php echo wp_kses_post( $subtitle);?></span>
                    <?php endif; ?> 
                    <?php if ( $title ): ?>
                         <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
                    <?php endif; ?> 
                </div>
            </div>
            <div class="col-lg-3 col-12 d-flex justify-content-lg-end justify-content-center">
                <div class="action-box-layout1">
                    <?php if ( $btn ): ?>
                        <?php echo wp_kses_post( $btn );?>      
                    <?php endif; ?>           
                </div>
            </div>
        </div>    
    <?php 
    break;
    case 'center': ?>
        <div class="row align-items-center">
            <div class="col-12 text-center">
                <div class="action-box-layout1">
                    <?php if ( $subtitle ): ?>
                        <span class="item-sub-title"><?php echo wp_kses_post( $subtitle);?></span>
                    <?php endif; ?> 
                    <?php if ( $title ): ?>
                         <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
                    <?php endif; ?> 
                </div>
                <div class="justify-content-center">
                    <div class="action-box-layout1">
                        <?php if ( $btn ): ?>
                            <?php echo wp_kses_post( $btn );?>      
                        <?php endif; ?>           
                    </div>
                </div>
             </div>
        </div>    
    <?php 
    break;      
    case 'right': ?>
        <div class="row align-items-center">
            <div class="col-lg-3 col-12 text-left">
                <div class="action-box-layout1">
                    <?php if ( $btn ): ?>
                        <?php echo wp_kses_post( $btn );?>      
                    <?php endif; ?>           
                </div>
            </div>
            <div class="col-lg-9 col-12">
                <div class="action-box-layout1 text-right">
                    <?php if ( $subtitle ): ?>
                        <span class="item-sub-title"><?php echo wp_kses_post( $subtitle);?></span>
                    <?php endif; ?> 
                    <?php if ( $title ): ?>
                         <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
                    <?php endif; ?> 
                </div>
            </div>            
        </div> 
    <?php 
    break;          
    default: ?>
        <div class="row align-items-center">
            <div class="col-lg-9 col-12">
                <div class="action-box-layout1">
                    <?php if ( $subtitle ): ?>
                        <span class="item-sub-title"><?php echo wp_kses_post( $subtitle);?></span>
                    <?php endif; ?> 
                    <?php if ( $title ): ?>
                         <h2 class="item-title"><?php echo wp_kses_post( $title);?></h2>
                    <?php endif; ?> 
                </div>
            </div>
            <div class="col-lg-3 col-12 d-flex justify-content-lg-end justify-content-center">
                <div class="action-box-layout1">
                    <?php if ( $btn ): ?>
                        <?php echo wp_kses_post( $btn );?>      
                    <?php endif; ?>           
                </div>
            </div>
        </div>   
    <?php 
    break;
    }
?>