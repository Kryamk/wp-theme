<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use radiustheme\Roofix\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;

extract($data);
$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	$title = '<a ' . $attr . '>' . $data['title'] . '</a>';
}
else {
	$title = $data['title'];
}

if ( $attr ) {
  $getimg = '<a ' . $attr . '>' .Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size' , 'icon_image' ).'</a>';
}
else {
	$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'icon_image' );
}

$final_icon_class       = " fas fa-thumbs-up";
$final_icon_image_url   = '';
if ( is_string( $icon_class['value'] ) && $dynamic_icon_class =  $icon_class['value']  ) {
  $final_icon_class     = $dynamic_icon_class;
}
if ( is_array( $icon_class['value'] ) ) {
  $final_icon_image_url = $icon_class['value']['url'];
}


		switch ( $data['icon-alignment'] ) {
				case 'left': ?>
					<div class="service-box-layout2 left">
						<div class="media service-box-media">
							<div class="item-icon <?php echo esc_html( $data['icon_layout'] );?>">	
								<?php if ( !empty( $data['icontype']== 'image' ) ) { ?>		            
											<?php echo wp_kses_post($getimg);?>  
									<?php }else{?> 	
										<?php if ( $final_icon_image_url ): ?>
												<img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
										<?php else: ?>
												<i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
										<?php endif ?>
								<?php }  ?>
						    </div>
							<div class="media-body media-body-wrp">
							<<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $title );?> </<?php echo esc_html( $data['title_tag'] );?>>
									<?php  if ($data['title_style']) { ?>
										<div class="title-style"></div>				
									<?php } ?>
							<?php  if ($data['content']) { ?>
								<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
							<?php } ?>             
							</div>
						</div>  
					</div>
				<?php 
				break;
				case 'center': ?>
						<div class="service-box-layout2 center">
						  <div class="service-box-media">
								<div class="item-icon <?php echo esc_html( $data['icon_layout'] );?>">			
									<?php if ( !empty( $data['icontype']== 'image' ) ) { ?>		            
													<?php echo wp_kses_post($getimg);?>  
											<?php }else{?> 	
												<?php if ( $final_icon_image_url ): ?>
														<img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
												<?php else: ?>
														<i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
												<?php endif ?>
									<?php }  ?>
								</div>
						      <div class="media-body-wrp">
						      	 <<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $title );?> </<?php echo esc_html( $data['title_tag'] );?>>
											<?php  if ($data['title_style']) { ?>
													<div class="title-style"></div>				
											<?php } ?>
										<?php  if ($data['content']) { ?>
											<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
										<?php } ?>             
						      </div>
						 </div>  
						</div>
				<?php 
				break;		
				case 'right': ?>
					<div class="service-box-layout2 right">
					  <div class="media service-box-media">
					  	 <div class="media-body media-body-wrp">
					      	 <<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $title );?> </<?php echo esc_html( $data['title_tag'] );?>>
										<?php  if ($data['title_style']) { ?>
											<div class="title-style"></div>				
										<?php } ?>
									<?php  if ($data['content']) { ?>
										<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
									<?php } ?>             
					      </div>
							<div class="item-icon <?php echo esc_html( $data['icon_layout'] );?>">			
									<?php if ( !empty( $data['icontype']== 'image' ) ) { ?>		            
													<?php echo wp_kses_post($getimg);?>  
											<?php }else{?> 	
												<?php if ( $final_icon_image_url ): ?>
														<img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
												<?php else: ?>
														<i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
												<?php endif ?>
									<?php }  ?>
								</div>					     
					 </div>  
					</div>
				<?php 
				break;			
				default: ?>
					<div class="service-box-layout2">
					  <div class="media">
							<div class="item-icon <?php echo esc_html( $data['icon_layout'] );?>">			
							<?php if ( !empty( $data['icontype']== 'image' ) ) { ?>		            
											<?php echo wp_kses_post($getimg);?>  
									<?php }else{?> 	
										<?php if ( $final_icon_image_url ): ?>
												<img src="<?php echo esc_url( $final_icon_image_url ); ?>" alt="SVG Icon">
										<?php else: ?>
												<i class="<?php  echo esc_attr( $final_icon_class ); ?>"></i>
										<?php endif ?>
							<?php }  ?>

						</div>
					      <div class="media-body">
					      	 <<?php echo esc_html( $data['title_tag'] );?> class="item-title"> <?php echo wp_kses_post( $title );?> </<?php echo esc_html( $data['title_tag'] );?>>
										<?php  if ($data['title_style']) { ?>
												<div class="title-style"></div>				
										<?php } ?>
									<?php  if ($data['content']) { ?>
										<p class="item-content"><?php echo wp_kses_post( $data['content'] );?></p>
									<?php } ?>             
					      </div>
					 </div>  
					</div>
				<?php 
				break;
		}
?>

