<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Insurex_Core;
use InsurexTheme_Helper;
use Elementor\Icons_Manager;
use Elementor\Utils;
extract($data);

$thumb_size = 'insurex-size1';

?>
<div class="rtin-insurance-tab">
	<div class="feature-tab-layout">
		<div class="tab-content">
			<?php $i = 1;
			foreach ( $data['tab_items'] as $tab_item_list ) { ?>
			<div class="tab-pane fade <?php if ( $i == 1 ) { ?>active<?php } ?> show" id="nav-<?php echo esc_html( $i ); ?>">
				<div class="rtin-item">
					<div class="rtin-img"><?php echo wp_get_attachment_image( $tab_item_list['image']['id'], $thumb_size );?></div>
					<div class="rtin-content">
						<div class="rtin-text">
						<div>
							<h3 class="rtin-title"><?php echo wp_kses_post( $tab_item_list['title'] ); ?></h3>
							<?php echo wp_kses_post( $tab_item_list['content'] ); ?>
							<a class="insur-tab-more" href="<?php echo esc_url( $tab_item_list['url']['url'] );?>"><i class="fas fa-calculator"></i><span><?php echo esc_html( $tab_item_list['buttontext'] );?></span><i class="fas fa-angle-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php $i++; } ?>
		</div>		
		<ul class="nav nav-tabs tab-nav-list">
		<?php $i = 1;
	    foreach ( $data['tab_items'] as $tab_item_list ) { ?>
			<li class="nav-item"><a class="<?php if ( $i == 1 ) { ?>active<?php } ?>" href="#nav-<?php echo esc_html( $i ); ?>" data-toggle="tab" aria-expanded="false"><?php if( !empty($tab_item_list['icon_class']) ) { ?><?php Icons_Manager::render_icon( $tab_item_list['icon_class'], [ 'aria-hidden' => 'true' ] ); ?><?php } ?>
				<span><?php echo wp_kses_post( $tab_item_list['title'] ); ?></span></a>
			</li>
			<?php $i++; } ?>
		</ul>
	</div>
</div>

