<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
if ( ! defined( 'ABSPATH' ) ) exit;
class Blog_Post extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name =esc_html__( 'Blog Posts', 'roofix-core' );
		$this->rt_base = 'rt-blog-post';
		$this->rt_translate = array(
			'cols'  => array(
				'12' =>esc_html__( '1 Col', 'roofix-core' ),
				'6'  =>esc_html__( '2 Col', 'roofix-core' ),
				'4'  =>esc_html__( '3 Col', 'roofix-core' ),
				'3'  =>esc_html__( '4 Col', 'roofix-core' ),
				'2'  =>esc_html__( '6 Col', 'roofix-core' ),
			),
		);
		parent::__construct( $data, $args );
	}


  private function rt_cat_dropdown() {  

   $terms = get_terms( [
     'taxonomy' => "category",
     'hide_empty' => true,
   ]);

   $category_dropdown = [];
   foreach ( $terms as $category ) {
     $category_dropdown[$category->slug] = $category->name;
   }
   return $category_dropdown;
 }


	public function rt_fields(){

		$categories = get_categories();

		foreach ( $categories as $category ) {
			$category_dropdown[$category->slug] = $category->name;
		}


		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_Layout',
				'label'   =>esc_html__( 'Layout', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'style',
					'label'   =>esc_html__( 'Layout', 'roofix-core' ),
					'options' => array(
						'style1' =>esc_html__( 'Style 1', 'roofix-core' ),
						'style2' =>esc_html__( 'Style 2', 'roofix-core' ),					
						'style3' =>esc_html__( 'Style 3', 'roofix-core' ),					
						'style4' =>esc_html__( 'Style 4', 'roofix-core' ),					
						'style5' =>esc_html__( 'Style 5', 'roofix-core' ),					
						'style6' =>esc_html__( 'Style 6', 'roofix-core' ),					
										
					),
					'default' => 'style1',
				),
		array(
				'mode' => 'section_end',
			),		

		array(
			'mode'    => 'section_start',
			'id'      => 'sec_qurey',
			'label'   =>esc_html__( 'Qurey', 'roofix-core' ),
		),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'cat',
					'label'   => esc_html__( 'Categories', 'roofix-core' ),
					'options' => $category_dropdown,
					'default' => '0',
					
					'multiple' => true,
				),
				array(
					'type'    			=> Controls_Manager::SELECT2,
					'id'      			=> 'orderby',
					'label'   			=> esc_html__( 'Order By', 'roofix-core' ),
					'options' 			=> array(
						'date'        => esc_html__( 'Date (Recents comes first)', 'roofix-core' ),
						'title'       => esc_html__( 'Title', 'roofix-core' ),
						'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'roofix-core' ),
					),
					'default' 			=> 'date',
				),
				array(
					'type'    		=> Controls_Manager::NUMBER,
					'id'      		=> 'number',
					'label'   		=> esc_html__( 'Total number of posts', 'roofix-core' ),
					'default' 		=> 5,
					'description' => esc_html__( 'Write -1 to show all', 'roofix-core' ),
				),
				array(
					'type'        => Controls_Manager::SWITCHER,
					'id'          => 'show_content',
					'label'       =>esc_html__( 'Post short Content ', 'roofix-core' ),
					'label_on'    =>esc_html__( 'On', 'roofix-core' ),
					'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
					'default'     => 'no',
					'description' =>esc_html__( 'Show or Hide short Content. Default: On', 'roofix-core' ),
					'condition'   => array( 'style' => array( 'style1','style3','style4','style5')),
				),
				array(
					'type'        => Controls_Manager::SWITCHER,
					'id'          => 'show_category',
					'label'       =>esc_html__( 'Post Category ', 'roofix-core' ),
					'label_on'    =>esc_html__( 'On', 'roofix-core' ),
					'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
					'default'     => 'yes',
					'description' =>esc_html__( 'Show or Hide short Category. Default: On', 'roofix-core' ),
					'condition'   => array( 'style' => array( 'style1' ,'style2')),
				),
				array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'count',
				'label'   =>esc_html__( 'Word count', 'roofix-core' ),
				'default' => 18,
				'description' =>esc_html__( 'Maximum number of words', 'roofix-core' ),
				'condition'   => array( 'show_content' => array( 'yes')),
				),
				array(
					'type'        => Controls_Manager::SWITCHER,
					'id'          => 'meta',
					'label'       =>esc_html__( 'Post Meta', 'roofix-core' ),
					'label_on'    =>esc_html__( 'On', 'roofix-core' ),
					'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
					'default'     => 'yes',
					'description' =>esc_html__( 'Show or Hide Date and Comment Counts. Default: On', 'roofix-core' ),
				),	
				array(
					'type'  => Controls_Manager::TEXT,
					'id'    => 'url_text',
					'label' => esc_html__( 'Botton Text (Optional)', 'roofix-core' ),
					'default' => esc_html__( 'Read More', 'roofix-core' ),	
					'condition'   => array( 'style' => array( 'style5' ,'style6')),			
				),	
			array(
				'mode' => 'section_end',
			),				
			
			// Responsive Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   =>esc_html__( 'Number of Responsive Columns', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'col_lg',
					'label'   =>esc_html__( 'Desktops: > 1199px', 'roofix-core' ),
					'options' => $this->rt_translate['cols'],
					'default' => '4',
				),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'col_md',
					'label'   =>esc_html__( 'Desktops: > 991px', 'roofix-core' ),
					'options' => $this->rt_translate['cols'],
					'default' => '4',
				),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'col_sm',
					'label'   =>esc_html__( 'Tablets: > 767px', 'roofix-core' ),
					'options' => $this->rt_translate['cols'],
					'default' => '6',
				),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'col_xs',
					'label'   =>esc_html__( 'Phones: < 768px', 'roofix-core' ),
					'options' => $this->rt_translate['cols'],
					'default' => '12',
				),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'col_mobile',
					'label'   =>esc_html__( 'Small Phones: < 480px', 'roofix-core' ),
					'options' => $this->rt_translate['cols'],
					'default' => '12',
				),
			array(
				'mode' => 'section_end',
			),

		// Title style
		array(
		    'mode'    => 'section_start',
		    'id'      => 'blog_post_title_style',
		    'label'   => esc_html__( 'Title Style', 'roofix-core' ),
		    'tab'     => Controls_Manager::TAB_STYLE,
		),      
			array(
			    'type'    => Controls_Manager::CHOOSE,
			    'id'      => 'title_tag',
			    'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
			    'options' => array(
			        'h1'  => [
			            'title' => esc_html__( 'H1', 'roofix-core' ),
			            'icon' => 'eicon-editor-h1'
			        ],
			        'h2'  => [
			            'title' => esc_html__( 'H2', 'roofix-core' ),
			            'icon' => 'eicon-editor-h2'
			        ],
			        'h3'  => [
			            'title' => esc_html__( 'H3', 'roofix-core' ),
			            'icon' => 'eicon-editor-h3'
			        ],
			        'h4'  => [
			            'title' => esc_html__( 'H4', 'roofix-core' ),
			            'icon' => 'eicon-editor-h4'
			        ],
			        'h5'  => [
			            'title' => esc_html__( 'H5', 'roofix-core' ),
			            'icon' => 'eicon-editor-h5'
			        ],
			        'h6'  => [
			            'title' => esc_html__( 'H6', 'roofix-core' ),
			            'icon' => 'eicon-editor-h6'
			        ],
			        'div'  => [
			            'title' => esc_html__( 'div', 'roofix-core' ),
			            'icon' => 'eicon-font'
			        ]
			    ),
			    'default' => 'h3',
			    
			),
			array(
			    'type'    	=> Controls_Manager::COLOR,
			    'id'      	=> 'title_color',
			    'label'   	=> esc_html__( 'Color', 'roofix-core' ),
			    'default' 	=> '',                       
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-title a' => 'color: {{VALUE}}',      
			        ),
			),  
			array(
			    'type'    	=> Controls_Manager::COLOR,
			    'id'      	=> 'title_hover_color',
			    'label'   	=> esc_html__( 'Hover Color', 'roofix-core' ),
			    'default' 	=> '',                       
			    'selectors' => array(
			         '{{WRAPPER}} .blog-box-wrp .item-title a:hover' => 'color: {{VALUE}}',    
			    ),
			),  
			array( 
			    'mode'      => 'group',
			    'type'      => Group_Control_Typography::get_type(),
			    'name'      => 'title_font_size',                
			    'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
			    'selector'  =>'{{WRAPPER}} .blog-box-wrp .item-title',
			),
			array(
			    'type'    => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'id'      => 'title_padding',
			    'label'   => esc_html__( 'Padding', 'roofix-core' ),
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
			                           
			    ),
			    'separator' => 'before',
			),  
			array(
			    'type'    => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'id'      => 'title_margin',
			    'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
			    ),
			    'separator' => 'before',
			),  
				
				
			array(

			'mode' => 'section_end',
			),

			// Content style
			array(
			    'mode'    => 'section_start',
			    'id'      => 'blog_post_content_style',
			    'label'   => esc_html__( 'Content Style', 'roofix-core' ),
			    'tab'     => Controls_Manager::TAB_STYLE,
			    'condition'   => array('style' => array( 'style1', 'style3', 'style4' ) ),
			),  
			array(
			    'type'    	=> Controls_Manager::COLOR,
			    'id'      	=> 'content_color',
			    'label'   	=> esc_html__( 'Color', 'roofix-core' ),
			    'default' 	=> '',                       
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-content-p' => 'color: {{VALUE}}',      
			        ),
			),  
			array( 
			    'mode'      => 'group',
			    'type'      => Group_Control_Typography::get_type(),
			    'name'      => 'content_font_size',                
			    'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
			    'selector'  =>'{{WRAPPER}} .blog-box-wrp .item-content-p',
			),
			array(
			    'type'    => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'id'      => 'content_padding',
			    'label'   => esc_html__( 'Padding', 'roofix-core' ),
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-content-p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
			                           
			    ),
			    'separator' => 'before',
			),  
			array(
			    'type'    => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'id'      => 'content_margin',
			    'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
			    'selectors' => array(
			        '{{WRAPPER}} .blog-box-wrp .item-content-p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
			    ),
			    'separator' => 'before',
			),  
				
				
		array(

		'mode' => 'section_end',
		),
		
		);
		return $fields;
	}
	protected function render() {	
	$data = $this->get_settings();	
		switch ( $data['style'] ) {
			case 'style2':
				$template = 'blog-post-2';			
			break;
			case 'style3':
				$template = 'blog-post-3';			
			break;
			case 'style4':
				$template = 'blog-post-4';			
			break;	
			case 'style5':
				$template = 'blog-post-5';			
			break;	
			case 'style6':
				$template = 'blog-post-6';			
			break;			
			default:
				$template = 'blog-post-1';
			break;
		}
		return $this->rt_template( $template, $data );
	}
}