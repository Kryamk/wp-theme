<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;
class Logo_Slider extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Logo Grid & Slider', 'roofix-core' );
		$this->rt_base = 'rt-logo-slider';
		$this->rt_translate = array(
			'cols'  => array(
				'1'  => esc_html__( '1 Col', 'roofix-core' ),
				'2'  => esc_html__( '2 Col', 'roofix-core' ),
				'3'  => esc_html__( '3 Col', 'roofix-core' ),
				'4'  => esc_html__( '4 Col', 'roofix-core' ),
				'6'  => esc_html__( '6 Col', 'roofix-core' ),
			),
		);
		parent::__construct( $data, $args );
	}

	public function rt_fields(){

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
				'label'   => esc_html__( 'Image', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'url',
            [
                'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'URL(optional)', 'roofix-core' ),
            ]
        );

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),
			),
				array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'default' => 'Lorem Ipsum',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
				'options' => array(
					'logoslider1' 		 => esc_html__( 'Grid', 'roofix-core' ),
					'logoslider2' => esc_html__( 'Carousel 2', 'roofix-core' ),
				),
				'default' => 'logoslider1',
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'logos',
				'label'   => esc_html__( 'Add as many logos as you want', 'roofix-core' ),
				'fields'  => $repeater->get_controls(),
			),
			array(
				'mode' => 'section_end',
			),

			// Responsive Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   => esc_html__( 'Number of Responsive Columns', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_lg',
				'label'   => esc_html__( 'Desktops: > 1199px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '6',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_md',
				'label'   => esc_html__( 'Desktops: > 991px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_sm',
				'label'   => esc_html__( 'Tablets: > 767px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '3',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_xs',
				'label'   => esc_html__( 'Phones: < 768px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '2',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_mobile',
				'label'   => esc_html__( 'Small Phones: < 480px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '1',
			),
			array(
				'mode' => 'section_end',
			),


			// Slider options
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider',
				'label'       => esc_html__( 'Slider Options', 'roofix-core' ),
				'condition'   => array( 'style' => 'logoslider2' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_nav',
				'label'       => esc_html__( 'Navigation Arrow', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Enable or disable navigation arrow. Default: On', 'roofix-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_autoplay',
				'label'       => esc_html__( 'Autoplay', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'roofix-core' ),
			),

			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'slider_interval',
				'label'   => esc_html__( 'Autoplay Interval', 'roofix-core' ),
				'options' => array(
					'5000' => esc_html__( '5 Seconds', 'roofix-core' ),
					'4000' => esc_html__( '4 Seconds', 'roofix-core' ),
					'3000' => esc_html__( '3 Seconds', 'roofix-core' ),
					'2000' => esc_html__( '2 Seconds', 'roofix-core' ),
					'1000' => esc_html__( '1 Second',  'roofix-core' ),
				),
				'default' => '5000',
				'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'roofix-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
			),

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_loop',
				'label'       => esc_html__( 'Loop', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Loop to first item. Default: On', 'roofix-core' ),
			),
			array(
				'mode' => 'section_end',
			),
		);

		return $fields;
	}

	protected function render() {

		$data = $this->get_settings();
		$owl_data = array(

			'autoplay' => $data['slider_autoplay'] == 'yes' ? true : false,
			'speed'  => $data['slider_interval'],
			'loop' => $data['slider_loop'],
			'col_lg'  => $data['col_lg'],
			'col_md'  => $data['col_md'],
			'col_sm'  => $data['col_sm'],
			'col_xs'  => $data['col_xs'],
			'col_mobile'  => $data['col_mobile'],

		);
		$data['owl_data'] = json_encode( $owl_data );
		$template = 'logo-slider/'.$data['style'];
		return $this->rt_template( $template, $data );
	}
}