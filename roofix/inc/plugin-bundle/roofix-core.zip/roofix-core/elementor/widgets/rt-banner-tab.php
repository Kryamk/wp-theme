<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Banner_Tab extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Banner Tab', 'roofix-core' );
		$this->rt_base = 'rt-banner-tab';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'title', [
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'default' => esc_html__( 'Roof Inspection', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'sub_title', [
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
				'default' => esc_html__( 'Smart Roofing Solution', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'image', [
				'type' => Controls_Manager::MEDIA,
				'label'   => esc_html__( 'Image', 'roofix-core' ),
					'default' => array(
						'url' => Utils::get_placeholder_image_src(),
					),
					'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'content', [
				'type' => Controls_Manager::WYSIWYG,
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'default' => esc_html__( 'Rohen an unknown printer took a galley offer type and scrambled it to make area type specimen book survived.', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'nav_title', [
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Nav Title', 'roofix-core' ),
				'default' => esc_html__( 'Inspection', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon_class', [
				'type' => Controls_Manager::ICONS,
				'label'   => esc_html__( 'Tab Icon', 'roofix-core' ),
				'default' => array(
						'value' => 'flaticon-mortgage',
						'library' => 'fa-solid',
					),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'url', [
				'type' => Controls_Manager::URL,
				'label' => esc_html__( 'Link (Optional)', 'roofix-core' ),
				'placeholder' => 'https://your-link.com',
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'buttontext', [
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Button Text', 'roofix-core' ),
				'default' => esc_html__( 'PREMIUM CALCULATE', 'roofix-core' ),
				'label_block' => true,
			]
		);
		
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'Tab', 'roofix-core' ),
			),
				array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Icon Layout', 'roofix-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Layout 1', 'roofix-core' ),
					'layout2' => esc_html__( 'Layout 2', 'roofix-core' ),				
				),
				'default' => 'layout1',
			),
			array (
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'tab_items',
				'label'   => esc_html__( 'Tab Items', 'roofix-core' ),
				'fields' => $repeater->get_controls(),
				'default' => [
					['title' => esc_html__('Roof Inspection', 'roofix-core' ) ],
					['title' => esc_html__('Roof Inspection', 'roofix-core' ) ],
					['title' => esc_html__('Roof Inspection', 'roofix-core' ) ],
					['title' => esc_html__('Roof Inspection', 'roofix-core' ) ],
					['title' => esc_html__('Roof Inspection', 'roofix-core' ) ],		         
		       ],
			),
			array(
				'mode' => 'section_end',
			),
			
			/*Title Style Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'roofix-core' ),
				'selector' => '{{WRAPPER}} .rtin-banner-tab .tab-content .rtin-item .rtin-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-content .rtin-item .rtin-title' => 'color: {{VALUE}}',
				),
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'sub_title_typo',
				'label'   => esc_html__( 'Sub Title Typo', 'roofix-core' ),
				'selector' => '{{WRAPPER}} .rtin-banner-tab .tab-content .rtin-item .sub_title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'sub_title_color',
				'label'   => esc_html__( 'Sub Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-content .rtin-item .sub_title' => 'color: {{VALUE}}',
				),
			),			
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'sub_title_display',
				'label'       => esc_html__( 'Sub Title Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
			),
			
			array(
				'mode' => 'section_end',
			),
			
			/*Title Style Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_tab',
				'label'   => esc_html__( 'Tab Style', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'tab_title_typo',
				'label'   => esc_html__( 'Nav Title Typo', 'roofix-core' ),
				'selector' => '{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a span',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'nav_title_color',
				'label'   => esc_html__( 'Nav Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'icon_color',
				'label'   => esc_html__( 'Icon Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a i' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'tab_bg_color',
				'label'   => esc_html__( 'Tab Background Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'tab_active_bg_color',
				'label'   => esc_html__( 'Tab Active Background Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a.active' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'icon_size',
				'label'   => esc_html__( 'Icon Size', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a i' => 'font-size: {{VALUE}}px',
					'{{WRAPPER}} .rtin-banner-tab .tab-nav-wrap .tab-nav-list li a i:before' => 'font-size: {{VALUE}}px',
				),
			),
			
			array(
				'mode' => 'section_end',
			),
			
		);
		return $fields;
	}

	protected function render() {
		
		$data = $this->get_settings();
		
		switch ( $data['layout'] ) {
			case 'layout2':
			$template = 'rt-banner-tab2';
			break;
			default:
			$template = 'rt-banner-tab';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}