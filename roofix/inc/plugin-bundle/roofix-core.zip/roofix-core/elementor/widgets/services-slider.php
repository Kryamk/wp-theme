<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) {
    exit;
}

class Services_Slider extends Custom_Widget_Base
{
    public function __construct($data = [], $args = null)
    {
        $this->rt_name      = esc_html__('Services Slider', 'roofix-core');
        $this->rt_base      = 'rt-services-slider';
        $this->rt_translate = array(
            'cols' => array(
                '12' => esc_html__('1 Col', 'roofix-core'),
                '6'  => esc_html__('2 Col', 'roofix-core'),
                '4'  => esc_html__('3 Col', 'roofix-core'),
                '3'  => esc_html__('4 Col', 'roofix-core'),
                '2'  => esc_html__('6 Col', 'roofix-core'),
            ),
        );
        parent::__construct($data, $args);
    }
    public function rt_fields()
    {
        $cpt               = ROOFIX_CORE_CPT;
        $terms             = get_terms(array('taxonomy' => "{$cpt}_services_category", 'fields' => 'id=>name'));
        $category_dropdown = array('0' => esc_html__('All Categories', 'roofix-core'));
        foreach ($terms as $id => $name) {
            $category_dropdown[$id] = $name;
        }
        $fields = array(
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general_layout',
                'label' => esc_html__('General', 'roofix-core'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'style',
                'label'   => esc_html__('Layout', 'roofix-core'),
                'options' => array(
                    'style1' => esc_html__('Style 1', 'roofix-core'),
                    'style2' => esc_html__('Style 2', 'roofix-core'),
                    'style3' => esc_html__('Style 3', 'roofix-core'),
                    'style4' => esc_html__('Style 4', 'roofix-core'),
                    'style5' => esc_html__('Style 5', 'roofix-core'),
                    'style6' => esc_html__('Style 6', 'roofix-core'),
                    'style7' => esc_html__('Style 7', 'roofix-core'),
                ),
                'default' => 'style1',
            ),
            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general_qurey',
                'label' => esc_html__('Qurey', 'roofix-core'),
            ),

            array(
                'type'        => Controls_Manager::NUMBER,
                'mode'        => 'responsive',
                'id'          => 'number',
                'label'       => esc_html__('Total number of items', 'roofix-core'),
                'default'     => 3,
                'description' => esc_html__('Write -1 to show all', 'roofix-core'),
            ),
            array(
                'type'     => Controls_Manager::SELECT2,
                'id'       => 'cat',
                'label'    => esc_html__('Categories', 'roofix-core'),
                'options'  => $category_dropdown,
                'multiple' => true,
                'default'  => '0',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'orderby',
                'label'   => esc_html__('Order By', 'roofix-core'),
                'options' => array(
                    'date'       => esc_html__('Date (Recents comes first)', 'roofix-core'),
                    'title'      => esc_html__('Title', 'roofix-core'),
                    'menu_order' => esc_html__('Custom Order (Available via Order field inside Page Attributes box)', 'roofix-core'),
                ),
                'default' => 'date',
            ),
            array(
                'mode' => 'section_end',
            ),
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general_display',
                'label' => esc_html__('Display', 'roofix-core'),
            ),
            array(
                'type'      => Controls_Manager::SWITCHER,
                'id'        => 'pagination_display',
                'label'     => esc_html__('Show Pagination', 'roofix-core'),
                'label_on'  => esc_html__('Show', 'roofix-core'),
                'label_off' => esc_html__('Hide', 'roofix-core'),
                'default'   => 'no',
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'services_imgover_icon',
                'label'       => esc_html__('Services Icon Show', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'yes',
                'description' => esc_html__('Show or Hide Services Icon. Default: On', 'roofix-core'),
                'condition'   => array('style' => 'style2'),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'services_content',
                'label'       => esc_html__('Services Content Show', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'yes',
                'description' => esc_html__('Show or Hide Services Content. Default: On', 'roofix-core'),
            ),
            array(
                'type'        => Controls_Manager::NUMBER,
                'id'          => 'count',
                'label'       => esc_html__('Word count', 'roofix-core'),
                'default'     => 15,
                'description' => esc_html__('Maximum number of words', 'roofix-core'),
                'condition'   => array('services_content' => 'yes'),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'services_btn',
                'label'       => esc_html__('Services Button Show', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'yes',
                'description' => esc_html__('Show or Hide Services link. Default: On', 'roofix-core'),
            ),
            array(
                'type'      => Controls_Manager::TEXT,
                'id'        => 'buttontext',
                'label'     => esc_html__('Button Text', 'roofix-core'),
                'default'   => 'READ MORE',
                'condition' => array('services_btn' => 'yes'),
            ),
            array(
                'mode' => 'section_end',
            ),
            // Responsive Columns
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_responsive',
                'label' => esc_html__('Number of Responsive Columns', 'roofix-core'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_lg',
                'label'   => esc_html__('Desktops: > 1199px', 'roofix-core'),
                'options' => $this->rt_translate['cols'],
                'default' => '4',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_md',
                'label'   => esc_html__('Desktops: > 991px', 'roofix-core'),
                'options' => $this->rt_translate['cols'],
                'default' => '4',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_sm',
                'label'   => esc_html__('Tablets: > 767px', 'roofix-core'),
                'options' => $this->rt_translate['cols'],
                'default' => '6',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_xs',
                'label'   => esc_html__('Phones: < 768px', 'roofix-core'),
                'options' => $this->rt_translate['cols'],
                'default' => '6',
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'col_mobile',
                'label'   => esc_html__('Small Phones: < 480px', 'roofix-core'),
                'options' => $this->rt_translate['cols'],
                'default' => '12',
            ),
            array(
                'mode' => 'section_end',
            ),

            // Slider options
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_slider',
                'label' => esc_html__('Slider Options', 'roofix-core'),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'slider_dots',
                'label'       => esc_html__('Hide Dots', 'roofix-core'),
                'description' => esc_html__('Enable or disable navigation dots. Default: On', 'roofix-core'),
                'selectors'   => [
                    '{{WRAPPER}} .swiper-pagination' => 'display: none;',
                ],
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'slider_autoplay',
                'label'       => esc_html__('Autoplay', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'yes',
                'description' => esc_html__('Enable or disable autoplay. Default: On', 'roofix-core'),
            ),

            array(
                'type'        => Controls_Manager::NUMBER,
                'id'          => 'autoplaySpeed',
                'label'       => esc_html__('Autoplay speed', 'roofix-core'),
                'default'     => 3000,
                'description' => esc_html__('Slide speed in milliseconds. Default: 3000', 'roofix-core'),
                'condition'   => array('slider_autoplay' => 'yes'),
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'slider_loop',
                'label'       => esc_html__('Loop', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'yes',
                'description' => esc_html__('Loop to first item. Default: On', 'roofix-core'),
            ),
            array(
                'mode' => 'section_end',
            ),

            // Title style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_title_style',
                'label' => esc_html__('Title', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'title_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-title',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'title_padding',
                'label'      => __('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'title_margin',
                'label'      => __('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'title_style',
                'label'       => esc_html__('Title Style', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'no',
                'description' => esc_html__('Show or Hide Title Style. Default: On', 'roofix-core'),
            ),
            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_style_color',
                'label'     => __('Title Style Color', 'roofix-core'),
                'default'   => '#ee212b',
                'condition' => array('title_style' => array('yes')),
                'selectors' => array(
                    '{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}',

                ),
            ),
            array(
                'type'       => Controls_Manager::SLIDER,
                'mode'       => 'responsive',
                'id'         => 'title_borde_size',
                'label'      => __('Border Size', 'roofix-core'),
                'condition'  => array('title_style' => array('yes')),
                'size_units' => array('px', '%'),
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 350,
                    ],
                ],

                'default'    => array(
                    'unit' => 'px',
                    'size' => 50,
                ),
                'range'      => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],

                'selectors'  => array(
                    '{{WRAPPER}} .title-style' => 'width: {{SIZE}}{{UNIT}};',

                ),
            ),

            array(
                'mode' => 'section_end',
            ),

            // Content style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_content_style',
                'label' => esc_html__('Contnet', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'content_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-title',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'content_padding',
                'label'      => esc_html__('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'content_margin',
                'label'      => esc_html__('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'mode' => 'section_end',
            ),
            // Content style
            array(
                'mode'      => 'section_start',
                'id'        => 'sec_btn_style',
                'label'     => esc_html__('Button', 'roofix-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => array('services_btn' => 'yes'),
            ),

            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'button_typo',
                'label'    => esc_html__('Button Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} a.ebtn-style, {{WRAPPER}} a.ebtn-style i',

            ),

            array(
                'type'       => Controls_Manager::SLIDER,
                'mode'       => 'responsive',
                'id'         => 'button_icon_spacing',
                'label'      => esc_html__('Position Top', 'roofix-core'),

                'size_units' => array('px'),
                'range'      => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100,
                    ),
                ),
                'default'    => array(
                    'unit' => 'px',
                    'size' => 5,
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .ebtn-style i' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ebtn-style i' => 'margin-left: {{SIZE}}{{UNIT}};',
                ),
            ),

            array(
                'mode' => 'section_end',
            ),

        );
        return $fields;
    }

    private function rt_load_scripts()
    {
        wp_enqueue_style('owl-carousel');
        wp_enqueue_style('owl-theme-default');
        wp_enqueue_script('owl-carousel');
    }
    protected function render()
    {
        if (is_rtl()) {
            $isrtl = true;
        } else {
            $isrtl = false;
        }

        $data     = $this->get_settings();
        $owl_data = array(

            'autoplay'      => $data['slider_autoplay'] == 'yes' ? true : false,
            'autoplaySpeed' => $data['autoplaySpeed'],
            'loop'          => $data['slider_loop'],
            'dots'          => $data['slider_dots'] == 'yes' ? true : false,
            'col_lg'        => 12 / $data['col_lg'],
            'col_md'        => 12 / $data['col_md'],
            'col_sm'        => 12 / $data['col_sm'],
            'col_xs'        => 12 / $data['col_xs'],
            'col_mobile'    => 12 / $data['col_mobile'],
        );
        $data['owl_data'] = json_encode($owl_data);
        $this->rt_load_scripts();

        switch ($data['style']) {
            case 'style2':
                $template = 'services-slider-2';
                break;
            case 'style3':
                $template = 'services-slider-3';
                break;
            case 'style4':
                $template = 'services-slider-4';
                break;
            case 'style5':
                $template = 'services-slider-5';
                break;
            case 'style6':
                $template = 'services-slider-6';
                break;
            case 'style7':
                $template = 'services-slider-7';
                break;
            default:
                $template = 'services-slider-1';
                break;
        }
        return $this->rt_template($template, $data);
    }
}
