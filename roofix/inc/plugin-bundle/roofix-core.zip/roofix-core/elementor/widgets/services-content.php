<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class rt_service_contant extends Custom_Widget_Base
{

    public function __construct($data = [], $args = null)
    {
        $this->rt_name = esc_html__('RT Service Content', 'roofix-core');
        $this->rt_base = 'rt-service-content';
        parent::__construct($data, $args);
    }

    public function rt_fields()
    {

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label'   => esc_html__('Title', 'roofix-core'),
                'default' => esc_html__('vorem ipsum dolor samet consectetur adipisicing elit sed eiusmod.', 'roofix-core'),
            ]
        );

        $repeater->add_control(
            'content',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'label'   => esc_html__('Content', 'roofix-core'),
                'default' => esc_html__('Roofing whenan unknown printer took
                tomake type specimen book.', 'roofix-core'),
            ]
        );

        $repeater->add_control(
            'count',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label'   => esc_html__('Count No', 'roofix-core'),
                'default' => esc_html__('1', 'roofix-core'),
            ]
        );

        $fields = array(
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general_img',
                'label' => esc_html__('Layout', 'roofix-core'),
            ),

            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'style',
                'label'   => esc_html__('Layout', 'roofix-core'),
                'options' => array(
                    '1' => esc_html__('Style 1', 'roofix-core'),
                    '2' => esc_html__('Style 2', 'roofix-core'),

                ),
                'default' => '1',
            ),
            array(
                'type'      => Controls_Manager::TEXTAREA,
                'id'        => 'stitle',
                'label'     => esc_html__('Title', 'roofix-core'),
                'default'   => 'Lorem Ipsum',
                'separator' => 'before',
                'condition' => array('style' => array('2')),
            ),

            array(
                'type'      => Controls_Manager::MEDIA,
                'id'        => 'image',
                'default'   => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'label'     => esc_html__('Select Left Image ', 'roofix-core'),
                'condition' => array('style' => array('1')),

            ),
            array(
                'type'      => Group_Control_Image_Size::get_type(),
                'mode'      => 'group',
                'label'     => esc_html__('Image size', 'roofix-core'),
                'name'      => 'image_size',
                'separator' => 'none',
                'condition' => array('style' => array('1')),
            ),
            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general',
                'label' => esc_html__('Content List', 'roofix-core'),
            ),
            array(
                'type'    => Controls_Manager::REPEATER,
                'id'      => 'content_items',
                'label'   => esc_html__('Content Items', 'roofix-core'),
                'fields'  => $repeater->get_controls(),
                'default' => [
                    ['title' => 'Quality We Ensure'],
                    ['title' => 'Quality We Ensure'],
                    ['title' => 'Quality We Ensure'],
                ],
            ),
            array(
                'mode' => 'section_end',
            ),
            /*Title Style Option*/
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_style',
                'label' => esc_html__('Style', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),
            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'title_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-title',
            ),
            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_color',
                'label'     => esc_html__('Title Color', 'roofix-core'),
                'default'   => '',
                'selectors' => array(
                    '{{WRAPPER}} .rtin-insurance-tab .rtin-item .rtin-content .rtin-title' => 'color: {{VALUE}}',
                ),
            ),

            array(
                'mode' => 'section_end',
            ),
        );
        return $fields;
    }
    protected function render()
    {
        $data = $this->get_settings();
        switch ($data['style']) {
            case '2':
                $template = 'services-content2';
                break;
            default:
                $template = 'services-content';
                break;
        }
        return $this->rt_template($template, $data);
    }
}
