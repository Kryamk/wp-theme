<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class services_info_box extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Services Info Box', 'roofix-core' );
		$this->rt_base = 'rt-services-info-box';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(

		array(
				'mode'    => 'section_start',
				'id'      => 'sec_layout',
				'label'   => esc_html__( 'layout', 'roofix-core' ),				
			),
				array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1', 'roofix-core' ),
					'style2' => esc_html__( 'Style 2', 'roofix-core' ),					
					'style3' => esc_html__( 'Style 3', 'roofix-core' ),					
					'style4' => esc_html__( 'Style 4', 'roofix-core' ),					
					'style5' => esc_html__( 'Style 5', 'roofix-core' ),					
				),
				'default' => 'style1',
			),		
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'design-theme',
				'label'   => esc_html__( 'Design Theme', 'roofix-core' ),
				'options' => array(
					'line-1' => esc_html__( 'Design 1', 'roofix-core' ),
					'line-2' => esc_html__( 'Design 2', 'roofix-core' ),					
					'line-3' => esc_html__( 'Design 3', 'roofix-core' ),					
					'line-4' => esc_html__( 'Design 4', 'roofix-core' ),			
										
				),
				'condition'   => array('style' => array( 'style5'  ) ),
				'default' => 'line-1',
			),		
		

		 array(
            'type'    => Controls_Manager::CHOOSE,
            'id'      => 'Alignment',
            'condition' 	=> [
					'style' => array('style2','style3','style4'),
					],
            'label'   => esc_html__( 'Style', 'roofix-core' ),

                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'htmega-addons' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'htmega-addons' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'htmega-addons' ),
                        'icon' => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justified', 'htmega-addons' ),
                        'icon' => 'fa fa-align-justify',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .why-choose-box-layout1' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .service-box-layout3' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .service-box-layout3d' => 'text-align: {{VALUE}};',
                ],

             'default' => 'center',
            ),	
			array(
				'mode' => 'section_end',
			),
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_image_icon',
				'label'   => esc_html__( 'Icon / Image', 'roofix-core' ),				
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'image_icon_active',
				'label'       => esc_html__( 'Show Image / Icon', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide icon or image. Default: On', 'roofix-core' ),
			),
			array(						 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => [
			     'icon' => [
			       'title' => esc_html__( 'Left', 'roofix-core' ),
			       'icon' => 'fa fa-smile-o',
			     ],
			     'image' => [
			       'title' => esc_html__( 'Center', 'roofix-core' ),
			       'icon' => 'fa fa-image',
			     ],		     
			   ],
			   'id'      => 'icontype',
			   'condition'   => array('image_icon_active' => array( 'yes' ) ),
			   'label'   => esc_html__( 'Media Type', 'roofix-core' ),
			   'default' => 'image',
			   'label_block' => false,
			   'toggle' => false,				 
			),	

			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon_class',
				'label'   => esc_html__( 'Icon', 'roofix-core' ),
				'default' => array(
			      'value' => 'flaticon-award',
			      'library' => 'fa-solid',
				),
				'condition'   => array('icontype' => array( 'icon' ), 'image_icon_active' => array( 'yes' ) ),
			),	
		
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'image',
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
				'condition'   => array('icontype' => array( 'image' ),'image_icon_active' => array( 'yes' )  ),
				'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
			),
			array(
				'type'    				=> Group_Control_Image_Size::get_type(),
				'mode'    				=> 'group',
				'name'      			=> 'image_size',
				'label'   				=> esc_html__( 'image size', 'roofix-core' ),					
				'separator' 			=> 'none',		
				'condition'   		=> array('icontype' => array( 'image' ),'image_icon_active' => array( 'yes' )  ),

			),	
			array(
				'mode' => 'section_end',
			),
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content',
				'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'default' => 'Residential <span> Services</span>',
			),
				array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'default' => 'Roofen an unknown printer took a galley of type and scrambled make.',
			),

			array(
					'type'    => Controls_Manager::REPEATER,
					'id'      => 'list',
					'label'   => esc_html__( 'Add as many list as you want', 'roofix-core' ),	
						'condition' 	=> [
							'style' => 'style1',
							],
					'fields'  => array(
						array(
							'type'    => Controls_Manager::TEXTAREA,
							'name'    => 'list_title',
							'label'   => esc_html__( 'List Title', 'roofix-core' ),
							'default' => 'Wood And Shake Shingles',
						),					
						array(
							'type'  => Controls_Manager::URL,
							'name'    => 'url',
							'label' => esc_html__( 'Link (Optional)', 'roofix-core' ),
							'placeholder' => 'https://your-link.com',
						),
					),
					'default' => [
		         ['list_title' => 'Wood And Shake Shingles', ],
		         ['list_title' => 'Slate', ],
		         ['list_title' => 'Synthetic Slate', ],
		         ['list_title' => 'Metal Roof', ],
		         ['list_title' => 'Flat Roof', ],		         
		       ],		
				),

		
			array(
				'mode' => 'section_end',
			),

					array(
						'mode'    => 'section_start',
						'id'      => 'sec_button',
						'label'   => esc_html__( 'Button', 'roofix-core' ),				
					),

					array(
						'type'        => Controls_Manager::SWITCHER,
						'id'          => 'is_button_active',
						'label'       => esc_html__( 'Show Button', 'roofix-core' ),
						'label_on'    => esc_html__( 'On', 'roofix-core' ),
						'label_off'   => esc_html__( 'Off', 'roofix-core' ),
						'default'     => 'no',
						'description' => esc_html__( 'Show or Hide Button. Default: Off', 'roofix-core' ),
					),

					array(
							'type'  				=> Controls_Manager::URL,
							'id'    				=> 'url',
							'label' 				=> esc_html__( 'Link (Optional)', 'roofix-core' ),
							'placeholder' 	=> 'https://your-link.com',
							'condition'   => array('is_button_active' => array( 'yes' )  ),
						),
						array(
							'type'  => Controls_Manager::TEXT,
							'id'    => 'url_text',
							'label' => esc_html__( 'Botton Text (Optional)', 'roofix-core' ),
							'default' => 'Read More',				
								'condition'   => array('is_button_active' => array( 'yes' )  ),	
						),
					array(
						'type'    => Controls_Manager::ICON,
						'id'      => 'button_icon',
						'label'   => esc_html__( 'Button Icon', 'roofix-core' ),
						'default' => 'fas fa-chevron-right',
							'condition'   => array('is_button_active' => array( 'yes' )  ),				
					),	
				array(
					'mode' => 'section_end',
				),


					array(
					'mode'    => 'section_start',
					'id'      => 'sec_image_style',
					'label'   => esc_html__( 'Image/Icon', 'roofix-core' ),
					'tab'     => Controls_Manager::TAB_STYLE,
					'condition'   => array('image_icon_active' => array( 'yes' )  ),
					),

					array(
						'type' 				=> Controls_Manager::SLIDER,
						'mode' 				=> 'responsive',
						'id'      		=> 'bottom_image_spacing',
						
						'label'   		=> esc_html__( 'Image Spacing', 'roofix-core' ),
						
					'size_units' => array( 'px' ),
						 'range' => [
					'px' => [
					'min' => 0,
					'max' => 250,
					],
					],

								
						'default' => array(
						'unit' => 'px',
						'size' => 20,
						),
							'selectors' => array(
								'{{WRAPPER}} .item-img' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
								'{{WRAPPER}} .item-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
							)
						),


						array(
							'type'    => Controls_Manager::COLOR,
							'id'      => 'icon_color',
							'label'   => esc_html__( 'Icon Color', 'roofix-core' ),
							'default' => '#082c4b',
							'condition' 	=> [
									'icontype' => 'icon',
									],
							'selectors' => array(
									'{{WRAPPER}} .item-icon i' => 'color: {{VALUE}}',							
								),
						),	
					array( 
							'mode'      => 'group',
							'type'      => Group_Control_Typography::get_type(),
							'name'      => 'icon_font_size',
							'condition' 	=> [
									'icontype' => 'icon',
									],
							'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
							'selector'  => '{{WRAPPER}} .item-icon i,{{WRAPPER}} .item-icon i::before',
						),
				array(
					'mode' => 'section_end',
				),
				array(
					'mode'    => 'section_start',
					'id'      => 'sec_title_style',
					'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
					'tab'     => Controls_Manager::TAB_STYLE,
				),
			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_title_spacing',
				'label'   		=> esc_html__( 'Title Bottom Spacing', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),	
				 'range' => [
         'px' => [
           'min' => 0,
           'max' => 250,
         ],
       ],			
				'default' => array(
				'unit' => 'px',
				'size' => 16,
				),
					'selectors' => array(
						'{{WRAPPER}} .item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
					)
				),
		array(
				'id'  	=> 'hr3',
				'type'	=> Controls_Manager::DIVIDER,
				'style' => 'thick',
			),
			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_color',
					'label'   => esc_html__( 'Title Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
							'{{WRAPPER}} .item-title a' => 'color: {{VALUE}}',
						),
				),	
			array(
			    'type'    => Controls_Manager::CHOOSE,
			    'id'      => 'title_tag',
			    'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
			    'options' => array(
			        'h1'  => [
			            'title' => esc_html__( 'H1', 'roofix-core' ),
			            'icon' => 'eicon-editor-h1'
			        ],
			        'h2'  => [
			            'title' => esc_html__( 'H2', 'roofix-core' ),
			            'icon' => 'eicon-editor-h2'
			        ],
			        'h3'  => [
			            'title' => esc_html__( 'H3', 'roofix-core' ),
			            'icon' => 'eicon-editor-h3'
			        ],
			        'h4'  => [
			            'title' => esc_html__( 'H4', 'roofix-core' ),
			            'icon' => 'eicon-editor-h4'
			        ],
			        'h5'  => [
			            'title' => esc_html__( 'H5', 'roofix-core' ),
			            'icon' => 'eicon-editor-h5'
			        ],
			        'h6'  => [
			            'title' => esc_html__( 'H6', 'roofix-core' ),
			            'icon' => 'eicon-editor-h6'
			        ],
			        'div'  => [
			            'title' => esc_html__( 'div', 'roofix-core' ),
			            'icon' => 'eicon-font'
			        ]
			    ),
			    'default' => 'h3',
			    
			),  
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'title_typo',
					'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-title',
				),
array(
				'id'  	=> 'borde-hr',
				'type'	=> Controls_Manager::DIVIDER,
				'style' => 'thick',
			),
			 array(
            'type'        => Controls_Manager::SWITCHER,
            'id'          => 'title_style',
            'label'       =>esc_html__( 'Title Border Style', 'roofix-core' ),
            'label_on'    =>esc_html__( 'On', 'roofix-core' ),
            'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
            'default'     => 'no',
            'description' =>esc_html__( 'Show or Hide Title Style. Default: On', 'roofix-core' ),
            ),  
            array(
                'type'    => Controls_Manager::COLOR,
                'id'      => 'title_style_color',
                'label'   => esc_html__( 'Title Style Color', 'roofix-core' ),
                'default' => '#ee212b',
                'condition'   => array('title_style' => array( 'yes' ) ),
                'selectors' => array(
                        '{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}', 

                    ),
            ),
					array(
                'type'          => Controls_Manager::SLIDER,
                'mode'          => 'responsive',
                'id'            => 'title_border-size',
                'label'         => esc_html__( 'Border Size', 'roofix-core' ),
                'condition'   => array('title_style' => array( 'yes' ) ),
                'size_units' => array( 'px','%'),
                 'range' => [
                   'px' => [
                     'min' => 0,
                     'max' => 250,
                   ],
                 ],   
                                     
                'default' => array(
                'unit' => 'px',
                'size' => 50,
                ),
                'range' => [
                   '%' => [
                     'min' => 0,
                     'max' => 100,
                   ],
                 ],    

                    'selectors' => array(
                        '{{WRAPPER}} .title-style' => 'width: {{SIZE}}{{UNIT}};',                      
                                      
                    )
                ),


			array(
				'id'  	=> 'hr',
				'type'	=> Controls_Manager::DIVIDER,
				'style' => 'thick',
			),
		array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_content_spacing',
				'label'   		=> esc_html__( 'Contant Bottom Spacing', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),				
				'default' => array(
				'unit' => 'px',
				'size' => 20,
				),
					'selectors' => array(
						'{{WRAPPER}} p.item-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
					)
			),
			array(
				'id'  	=> 'hr2',
				'type'	=> Controls_Manager::DIVIDER,
				'style' => 'thick',
			),
			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'content_color',
					'label'   => esc_html__( 'Content Color', 'roofix-core' ),
					'default' => '#082c4b',
					'selectors' => array(
							'{{WRAPPER}} p.item-content' => 'color: {{VALUE}}',							
						),
				),	
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'content_typo',
					'label'     => esc_html__( 'Content Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} p.item-content, {{WRAPPER}} ul.service-list li',
				
				),
			array(
				'mode' => 'section_end',
			),
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_btn_style',
				'label'   => esc_html__( 'Button', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition'   => array('is_button_active' => array( 'yes' )  ),				

			),
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'button_typo',
					'label'     => esc_html__( 'Button Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} a.btn-fill-lg , {{WRAPPER}} a.btn-fill-lg i' ,					
				),
			array(					 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => [
			     'icon' => [
			      'before' => esc_html__( 'Before', 'roofix-core' ),
			     	'icon' => 'eicon-text-align-left',
			     ],
			     'after' => [
			       'title' => esc_html__( 'After', 'roofix-core' ),
			       'icon' => 'eicon-text-align-right',
			     ],		     
			   ],
			   'id'      => 'button_icon_position',				 
			   'label'   => esc_html__( 'Icon Position', 'roofix-core' ),
			   'default' => 'after',
			   'label_block' => false,
			   'toggle' => false,	
					'condition' => [
						'button_icon!' => '',
					],			 
			),
			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'button_icon_spacing',
				'label'   		=> esc_html__( 'Icon Position', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),
					'range' => array(
						'px' => array(
						'min' => 0,
						'max' => 100,
						),
					),
				'default' => array(
				'unit' => 'px',
				'size' => 5,
				),
					'selectors' => array(
						'{{WRAPPER}} .icon-before i' => 'margin-right: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-after i' => 'margin-left: {{SIZE}}{{UNIT}};',
					)
				),
			array(
				'mode' => 'section_end',
			),
		
		);
		return $fields;
	}

	protected function render() {
		$data 			= $this->get_settings();	
		$template 	= 'services-info-box-' . str_replace("style", "", $data['style']);
		return $this->rt_template( $template, $data );
	}
}