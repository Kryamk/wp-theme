<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Controls_Manager;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;
class Price_Plan extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Price & Plan', 'roofix-core' );
		$this->rt_base = 'rt-price-plan';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'option_title', [
				'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Options', 'roofix-core' ),
				'default' => esc_html__( 'Dorem ipsum dolor', 'roofix-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'icon', [
				'type' => Controls_Manager::ICON,
				'label'   => esc_html__( 'Icon', 'roofix-core' ),
				'default' => 'fa fa-check',
				'label_block' => true,
			]
		);
		
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),
				),			
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'default' => esc_html__( 'Residential', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'price',
				'label'   => esc_html__( 'Price', 'roofix-core' ),
				'default' => 49,
				'description' => esc_html__( 'Maximum number of words', 'roofix-core' ),				
			),
            array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'period',
				'label'   => esc_html__( 'Period', 'roofix-core' ),
				'default' => 'Per Month',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'currency',
				'label'   => esc_html__( 'Currency', 'roofix-core' ),
				'default' => '$',
				'description' => esc_html__( 'Select Currency', 'roofix-core' ),				
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'icon_display',
				'label'       => esc_html__( 'Icon Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'info_image',
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],			
				'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
			),
			array(
				'type'    	=> Group_Control_Image_Size::get_type(),
				'mode'    	=> 'group',
				'label'   	=> esc_html__( 'Image size', 'roofix-core' ),	
				'name' 		=> 'info_image_size',
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'options',
				'label'   => esc_html__( 'Add as many slides as you want', 'roofix-core' ),	
				'fields' => $repeater->get_controls(),
				'default' => [
					['option_title' => esc_html__('Dorem ipsum dolor', 'roofix-core' ) ],
					['option_title' => esc_html__('Dorem ipsum dolor', 'roofix-core' ) ],		         
		       ],			
			),                   
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'roofix-core' ),
				'default' => esc_html__( 'PURCHASE NOW', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'    => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'roofix-core' ),
			),
				
			array(
				'mode' => 'section_end',
			),
			
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Title Style', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array( 
				'mode'      => 'group',
				'type'      => Group_Control_Typography::get_type(),
				'name'      => 'title_typo',
				'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
				'selector'  => '{{WRAPPER}} .price-table-layout1 .rtin-header .rtin-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .price-table-layout1 .rtin-header .rtin-title' => 'color: {{VALUE}}',
				),
			),
			array( 
				'mode'      => 'group',
				'type'      => Group_Control_Typography::get_type(),
				'name'      => 'price_typo',
				'label'     => esc_html__( 'Price Typography', 'roofix-core' ),
				'selector'  => '{{WRAPPER}} .price-table-layout1 .rtin-header .rtin-price',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'price_color',
				'label'   => esc_html__( 'Price Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .price-table-layout1 .rtin-header .rtin-price' => 'color: {{VALUE}}',
					'{{WRAPPER}} .price-table-layout1 .rtin-header .period' => 'color: {{VALUE}}',
				),
			),			
			array(
				'mode' => 'section_end',
			),
			
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();	
     	 $template = 'price-plan-1';                        
		return $this->rt_template( $template, $data );
	}
}