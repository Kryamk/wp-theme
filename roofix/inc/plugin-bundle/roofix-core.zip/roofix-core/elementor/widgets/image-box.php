<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use radiustheme\Roofix\Helper;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Base;

if ( ! defined( 'ABSPATH' ) ) exit;
class Image_Box extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Image Box', 'roofix-core' );
		$this->rt_base = 'rt-image-box';
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
			wp_enqueue_script( 'jquery-magnific-popup' );
			wp_enqueue_style( 'magnific-popup' );
		}
	private function rt_knob_load_scripts(){
		wp_enqueue_script( 'jquery-knob' );
		wp_enqueue_script( 'jquery-appear' );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
				'options' => array(
					'1' => esc_html__( 'Layout 1', 'roofix-core' ),
					'2' => esc_html__( 'Layout 2', 'roofix-core' ),
					'3' => esc_html__( 'Layout 3', 'roofix-core' ),
					'4' => esc_html__( 'Layout 4', 'roofix-core' ),
					'5' => esc_html__( 'Layout 5', 'roofix-core' ),
					'6' => esc_html__( 'Layout 6', 'roofix-core' ),
					'7' => esc_html__( 'Layout 7', 'roofix-core' ),
					'8' => esc_html__( 'Layout 8', 'roofix-core' ),
				),
				'default' => '1',
			),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'pnumber',
				'label'   => esc_html__( 'Progress number', 'roofix-core' ),
				'default' => '01',
				'description' => esc_html__( 'Write image Count No', 'roofix-core' ),
				'condition'   => array( 'layout' => array( '1','2','3','4')),
			),

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'alignment',
				'label'       => esc_html__( 'Number Alignment', 'roofix-core' ),
				'label_on'    => esc_html__( 'Left', 'roofix-core' ),
				'label_off'   => esc_html__( 'Right', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Left or Right Number Alignment. Default: Left', 'roofix-core' ),
				'condition'   => array( 'layout' => array( '1','2','3','4')),
			),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'pho_text',
				'label'   => esc_html__( 'Phone Text', 'roofix-core' ),
				'default' => esc_html__( 'Emergency Call', 'roofix-core' ),
				'description' => esc_html__( 'Write phone text', 'roofix-core' ),
				'condition'   => array( 'layout' => array( '8')),
			),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'pho_number',
				'label'   => esc_html__( 'Phone Number', 'roofix-core' ),
				'default' => '123-555-6677',
				'description' => esc_html__( 'Write phone No', 'roofix-core' ),
				'condition'   => array( 'layout' => array( '8')),
			),

			array(
				'type'    	=> Controls_Manager::MEDIA,
				'id'    	=> 'image',
				'default' 	=> [
				'url' 		=> Utils::get_placeholder_image_src(),
				],
				'label'   => esc_html__( 'Total number of items', 'roofix-core' ),
				'description' => esc_html__( 'Write image Count No', 'roofix-core' ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',
				'label'   => esc_html__( 'Image size', 'roofix-core' ),
				'name' 		=> 'image_size',
				'separator' => 'none',
			),
			array(
				'type'  => Controls_Manager::TEXTAREA,
				'id'    => 'videourl',
				'label' => esc_html__( 'video Link (Optional)', 'roofix-core' ),
				'placeholder' => 'http://www.youtube.com/watch?v=1iIZeIy7TqM',
				'condition'   => array( 'layout' => array( '1','2','3','4')),
			),


			array(
				'mode' => 'section_end',

			),

			array(
				'mode'    => 'section_start',
				'id'      => 'circle_general',
				'label'   => esc_html__( 'Progress Circle', 'roofix-core' ),
				'condition'   => array( 'layout' => array('6', '7')),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Progress title', 'roofix-core' ),
				'default' => 'Years Of Experience',
				'description' => esc_html__( 'Write image Count No', 'roofix-core' ),

			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'subtitle',
				'label'   => esc_html__( 'Progress Sub title', 'roofix-core' ),
				'default' => 'Years Of Experience',
				'description' => esc_html__( 'Write image Count No', 'roofix-core' ),

			),

				array(
					'type'    => Controls_Manager::NUMBER,
					'id'      => 'number',
					'label'   => esc_html__( 'Circle Number', 'roofix-core' ),
					'default' => 50,
				),
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'circle_width',
					'label'   => esc_html__( 'Circle Width', 'roofix-core' ),
					'default' => 125,
				),
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'circle_height',
					'label'   => esc_html__( 'Circle Height', 'roofix-core' ),
					'default' => 125,
				),
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'circle_border',
					'label'   => esc_html__( 'Circle thickness', 'roofix-core' ),
					'default' => 0.12,
				),
				array(
					'type'    => Controls_Manager::NUMBER,
					'id'      => 'speed',
					'label'   => esc_html__( 'Animation Speed', 'roofix-core' ),
					'default' => 5000,
					'description' => esc_html__( 'The total duration of the count animation in milisecond eg. 5000', 'roofix-core' ),
				),
				array(
					'type'    => Controls_Manager::NUMBER,
					'id'      => 'steps',
					'label'   => esc_html__( 'Animation Steps', 'roofix-core' ),
					'default' => 10,
					'description' => esc_html__( 'Counter steps eg. 10', 'roofix-core' ),
				),
			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'condition'   => array( 'layout' => array('7')),
				 'tab'     => Controls_Manager::TAB_STYLE,
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Style', 'roofix-core' ),
				'selector' => '{{WRAPPER}} .progress-circular-layout .rtin-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .progress-circular-layout .rtin-title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'content_color',
				'label'   => esc_html__( 'Content Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .progress-circular-layout .rtin-content' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'bgcolor_color',
				'label'   => esc_html__( 'bgcolor Color', 'roofix-core' ),
				'default' => '#e1e1e1',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'fgcolor_color',
				'label'   => esc_html__( 'fgcolor Color', 'roofix-core' ),
				'default' => '#ff0000',
			),
			array(
				'mode' => 'section_end',
			),

		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();

		  switch ( $data['layout'] ) {
                case '7':
                  $this->rt_knob_load_scripts();
            break;
                default:
                $this->rt_load_scripts();
            break;

}

		$template 	= 'image-box-' . $data['layout'];
		return $this->rt_template( $template, $data );
	}
}