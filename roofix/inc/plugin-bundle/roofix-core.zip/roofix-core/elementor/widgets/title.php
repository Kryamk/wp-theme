<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) {
    exit;
}

class Title extends Custom_Widget_Base
{
    public function __construct($data = [], $args = null)
    {
        $this->rt_name = esc_html__('Section Title', 'roofix-core');
        $this->rt_base = 'rt-title';
        parent::__construct($data, $args);
    }
    public function rt_fields()
    {
        $fields = array(
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_general',
                'label' => esc_html__('General', 'roofix-core'),
            ),
            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'style',
                'label'   => esc_html__('Layout', 'roofix-core'),
                'options' => array(
                    'style1' => esc_html__('Style 1', 'roofix-core'),
                    'style2' => esc_html__('Style 2', 'roofix-core'),

                ),
                'default' => 'style1',
            ),

            array(
                'type'      => Controls_Manager::CHOOSE,
                'id'        => 'Alignment',
                'mode'      => 'responsive',
                'label'     => esc_html__('Style', 'roofix-core'),

                'options'   => [
                    'left'    => [
                        'title' => esc_html__('Left', 'htmega-addons'),
                        'icon'  => 'fa fa-align-left',
                    ],
                    'center'  => [
                        'title' => esc_html__('Center', 'htmega-addons'),
                        'icon'  => 'fa fa-align-center',
                    ],
                    'right'   => [
                        'title' => esc_html__('Right', 'htmega-addons'),
                        'icon'  => 'fa fa-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justified', 'htmega-addons'),
                        'icon'  => 'fa fa-align-justify',
                    ],
                ],

                'selectors' => [
                    '{{WRAPPER}} .heading-layout1'    => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .heading-layout1new' => 'text-align: {{VALUE}};',
                ],

                'default'   => 'center',
            ),

            array(
                'type'      => Controls_Manager::TEXT,
                'id'        => 'beforetitle',
                'label'     => esc_html__('Before Title', 'roofix-core'),
                'default'   => 'Before Title',
                'separator' => 'before',

            ),
            array(
                'type'      => Controls_Manager::TEXTAREA,
                'id'        => 'title',
                'label'     => esc_html__('Section Title', 'roofix-core'),
                'default'   => 'Lorem Ipsum',
                'separator' => 'before',
            ),

            array(
                'type'    => Controls_Manager::CHOOSE,
                'id'      => 'title_tag',
                'label'   => esc_html__('Title HTML Tag', 'roofix-core'),
                'options' => array(
                    'h1'  => [
                        'title' => esc_html__('H1', 'roofix-core'),
                        'icon'  => 'eicon-editor-h1',
                    ],
                    'h2'  => [
                        'title' => esc_html__('H2', 'roofix-core'),
                        'icon'  => 'eicon-editor-h2',
                    ],
                    'h3'  => [
                        'title' => esc_html__('H3', 'roofix-core'),
                        'icon'  => 'eicon-editor-h3',
                    ],
                    'h4'  => [
                        'title' => esc_html__('H4', 'roofix-core'),
                        'icon'  => 'eicon-editor-h4',
                    ],
                    'h5'  => [
                        'title' => esc_html__('H5', 'roofix-core'),
                        'icon'  => 'eicon-editor-h5',
                    ],
                    'h6'  => [
                        'title' => esc_html__('H6', 'roofix-core'),
                        'icon'  => 'eicon-editor-h6',
                    ],
                    'div' => [
                        'title' => esc_html__('div', 'roofix-core'),
                        'icon'  => 'eicon-font',
                    ],
                ),
                'default' => 'h2',

            ),
            array(
                'type'      => Controls_Manager::TEXTAREA,
                'id'        => 'subtitle',
                'label'     => esc_html__('Subtitle', 'roofix-core'),
                'default'   => 'Lorem Ipsum has been standard daand scrambled. Rimply dummy text of the printing and typesetting industry',
                'separator' => 'before',
            ),
            array(
                'mode' => 'section_end',
            ),

            // Before Title style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_bft_style',
                'label' => esc_html__('Before Title', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'bfts_color',
                'label'     => esc_html__('Style Color', 'roofix-core'),
                'default'   => '#ee212b',
                'selectors' => array(
                    '{{WRAPPER}} .heading-layout1new .item-subtitle:after' => 'background-color: {{VALUE}}',
                ),
            ),
            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'bft_color',
                'label'     => esc_html__('Color', 'roofix-core'),
                'default'   => '#444444',
                'selectors' => array(
                    '{{WRAPPER}} .item-beforetitle' => 'color: {{VALUE}}',
                ),
            ),
            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'bft_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-beforetitle',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'id'         => 'content_padding',
                'mode'       => 'responsive',
                'label'      => esc_html__('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-beforetitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'content_margin',
                'label'      => esc_html__('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-beforetitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),

            array(
                'mode' => 'section_end',
            ),

            // Title style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_title_style',
                'label' => esc_html__('Title', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_color',
                'label'     => __('Color', 'roofix-core'),
                'default'   => '#111111',
                'selectors' => array(
                    '{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
                ),
            ),
            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'title_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-title',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'title_padding',
                'label'      => __('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'mode'       => 'responsive',
                'id'         => 'title_margin',
                'label'      => __('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'title_style',
                'label'       => esc_html__('Title Style', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'no',
                'description' => esc_html__('Show or Hide Title Style. Default: On', 'roofix-core'),
            ),
            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_style_color',
                'label'     => __('Title Style Color', 'roofix-core'),
                'default'   => '#ee212b',
                'condition' => array('title_style' => array('yes')),
                'selectors' => array(
                    '{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}',

                ),
            ),

            array(
                'type'       => Controls_Manager::SLIDER,
                'mode'       => 'responsive',
                'id'         => 'title_border-size',
                'label'      => __('Border Size', 'roofix-core'),
                'condition'  => array('title_style' => array('yes')),
                'size_units' => array('px', '%'),
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 250,
                    ],
                ],

                'default'    => array(
                    'unit' => 'px',
                    'size' => 50,
                ),
                'range'      => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],

                'selectors'  => array(
                    '{{WRAPPER}} .title-style' => 'width: {{SIZE}}{{UNIT}};',

                ),
            ),

            array(
                'mode' => 'section_end',
            ),

            // section subtitle  style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_subtitle_style',
                'label' => esc_html__('Sub Title', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'subtitle_color',
                'label'     => __('Color', 'roofix-core'),
                'default'   => '#646464',
                'selectors' => array(
                    '{{WRAPPER}} .section-subtitle' => 'color: {{VALUE}}',
                ),
            ),
            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'subtitle_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .section-subtitle',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'mode'       => 'responsive',
                'size_units' => ['px', '%', 'em'],
                'id'         => 'subtitle_padding',
                'label'      => __('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .section-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'mode'       => 'responsive',
                'size_units' => ['px', '%', 'em'],
                'id'         => 'subtitle_margin',
                'label'      => __('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .section-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),

            array(
                'mode' => 'section_end',
            ),

        );
        return $fields;
    }
    protected function render()
    {
        $data = $this->get_settings();

        switch ($data['style']) {
            case 'style2':
                $template = 'title-2';
                break;
            default:
                $template = 'title-1';
                break;
        }
        return $this->rt_template($template, $data);
    }
}
