<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofix\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Contact extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Contact', 'roofix-core' );
		$this->rt_base = 'rt-contact';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general_layout',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
			),
				array(
						'type'    => Controls_Manager::TEXT,
						'id'      => 'title',
						'label'   => esc_html__( 'Title', 'roofix-core' ),
						'default' => 'Contact Information',
					),

				array(
						'type'    => Controls_Manager::SELECT2,
						'id'      => 'layout',
						'label'   => esc_html__( 'Layout', 'roofix-core' ),
						'options' => array(
							'layout1' => esc_html__( 'Layout 1', 'roofix-core' ),
							'layout2' => esc_html__( 'Layout 2 (Map Bottom)', 'roofix-core' ),					
							'layout3' => esc_html__( 'Layout 3', 'roofix-core' ),					
							'layout4' => esc_html__( 'Layout 4', 'roofix-core' ),					
							'layout5' => esc_html__( 'Layout 5', 'roofix-core' ),					
						),
						'default' => 'layout1',
					),
			array(
				'mode' => 'section_end',
			),

		array(
				'mode'    => 'section_start',
				'id'      => 'sec_general_address',
				'label'   => esc_html__( 'Address', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'address_label',
				'label'   => esc_html__( 'Address label', 'roofix-core' ),
				'default' => 'Location:',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'address',
				'label'   => esc_html__( 'Address 1', 'roofix-core' ),
				'default' => '51 Street, Newyork City, NYPD',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'address2',
				'label'   => esc_html__( 'Address 2', 'roofix-core' ),
				'default' => '18 Street, Newyork City, NYPD',
			),
		array(
			'mode' => 'section_end',
		),

	array(
			'mode'    => 'section_start',
			'id'      => 'sec_general_email',
			'label'   => esc_html__( 'Email', 'roofix-core' ),
		),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'email_label',
				'label'   => esc_html__( 'Email label', 'roofix-core' ),
				'default' => 'E-mail:',
			),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'email',
				'label'   => esc_html__( 'Email 1', 'roofix-core' ),
				'default' => 'info@roofing.com',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'email2',
				'label'   => esc_html__( 'Email 2', 'roofix-core' ),
				'default' => 'info@roofing.com',
			),
		array(
			'mode' => 'section_end',
		),

	array(
			'mode'    => 'section_start',
			'id'      => 'sec_general_phone',
			'label'   => esc_html__( 'Phone', 'roofix-core' ),
		),

			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'phone_label',
				'label'   => esc_html__( 'Phone label', 'roofix-core' ),
				'default' => 'Phone:',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'phone',
				'label'   => esc_html__( 'Phone 1', 'roofix-core' ),
				'default' => '+8123 (456) 788 99',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'phone2',
				'label'   => esc_html__( 'Phone 2', 'roofix-core' ),
				'default' => '+8123 (456) 788 99',
			),
		array(
				'mode' => 'section_end',
			),
		

		array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Layout Title', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_title_spacing',
				'label'   		=> __( 'Bottom Spacing', 'roofix-core' ),
				'size_units' => array( 'px' ),				
				'default' => array(
				'unit' => 'px',
				'size' => 20,
				),
					'selectors' => array(
						'{{WRAPPER}} .item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
						)
					
				),

			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_color',
					'label'   => __( 'Title Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .item-title' => 'color: {{VALUE}}',							
						),
				),		
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'title_typo',
					'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-title',
				),			
			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_lable_style',
				'label'   => esc_html__( 'Labal', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,

				'condition'   => array('layout' => array( 'layout1' ) ),
			),
			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_email_spacing',
				'label'   		=> __( 'Labal Bottom Spacing', 'roofix-core' ),
				'size_units' => array( 'px' ),				
				'default' => array(
				'unit' => 'px',
				'size' => 20,
				),
					'selectors' => array(
						'{{WRAPPER}} .lab-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
					)
				),
			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'email_lab_color',
					'label'   => __( 'Labal Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .lab-title' => 'color: {{VALUE}}',							
							'{{WRAPPER}} .item-icon i' => 'color: {{VALUE}}',							
						),
				),		
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'email_typo',
					'label'     => esc_html__( 'Labal Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .lab-title',
				),	

			array(
				'mode' => 'section_end',
			),
		array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
				array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'content_color',
					'label'   => __( 'Content Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .content-style li' => 'color: {{VALUE}}',							
							
						),
				),		
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'content_typo',
					'label'     => esc_html__( 'Content Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .content-style li',
				),			
					

			array(
				'mode' => 'section_end',
			),
			

				
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		$template 	= 'contact-' . str_replace("layout", "", $data['layout']);
		
		return $this->rt_template( $template, $data );
	}
}