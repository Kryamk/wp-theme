<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit;
class Text_With_Title extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Title With Content', 'roofix-core' );
		$this->rt_base = 'rt-text-with-title';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
			
			array(
				'mode'    => 'section_start',
				'id'      => 'twt_layout',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'layout',
					'label'   => esc_html__( 'Layout', 'roofix-core' ),
					'options' => array(
						'layout1' => esc_html__( 'Layout 1', 'roofix-core' ),
						'layout2' => esc_html__( 'Layout 2', 'roofix-core' ),
						'layout3' => esc_html__( 'Layout 3', 'roofix-core' ),
						'layout4' => esc_html__( 'Layout 4', 'roofix-core' ),
					),
					'default' => 'layout1',
				),	
			 array(
          'mode' => 'section_end',
      ),

		array(
				'mode'    => 'section_start',
				'id'      => 'twt_general',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::TEXTAREA,
					'id'      => 'title',
					'label'   => esc_html__( 'Title', 'roofix-core' ),
					'default' => 'An Experienced Roofing<br> Solution company',
				),

            array(
                    'type'    => Controls_Manager::CHOOSE,
                    'id'      => 'title_tag',
                    'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
                    'options' => array(
                        'h1'  => [
                            'title' => esc_html__( 'H1', 'roofix-core' ),
                            'icon' => 'eicon-editor-h1'
                        ],
                        'h2'  => [
                            'title' => esc_html__( 'H2', 'roofix-core' ),
                            'icon' => 'eicon-editor-h2'
                        ],
                        'h3'  => [
                            'title' => esc_html__( 'H3', 'roofix-core' ),
                            'icon' => 'eicon-editor-h3'
                        ],
                        'h4'  => [
                            'title' => esc_html__( 'H4', 'roofix-core' ),
                            'icon' => 'eicon-editor-h4'
                        ],
                        'h5'  => [
                            'title' => esc_html__( 'H5', 'roofix-core' ),
                            'icon' => 'eicon-editor-h5'
                        ],
                        'h6'  => [
                            'title' => esc_html__( 'H6', 'roofix-core' ),
                            'icon' => 'eicon-editor-h6'
                        ],
                        'div'  => [
                            'title' => esc_html__( 'div', 'roofix-core' ),
                            'icon' => 'eicon-font'
                        ]
                    ),
                    'default' => 'h2',
                    
                ),

			array(
          'mode' => 'section_end',
      ),	

        array(
        	'mode'    => 'section_start',
        	'id'      => 'twt_subtitle',
        	'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
        ),

        array(
        	'type'    => Controls_Manager::TEXTAREA,
        	'id'      => 'subtitle',
        	'label'   => esc_html__( 'Subtitle', 'roofix-core' ),
        	'default' => 'With More Than Half a Century of <br>Experience And thousands of Innovative',
        ),

        array(
            'mode' => 'section_end',
        ),	 

	  array(
			'mode'    => 'section_start',
			'id'      => 'twt_content',
			'label'   => esc_html__( 'Content', 'roofix-core' ),
		),
		array(
			'type'    => Controls_Manager::WYSIWYG,
			'id'      => 'content',
			'label'   => esc_html__( 'Content', 'roofix-core' ),
			'default' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet they consec tetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatemo qui quia dolor sit amedipisci develit.',
		),
			array(
		  'mode' => 'section_end',
		),

	  array(
			'mode'    => 'section_start',
			'id'      => 'twt_btn',
			'label'   => esc_html__( 'Button', 'roofix-core' ),
		),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'roofix-core' ),
				'default' => 'LOREM IPSUM',
			),
			array(
				'type'    => Controls_Manager::URL,
				'id'      => 'buttonurl',
				'label'   => esc_html__( 'Button URL', 'roofix-core' ),
				'placeholder' => 'https://your-link.com',
			),
		array(
			  'mode' => 'section_end',
			),


    // Title style
        array(
            'mode'    => 'section_start',
            'id'      => 'pwt_title_style',
            'label'   => esc_html__( 'Title', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
        ),      

        array(
            'type'    	=> Controls_Manager::COLOR,
            'id'      	=> 'title_color',
            'label'   	=> esc_html__( 'Color', 'roofix-core' ),
            'default' 	=> '#111111',                       
            'selectors' => array(
                    '{{WRAPPER}} .about-box-layout4 .item-title' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout5 .item-title' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout1 .item-title' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout1d .item-title' => 'color: {{VALUE}}',                           
                ),
        ),  
        array( 
            'mode'      => 'group',
            'type'      => Group_Control_Typography::get_type(),
            'name'      => 'title_font_size',                
            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  => 
                '
                {{WRAPPER}} .about-box-layout5 .item-title,
            	{{WRAPPER}} .about-box-layout4 .item-title,
            	{{WRAPPER}} .about-box-layout1 .item-title,
                {{WRAPPER}} .about-box-layout1d .item-title
                ',
            	
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'title_padding',
            'label'   => esc_html__( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout5 .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1 .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1d .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
            ),
            'separator' => 'before',
        ),  
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'title_margin',
            'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout5 .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1 .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1d .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator' => 'before',
        ),  

        array(
            'type'        => Controls_Manager::SWITCHER,
            'id'          => 'title_style',
            'label'       =>esc_html__( 'Title Style', 'roofix-core' ),
            'label_on'    =>esc_html__( 'On', 'roofix-core' ),
            'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
            'default'     => 'no',
             'separator' => 'before',
            'description' =>esc_html__( 'Show or Hide Title Style. Default: On', 'roofix-core' ),
        ),  
        array(
            'type'              => Controls_Manager::SLIDER,
            'mode'              => 'responsive',
            'id'                => 'title_style_size',
            'label'             => esc_html__( 'Title Style Width', 'roofix-core' ),
            'condition'         => [
                'title_style'   => 'yes',
            ],
            'size_units'        => [ 'px', '%' ],
            'range'             => [
               'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ]
            ],               
            'default' => array(
            'unit' => 'px',
            'size' => 50,
            ),
                'selectors' => array(
                    '{{WRAPPER}} .about-box-layout4 .title-style' => 'width: {{SIZE}}{{UNIT}};',                      
                    '{{WRAPPER}} .about-box-layout5 .title-style' => 'width: {{SIZE}}{{UNIT}};',                      
                    '{{WRAPPER}} .about-box-layout1 .title-style' => 'width: {{SIZE}}{{UNIT}};',                      
                    '{{WRAPPER}} .about-box-layout1d .title-style' => 'width: {{SIZE}}{{UNIT}};',                      
                )
        ),
        array( 
            'mode'      => 'group',
            'type'      => Group_Control_Background::get_type(),
            'name'      => 'title_style_color',        
            'condition'   => array('title_style' => array( 'yes' ) ),        
            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  => 
                '
            	{{WRAPPER}}  .about-box-layout4 .title-style::after,
            	{{WRAPPER}}  .about-box-layout5 .title-style::after,
            	{{WRAPPER}}  .about-box-layout1 .title-style::after,
                {{WRAPPER}}  .about-box-layout1d .title-style::after

                ',
        ),
        array(
            'type'          => Controls_Manager::DIMENSIONS,
            'size_units'    => [ 'px', '%', 'em' ],
            'id'            => 'title_style_margin',
            'label'         => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors'     => array(
                '{{WRAPPER}} .about-box-layout4 .title-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout5 .title-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1 .title-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1d .title-style' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator'     => 'before',
        ),


    array(
        'mode' => 'section_end',
    ),

 			// Sub Title style
        array(
            'mode'    => 'section_start',
            'id'      => 'pwt_subtitle_style',
            'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
      ),
   
        array(
            'type'    => Controls_Manager::COLOR,
            'id'      => 'subtitle_color',
            'label'   => esc_html__( 'Color', 'roofix-core' ),
            'default' => '',                       
            'selectors' => array(
                    '{{WRAPPER}} .about-box-layout4 .item-subtitle' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout5 .item-subtitle' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout1 .item-subtitle' => 'color: {{VALUE}}',                           
                    '{{WRAPPER}} .about-box-layout1d .item-subtitle' => 'color: {{VALUE}}',                           
                ),
        ),  
        array( 
            'mode'     		 => 'group',
            'type'      	=> Group_Control_Typography::get_type(),
            'name'      	=> 'pt_subtitle_font_size',                
            'label'     	=> esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  	=>
            '
            {{WRAPPER}} .about-box-layout4 .item-subtitle,
            {{WRAPPER}} .about-box-layout5 .item-subtitle,
            {{WRAPPER}} .about-box-layout1 .item-subtitle,
            {{WRAPPER}} .about-box-layout1d .item-subtitle
            ',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'subtitle_padding',
            'label'   => esc_html__( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .item-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout5 .item-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1 .item-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1d .item-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
            ),
            'separator' => 'before',
        ),  
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'subtitle_margin',
            'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout5 .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1 .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1d .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator' => 'before',
        ),  

    array(
        'mode' => 'section_end',
    ), 

        //section Content style
        array(
            'mode'    => 'section_start',
            'id'      => 'pwt_content_style',
            'label'   => esc_html__( 'Content', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
        ),               
        array(
            'type'    => Controls_Manager::COLOR,
            'id'      => 'content_color',
            'label'   => esc_html__( 'Color', 'roofix-core' ),
            'default' => '#646464',                       
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .rtr-content' => 'color: {{VALUE}}',                           
                '{{WRAPPER}} .about-box-layout4 .rtr-content p' => 'color: {{VALUE}}',                           
                '{{WRAPPER}} .about-box-layout5 .rtr-content' => 'color: {{VALUE}}',                           
                '{{WRAPPER}} .about-box-layout5 .rtr-content p' => 'color: {{VALUE}}', 
                '{{WRAPPER}} .about-box-layout1 .rtr-content' => 'color: {{VALUE}}',                           
                '{{WRAPPER}} .about-box-layout1 .rtr-content p' => 'color: {{VALUE}}',
                '{{WRAPPER}} .about-box-layout1d .rtr-content' => 'color: {{VALUE}}',                           
                '{{WRAPPER}} .about-box-layout1d .rtr-content p' => 'color: {{VALUE}}',                           
            ),
        ),  
        array( 
            'mode'      => 'group',
            'type'      => Group_Control_Typography::get_type(),
            'name'      => 'content_font_size',                
            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  => 
            '
            {{WRAPPER}} .about-box-layout4 .rtr-content,
            {{WRAPPER}} .about-box-layout5 .rtr-content,
            {{WRAPPER}} .about-box-layout1 .rtr-content,
            {{WRAPPER}} .about-box-layout1d .rtr-content
            ',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'content_padding',
            'label'   => esc_html__( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .rtr-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout5 .rtr-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1 .rtr-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                '{{WRAPPER}} .about-box-layout1d .rtr-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
            ),
            'separator' => 'before',
        ),  
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'content_margin',
            'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors' => array(
                '{{WRAPPER}} .about-box-layout4 .rtr-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout5 .rtr-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1 .rtr-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                '{{WRAPPER}} .about-box-layout1d .rtr-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator' => 'before',
        ),  
        array(
            'mode' => 'section_end',
        ),

			//section Button style
		  array(
		      'mode'    => 'section_start',
		      'id'      => 'pwt_btn_style',
		      'label'   => esc_html__( 'Button', 'roofix-core' ),
		      'tab'     => Controls_Manager::TAB_STYLE,
		  ),               
			  array(
			      'type'    	=> Controls_Manager::COLOR,
			      'id'      	=> 'btn_color',
			      'label'   	=> esc_html__( 'Color', 'roofix-core' ),
			      'default' 	=> '',                       
			      'selectors' => array(
			          '{{WRAPPER}} .about-box-layout4 .rtin-button a' => 'color: {{VALUE}}; border-color: {{VALUE}};',                           
			          '{{WRAPPER}} .about-box-layout4 .rtin-button a:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',  
			          '{{WRAPPER}} .about-box-layout5 .rtin-button a' => 'color: {{VALUE}}; border-color: {{VALUE}};',                           
			          '{{WRAPPER}} .about-box-layout5 .rtin-button a:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',	
			          '{{WRAPPER}} .about-box-layout1 .rtin-button a' => 'color: {{VALUE}}; border-color: {{VALUE}};',                           
			          '{{WRAPPER}} .about-box-layout1 .rtin-button a:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',
                      '{{WRAPPER}} .about-box-layout1d .rtin-button a' => 'color: {{VALUE}}; border-color: {{VALUE}};',                           
                      '{{WRAPPER}} .about-box-layout1d .rtin-button a:hover' => 'background-color: {{VALUE}}; border-color: {{VALUE}};',                           
			      ),
			  ),  
			  array( 
			      'mode'      => 'group',
			      'type'      => Group_Control_Typography::get_type(),
			      'name'      => 'btn_font_size',                
			      'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
			      'selector'  => 
                  '
                  {{WRAPPER}} .about-box-layout4 .rtin-button a,
                  {{WRAPPER}} .about-box-layout5 .rtin-button a,                  
                  {{WRAPPER}} .about-box-layout1 .rtin-button a,
                  {{WRAPPER}} .about-box-layout1d .rtin-button a',
			      	
			  ),
			  array(
			      'type'    		=> Controls_Manager::DIMENSIONS,
			      'size_units' 	=> [ 'px', '%', 'em' ],
			      'id'      		=> 'btn_padding',
			      'label'   		=> esc_html__( 'Padding', 'roofix-core' ),
			      'selectors' 	=> array(
			          '{{WRAPPER}} .about-box-layout4 .rtin-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
			          '{{WRAPPER}} .about-box-layout5 .rtin-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
			          '{{WRAPPER}} .about-box-layout1 .rtin-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
                      '{{WRAPPER}} .about-box-layout1d .rtin-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
			      ),
			      'separator' 	=> 'before',
			  ),  
			  array(
			      'type'    => Controls_Manager::DIMENSIONS,
			      'size_units' => [ 'px', '%', 'em' ],
			      'id'      => 'btn_margin',
			      'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
			      'selectors' => array(
			          '{{WRAPPER}} .about-box-layout4 .rtin-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
			          '{{WRAPPER}} .about-box-layout5 .rtin-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
			          '{{WRAPPER}} .about-box-layout1 .rtin-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
                      '{{WRAPPER}} .about-box-layout1d .rtin-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
			      ),
			      'separator' => 'before',
			  ),  
		  array(
		      'mode' => 'section_end',
		  ),

		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();

		switch ( $data['layout'] ) {
			case 'layout2':
			$template = 'text-with-title-2';
			break;
			case 'layout3':
			$template = 'text-with-title-3';
			break;
			case 'layout4':
			$template = 'text-with-title-4';
			break;
			default:
			$template = 'text-with-title-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}