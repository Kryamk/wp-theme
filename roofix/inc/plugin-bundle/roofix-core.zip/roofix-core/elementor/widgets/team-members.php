<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofix\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;
class Team_Members extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Team Member', 'roofix-core' );
		$this->rt_base = 'rt-team-member';
		$this->rt_translate = array(
			'cols'  => array(
				'12' => esc_html__( '1 Col', 'roofix-core' ),
				'6'  => esc_html__( '2 Col', 'roofix-core' ),
				'4'  => esc_html__( '3 Col', 'roofix-core' ),
				'3'  => esc_html__( '4 Col', 'roofix-core' ),
				'2'  => esc_html__( '6 Col', 'roofix-core' ),
			),
		);
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
		wp_enqueue_script( 'imagesloaded' );
		wp_enqueue_script( 'isotope-pkgd' );
	}
	
	public function rt_fields(){
		$cpt = ROOFIX_CORE_CPT;
		$terms  = get_terms( array( 'taxonomy' => "{$cpt}_team_category", 'fields' => 'id=>name' ) );
		$category_dropdown = array( '0' => esc_html__( 'All Categories', 'roofix-core' ) );
		foreach ( $terms as $id => $name ) {
			$category_dropdown[$id] = $name;
		}
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1', 'roofix-core' ),
					'style2' => esc_html__( 'Style 2', 'roofix-core' ),
					'style3' => esc_html__( 'Style 3', 'roofix-core' ),
					'style4' => esc_html__( 'Style 4', 'roofix-core' ),
					'style5' => esc_html__( 'Style 5', 'roofix-core' ),
					'style6' => esc_html__( 'Style 6', 'roofix-core' ),
					'style7' => esc_html__( 'Style 7', 'roofix-core' ),
				),

				'default' => 'style1',
			),
			array(
				'type'    		=> Controls_Manager::NUMBER,
				'id'      		=> 'number',
				'label'   		=> esc_html__( 'Total number of items', 'roofix-core' ),
				'default' 		=> 5,
				'description' 	=> esc_html__( 'Write -1 to show all', 'roofix-core' ),
			),			
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'designation_content',
				'label'       => esc_html__( 'Short details', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Content. Default: On', 'roofix-core' ),
				'condition'	  => array( 'style' => array( 'style3')),	
			),

			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'count',
				'label'   => esc_html__( 'Word count', 'roofix-core' ),
				'default' => 15,
				'description' => esc_html__( 'Maximum number of words', 'roofix-core' ),
				'condition' => array( 'style' => array( 'style3'),'designation_content' => array( 'yes')),	
				
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'cat',
				'label'   => esc_html__( 'Categories', 'roofix-core' ),
				'options' => $category_dropdown,
				'default' => '0',
			),			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'orderby',
				'label'   => esc_html__( 'Order By', 'roofix-core' ),
				'options' => array(
					'date'        => esc_html__( 'Date (Recents comes first)', 'roofix-core' ),
					'title'       => esc_html__( 'Title', 'roofix-core' ),
					'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'roofix-core' ),
				),
				'default' => 'date',
			),			

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'designation_display',
				'label'       => esc_html__( 'Designation Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Designation. Default: On', 'roofix-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'item_social',
				'label'       => esc_html__( 'Item Social', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Social link. Default: On', 'roofix-core' ),
			),		
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'pagination_display',
				'label'       => esc_html__( 'Pagination Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Pagination. Default: On', 'roofix-core' ),
			),		
			array(
				'mode' => 'section_end',
			),

		// Category Style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_cat_style',
				'label'   => esc_html__( 'Category', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,				
			),				
				
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'cat_typo',
					'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-title',
					
				),
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'designation_typo',
					'label'     => esc_html__( 'Designation Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-subtitle',
					
				),
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'short_typo',
					'label'     => esc_html__( 'Short Content Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .short-content',
					'condition' => array( 'style' => array( 'style3'),'designation_content' => array( 'yes')),
					
				),
			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'social_typo',
					'label'     => esc_html__( 'Social Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-content .item-social li a',
					
				),


			array(
				'mode' => 'section_end',
			),
			// Responsive Columns

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   => esc_html__( 'Number of Responsive Columns', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_lg',
				'label'   => esc_html__( 'Desktops: > 1199px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '3',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_md',
				'label'   => esc_html__( 'Desktops: > 991px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_sm',
				'label'   => esc_html__( 'Tablets: > 767px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '6',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_xs',
				'label'   => esc_html__( 'Phones: < 768px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_mobile',
				'label'   => esc_html__( 'Small Phones: < 480px', 'roofix-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}
	protected function render() {
		$data = $this->get_settings();		
		$template 	= 'team-' . str_replace("style", "", $data['style']);	
		return $this->rt_template( $template, $data );
	}
}