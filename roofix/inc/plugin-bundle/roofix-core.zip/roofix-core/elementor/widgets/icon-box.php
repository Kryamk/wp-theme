<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofix\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class icon_Box extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Icon Box', 'roofix-core' );
		$this->rt_base = 'rt-icon-box';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
	
			array(
					'mode'    => 'section_start',
					'id'      => 'sec_image_icon',
					'label'   => esc_html__( 'Icon', 'roofix-core' ),				
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'icon_layout',
				'label'   => esc_html__( 'Icon Layout', 'roofix-core' ),
				'options' => array(
					'icon-layout-1' => esc_html__( 'Layout 1', 'roofix-core' ),
					'icon-layout-2' => esc_html__( 'Layout 2', 'roofix-core' ),					
					'icon-layout-3' => esc_html__( 'Layout 3', 'roofix-core' ),					
					'icon-layout-4' => esc_html__( 'Layout 4', 'roofix-core' ),					
					'icon-layout-5' => esc_html__( 'Layout 5', 'roofix-core' ),					
					'icon-layout-6' => esc_html__( 'Layout 6', 'roofix-core' ),					
				),
				'default' => 'icon-layout-2',
			),
			 array(
	            'type'    => Controls_Manager::CHOOSE,
	            'id'      => 'icon-alignment',
	            'label'   => esc_html__( 'Style', 'roofix-core' ),

	                'options' => [
	                    'left' => [
	                        'title' => esc_html__( 'Left', 'roofix-core' ),
	                        'icon' => 'fa fa-align-left',
	                    ],
	                    'center' => [
	                        'title' => esc_html__( 'Center', 'roofix-core' ),
	                        'icon' => 'fa fa-align-center',
	                    ],
	                    'right' => [
	                        'title' => esc_html__( 'Right', 'roofix-core' ),
	                        'icon' => 'fa fa-align-right',
	                    ],                   
	                ],
	                
	             'default' => 'left',
	            ),
			array(					 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => [
			     'icon' => [
			       'title' => esc_html__( 'Left', 'roofix-core' ),
			       'icon' => 'fa fa-smile-o',
			     ],
			     'image' => [
			       'title' => esc_html__( 'Center', 'roofix-core' ),
			       'icon' => 'fa fa-image',
			     ],		     
			   ],
			   'id'      => 'icontype',
			   'label'   => esc_html__( 'Media Type', 'roofix-core' ),
			   'default' => 'icon',
			   'label_block' => false,
			   'toggle' => false,				 
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon_class',
				'label'   => esc_html__( 'Icon', 'roofix-core' ),
				'default' => [
			      'value' => 'fas fa-smile-wink',
			      'library' => 'fa-solid',
			  ],	
			  	'condition'   => array('icontype' => array( 'icon' ) ),
			),	
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'icon_image',
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
				'condition'   => array('icontype' => array( 'image' ) ),
				'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'roofix-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',		
				'condition'   => array('icontype' => array( 'image' ) ),
			),			
			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content',
				'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'count_number',
				'label'   => esc_html__( 'Count', 'roofix-core' ),
				'default' => '01',
				'condition' => array('icon_layout' => array('icon-layout-6')),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'default' => 'Lorem Ipsum',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'default' => 'Lorem Ipsum hasbeen standard daand scrambled. Rimply dummy text of the printing and typesetting industry',
			),
			array(
				'type'  				=> Controls_Manager::URL,
				'id'    				=> 'url',
				'label' 				=> esc_html__( 'Link (Optional)', 'roofix-core' ),
				'placeholder' 	=> 'https://your-link.com',
			),
			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_image_style',
				'label'   => esc_html__( 'Image/Icon', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				),

				array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'icon_box_width',
				'label'   		=> esc_html__( 'Icon Box Width', 'roofix-core' ),

				'size_units' => array( 'px' ),		
					'range' => [
				 'px' => [
				   'min' => 0,
				   'max' => 300,
				 ],
				],		
				'default' => array(
				'unit' => 'px',
				'size' => 70,
				),
					'selectors' => array(
						'{{WRAPPER}} .service-box-media .item-icon' => 'width: {{SIZE}}{{UNIT}};',						
					)
				),

				array(
						'type' 				=> Controls_Manager::SLIDER,
						'mode' 				=> 'responsive',
						'id'      		=> 'icon_box_height',
						'label'   		=> esc_html__( 'Icon Box Height', 'roofix-core' ),
						
						'size_units' => array( 'px' ),		
						'range' => [
				 'px' => [
				   'min' => 0,
				   'max' => 300,
				 ],
				],		
				'default' => array(
				'unit' => 'px',
				'size' => 70,
				),
					'selectors' => array(
						'{{WRAPPER}} .service-box-media .item-icon' => 'height: {{SIZE}}{{UNIT}};',						
					)
				),	
				
				array(
					'type' 				=> Controls_Manager::SLIDER,
					'mode' 				=> 'responsive',
					'id'      		=> 'icon_box_padding',
					'label'   		=> esc_html__( 'Icon Box Padding', 'roofix-core' ),
					
					'size_units' => array( 'px' ),		
					'range' => [
				'px' => [
				'min' => 0,
				'max' => 100,
				],
				],		
				'default' => array(
				'unit' => 'px',
				'size' => 10,
				),
					'selectors' => array(
						'{{WRAPPER}} .service-box-media .item-icon' => 'padding: {{SIZE}}{{UNIT}};',						
					)
				),

				array(
					'type' 				=> Controls_Manager::SLIDER,
					'mode' 				=> 'responsive',
					'id'      		=> 'bottom_image_spacing',
					'label'   		=> esc_html__( 'Icon Box Spacing', 'roofix-core' ),						
					'size_units' => array( 'px' ),	
						
					'default' => array(
					'unit' => 'px',
					'size' => 70,
					),
					'selectors' => array(
						'{{WRAPPER}} .service-box-layout2.left .media-body-wrp' => 'padding-left: {{SIZE}}{{UNIT}};',				
						'{{WRAPPER}} .service-box-layout2.center .media-body-wrp' => 'padding-top: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .service-box-layout2.right .media-body-wrp' => 'padding-right: {{SIZE}}{{UNIT}};',				
						'{{WRAPPER}} .icon-layout-4 .media-body-wrp' => 'padding-top: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-box-layout5.left .media-body-wrp' => 'padding-left: {{SIZE}}{{UNIT}};',				
						'{{WRAPPER}} .icon-box-layout5.center .media-body-wrp' => 'padding-top: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-box-layout5.right .media-body-wrp' => 'padding-right: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-box-layout6.left .media-body-wrp' => 'padding-left: {{SIZE}}{{UNIT}};',				
						'{{WRAPPER}} .icon-box-layout6.center .media-body-wrp' => 'padding-top: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-box-layout6.right .media-body-wrp' => 'padding-right: {{SIZE}}{{UNIT}};',
					)
				),

				array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'icon_color',
					'label'   => esc_html__( 'Icon Color', 'roofix-core' ),
					'default' => '',						
					'selectors' => array(
							'{{WRAPPER}} .item-icon i:before' => 'color: {{VALUE}}',							
						),
				),
				array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'icon_hover_color',
					'label'   => esc_html__( 'Icon Hover Color', 'roofix-core' ),
					'default' => '',						
					'selectors' => array(
						'{{WRAPPER}} .icon-box-layout5:hover .icon-layout-5 i' => 'background-color: {{VALUE}}',							
					),
					'condition' => array('icon_layout' => array('icon-layout-5')),
				),	

				array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'icon_font_size',
					'condition' 	=> [
							'icontype' => 'icon',
							],
					'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-icon i',
				),
				
				array(
					'type'    => Controls_Manager::NUMBER,
					'id'      => 'flat_icon_size',
					'label'   => esc_html__( 'Flaticon Size', 'roofix-core' ),
					'default' => '',						
					'selectors' => array(
						'{{WRAPPER}} .item-icon i' => 'font-size: {{VALUE}}px',							
						'{{WRAPPER}} .item-icon i:before' => 'font-size: {{VALUE}}px',							
					),
				),

				array(
					'mode' => 'section_end',
				),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),


			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_title_spacing',
				'label'   		=> esc_html__( 'Bottom Spacing', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),				
				'default' => array(
				'unit' => 'px',
				'size' => 20,
				),
					'selectors' => array(
						'{{WRAPPER}} .item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
					)
				),

			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_color',
					'label'   => esc_html__( 'Title Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
							'{{WRAPPER}} .item-title a' => 'color: {{VALUE}}' ,
						),
				),		
			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_hover_color',
					'label'   => esc_html__( 'Title Hover Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .item-title:hover' => 'color: {{VALUE}}',
							'{{WRAPPER}} .item-title a:hover' => 'color: {{VALUE}}',
						),
				),	

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'title_style',
				'label'       =>esc_html__( 'Title Style', 'roofix-core' ),
				'label_on'    =>esc_html__( 'On', 'roofix-core' ),
				'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' =>esc_html__( 'Show or Hide Title Style. Default: On', 'roofix-core' ),
			),	
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_style_color',
				'label'   => esc_html__( 'Title Style Color', 'roofix-core' ),
				'default' => '#ee212b',
				'condition'   => array('title_style' => array( 'yes' ) ),
				'selectors' => array(
						'{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}',	
						'{{WRAPPER}} .title-style' => 'background-color: {{VALUE}}',	

					),
			),

			array(
			    'type'    => Controls_Manager::CHOOSE,
			    'id'      => 'title_tag',
			    'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
			    'options' => array(
			        'h1'  => [
			            'title' => esc_html__( 'H1', 'roofix-core' ),
			            'icon' => 'eicon-editor-h1'
			        ],
			        'h2'  => [
			            'title' => esc_html__( 'H2', 'roofix-core' ),
			            'icon' => 'eicon-editor-h2'
			        ],
			        'h3'  => [
			            'title' => esc_html__( 'H3', 'roofix-core' ),
			            'icon' => 'eicon-editor-h3'
			        ],
			        'h4'  => [
			            'title' => esc_html__( 'H4', 'roofix-core' ),
			            'icon' => 'eicon-editor-h4'
			        ],
			        'h5'  => [
			            'title' => esc_html__( 'H5', 'roofix-core' ),
			            'icon' => 'eicon-editor-h5'
			        ],
			        'h6'  => [
			            'title' => esc_html__( 'H6', 'roofix-core' ),
			            'icon' => 'eicon-editor-h6'
			        ],
			        'div'  => [
			            'title' => esc_html__( 'div', 'roofix-core' ),
			            'icon' => 'eicon-font'
			        ]
			    ),
			    'default' => 'h3',
			    
			),  
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				 'mode'          => 'responsive',
				'id'      => 'content_margin',
				'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
				'selectors' => array(
				    '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
				),
			'separator' => 'before',
			),  

			array( 
				'mode'      => 'group',
				'type'      => Group_Control_Typography::get_type(),
				'name'      => 'title_typo',
				'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
				'selector'  => '{{WRAPPER}} .item-title',
				

			),	
			array(
					'id'  	=> 'hr-1',
					'type'	=> Controls_Manager::DIVIDER,
					'style' => 'thick',
				),
			array( 
				'mode'      => 'group',
				'type'      => Group_Control_Typography::get_type(),
				'name'      => 'content_typo',
				'label'     => esc_html__( 'Content Typography', 'roofix-core' ),
				'selector'  => '{{WRAPPER}} .item-content',
			 
			),
	
		);
		return $fields;
	}



	protected function render() {
		$data = $this->get_settings();		
		$template 	= 'icon-box-1';
		
		switch ( $data['icon_layout'] ) {			
			case 'icon-layout-6':
			$template = 'icon-box-4';
			break;
			case 'icon-layout-5':
			$template = 'icon-box-3';
			break;
			case 'icon-layout-4':
			$template = 'icon-box-2';
			break;
			default:
			$template = 'icon-box-1';
			break;
		}
			
			
		return $this->rt_template( $template, $data );
	}
}