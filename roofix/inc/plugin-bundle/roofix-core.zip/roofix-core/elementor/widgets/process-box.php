<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofix\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class Process_Box extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Step Flow', 'roofix-core' );
		$this->rt_base = 'rt-process-box';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
		array(
				'mode'    => 'section_start',
				'id'      => 'sec_layout',
				'label'   => esc_html__( 'layout', 'roofix-core' ),				
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1', 'roofix-core' ),
					'style2' => esc_html__( 'Style 2', 'roofix-core' ),					
					'style3' => esc_html__( 'Style 3', 'roofix-core' ),					
					'style4' => esc_html__( 'Style 4', 'roofix-core' ),					
				),
				'default' => 'style1',
			),	


			array(
				'mode' => 'section_end',
			),
			
			array(
					'mode'    => 'section_start',
					'id'      => 'sec_image',
					'label'   => esc_html__( ' Image', 'roofix-core' ),	
					'condition'   => array('style' => array( 'style1', 'style3', 'style4' ) ),
			),			
			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'icontype',
				'label'   => esc_html__( 'Icon Type', 'roofix-core' ),
				'options' => array(
					'icon'  => esc_html__( 'Icon', 'roofix-core' ),
					'image' => esc_html__( 'Custom Image', 'roofix-core' ),
				),
				'default' => 'icon',	
			),
			array(
				'type'    => Controls_Manager::ICONS,
				'id'      => 'icon',
				'label'   => esc_html__( 'Icon', 'roofix-core' ),
				'default' => [
			      'value' => 'fas fa-smile-wink',
			      'library' => 'fa-solid',
			  ],	
			  'condition'   => array( 'icontype' => array( 'icon' )),
			),	

			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'info_image',
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'default' => [
	                'url' => Utils::get_placeholder_image_src(),
	            ],			
				'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
				'condition'   => array( 'icontype' => array( 'image' )),
			),

			array(
				'type'    	=> Group_Control_Image_Size::get_type(),
				'mode'    	=> 'group',
				'label'   	=> esc_html__( 'Image size', 'roofix-core' ),	
				'name' 			=> 'info_image_size', 
				'condition'   => array( 'icontype' => array( 'image' )),
										
			),			

	
			array(
				'mode' => 'section_end',
			),


			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content',
				'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'number',
					'label'   => esc_html__( 'Process number', 'roofix-core' ),
					'default' => '01',
				),	
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'title',
					'label'   => esc_html__( 'Title', 'roofix-core' ),
					'default' => 'Lorem Ipsum',
				),
				array(
					'type'    => Controls_Manager::TEXTAREA,
					'id'      => 'content',
					'label'   => esc_html__( 'Content', 'roofix-core' ),
					'default' => 'Lorem Ipsum hasbeen standard daand scrambled. Rimply dummy text of the printing and typesetting industry',
				),


			array(
				'mode' => 'section_end',
			),

				array(
					'mode'    => 'section_start',
					'id'      => 'sec_button',
					'label'   => esc_html__( 'Button', 'roofix-core' ),	
					'condition'   => array('style' => array( 'style1') ),
								
				),
				array(
						'type'  				=> Controls_Manager::URL,
						'id'    				=> 'url',
						'label' 				=> esc_html__( 'Link (Optional)', 'roofix-core' ),
						'placeholder' 	=> 'https://your-link.com',
					),
					array(
						'type'  => Controls_Manager::TEXT,
						'id'    => 'url_text',
						'label' => esc_html__( 'Botton Text (Optional)', 'roofix-core' ),
						'default' => 'Read More',					
					),
				array(
					'type'    => Controls_Manager::ICON,
					'id'      => 'button_icon',
					'label'   => esc_html__( 'Button Icon', 'roofix-core' ),
					'default' => 'fas fa-angle-right',				
				),	
				array(
					'mode' => 'section_end',
				),


				array(
				'mode'    => 'section_start',
				'id'      => 'sec_image_style',
				'label'   => esc_html__( 'Image/Icon', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition'   => array('style' => array( 'style1' ) ),
				),

				array(
					'type' 				=> Controls_Manager::SLIDER,
					'mode' 				=> 'responsive',
					'id'      		=> 'bottom_image_spacing',
					'label'   		=> esc_html__( 'Image Spacing', 'roofix-core' ),
					'condition' 	=> [
							'style' => 'style1',
							],
					'size_units' => array( 'px' ),				
					'default' => array(
					'unit' => 'px',
					'size' => 25,
					),
						'selectors' => array(
							'{{WRAPPER}} .item-img' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
						)
					),

					array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'icon_color',
					'label'   => esc_html__( 'Icon Color', 'roofix-core' ),
					'default' => '#ee212b',
					'condition' 	=> [
								'style' => 'style2',
							],
					'selectors' => array(
							'{{WRAPPER}} .item-icon i' => 'color: {{VALUE}}',							
						),
				),	

			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'icon_font_size',
					'condition' 	=> [
							'style' => 'style2',
							],
					'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} .item-icon i',
				),



				array(
					'mode' => 'section_end',
				),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_style',
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),


			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'bottom_title_spacing',
				'label'   		=> __( 'Bottom Spacing', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),				
				'default' => array(
				'unit' => 'px',
				'size' => 15,
				),
					'selectors' => array(
						'{{WRAPPER}} .item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',						
					)
				),

			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_color',
					'label'   => esc_html__( 'Title Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
							'{{WRAPPER}} .item-title a' => 'color: {{VALUE}}',
						),
				),	

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'title_style',
				'label'       =>esc_html__( 'Box Style', 'roofix-core' ),
				'label_on'    =>esc_html__( 'On', 'roofix-core' ),
				'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'no',
				'description' =>esc_html__( 'Show or Hide Title Style. Default: On', 'roofix-core' ),
			),	
				array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'title_style_color',
					'label'   => esc_html__( 'Title Style Color', 'roofix-core' ),
					'default' => '#ee212b',
					'condition'   => array('title_style' => array( 'yes' ) ),
					'selectors' => array(
							'{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}',	

						),
				),

			array(
			    'type'    => Controls_Manager::CHOOSE,
			    'id'      => 'title_tag',
			    'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
			    'options' => array(
			        'h1'  => [
			            'title' => esc_html__( 'H1', 'roofix-core' ),
			            'icon' => 'eicon-editor-h1'
			        ],
			        'h2'  => [
			            'title' => esc_html__( 'H2', 'roofix-core' ),
			            'icon' => 'eicon-editor-h2'
			        ],
			        'h3'  => [
			            'title' => esc_html__( 'H3', 'roofix-core' ),
			            'icon' => 'eicon-editor-h3'
			        ],
			        'h4'  => [
			            'title' => esc_html__( 'H4', 'roofix-core' ),
			            'icon' => 'eicon-editor-h4'
			        ],
			        'h5'  => [
			            'title' => esc_html__( 'H5', 'roofix-core' ),
			            'icon' => 'eicon-editor-h5'
			        ],
			        'h6'  => [
			            'title' => esc_html__( 'H6', 'roofix-core' ),
			            'icon' => 'eicon-editor-h6'
			        ],
			        'div'  => [
			            'title' => esc_html__( 'div', 'roofix-core' ),
			            'icon' => 'eicon-font'
			        ]
			    ),
			    'default' => 'h3',
			    
			),  

		array( 
				'mode'      => 'group',
				'type'      => Group_Control_Typography::get_type(),
				'name'      => 'title_typo',
				'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
				'selector'  => '{{WRAPPER}} .item-title',
			),

	array(
			'mode' => 'section_end',
		),


		array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),		

				array(
						'type'    => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'id'      => 'content_padding',
						'label'   => esc_html__( 'Padding', 'roofix-core' ),
						
						'selectors' => array(
								'{{WRAPPER}} p.item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',					
							),
						'separator' => 'before',
					),	
				array(
						'type'    => Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', '%', 'em' ],
						'id'      => 'content_margin',
						'label'   => esc_html__( 'Margin', 'roofix-core' ),					
						'selectors' => array(
								'{{WRAPPER}} p.item-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',					
							),
						'separator' => 'before',
					),	
				           

			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'content_color',
					'label'   => esc_html__( 'Content Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} p.item-content' => 'color: {{VALUE}}',							
						),
				),	
		array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'content_typo',
					'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} p.item-content',
				),

			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_btn_style',
				'label'   => esc_html__( 'Button', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition'   => array('style' => array( 'style1' ) ),
			),

			array( 
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'button_typo',
					'label'     => esc_html__( 'Button Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} a.button-c-style, {{WRAPPER}} a.button-c-style i:before' ,					
				),

			
			array(					 
			   'type'    => Controls_Manager::CHOOSE,
			   'options' => [
			     'icon' => [
			      'before' => esc_html__( 'Before', 'roofix-core' ),
			     	'icon' => 'eicon-text-align-left',
			     ],
			     'after' => [
			       'title' => esc_html__( 'After', 'roofix-core' ),
			       'icon' => 'eicon-text-align-right',
			     ],		     
			   ],
			   'id'      => 'button_icon_position',				 
			   'label'   => esc_html__( 'Icon Position', 'roofix-core' ),
			   'default' => 'after',
			   'label_block' => false,
			   'toggle' => false,	
					'condition' => [
						'button_icon!' => '',
					],			 
			),

			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'button_icon_spacing',
				'label'   		=> esc_html__( 'Position Top', 'roofix-core' ),
				'condition' 	=> [
						'button_icon!' => '',
						],
				'size_units' => array( 'px' ),
					'range' => array(
						'px' => array(
						'min' => 0,
						'max' => 100,
						),
					),
				'default' => array(
				'unit' => 'px',
				'size' => 5,
				),
					'selectors' => array(
						'{{WRAPPER}} .icon-before i' => 'margin-right: {{SIZE}}{{UNIT}};',
						'{{WRAPPER}} .icon-after i' => 'margin-left: {{SIZE}}{{UNIT}};',
					)
				),
			array(
				'mode' => 'section_end',
			),



			
		);
		return $fields;
	}


	protected function render() {
		$data = $this->get_settings();	

			$template 	= 'process-box-' . str_replace("style", "", $data['style']);
		
		return $this->rt_template( $template, $data );
	}
}