<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Base;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Service_Tab extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Service Tab', 'roofix-core' );
		$this->rt_base = 'rt-service-tab';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label'   => esc_html__( 'Tab Title', 'roofix-core' ),
				'default' => esc_html__( '1980', 'roofix-core' ),
                'label_block' => true,
            ]
        );

		$repeater->add_control(
            'ctitle',
            [
                'type' => Controls_Manager::TEXTAREA,
				'label'   => esc_html__( 'Tab Content Title', 'roofix-core' ),
				'default' => esc_html__( 'Roofing whenan unknown printer took
				tomake type specimen book.', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
				'description' => esc_html__( 'Recommended full image', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'content',
            [
                'type' => Controls_Manager::WYSIWYG,
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'default' => esc_html__( 'Roofing whenan unknown printer took a galley of type and scrambleitte
				tomake a type specimen book. It has Roofing whenan unknow near
				printer a took area galley of type and scrambled.', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'icon_class',
            [
                'type' => Controls_Manager::ICONS,
				'label'   => esc_html__( 'Tab Icon', 'roofix-core' ),
				'default' => array(
				  'value' => 'flaticon-mortgage',
				  'library' => 'fa-solid',
			  ),
            ]
        );

		$repeater->add_control(
            'url',
            [
                'type' => Controls_Manager::URL,
				'label' => esc_html__( 'Link (Optional)', 'roofix-core' ),
				'placeholder' => 'https://your-link.com',
            ]
        );

		$repeater->add_control(
            'buttontext',
            [
                'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Button Text', 'roofix-core' ),
				'default' => esc_html__( 'PREMIUM CALCULATE', 'roofix-core' ),
            ]
        );

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'Tab', 'roofix-core' ),
			),
			array (
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'tab_items',
				'label'   => esc_html__( 'Tab Items', 'roofix-core' ),
				'fields'  => $repeater->get_controls(),
				'default' => [
			         ['title' => '1998', ],
			         ['title' => '2000', ],
			         ['title' => '2008', ],
			         ['title' => '2015', ],
			         ['title' => '2000', ],
		       ],
			),
			array(
				'mode' => 'section_end',
			),

			/*Title Style Option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Typo', 'roofix-core' ),
				'selector' => '{{WRAPPER}} .rtin-insurance-tab .rtin-item .rtin-content .rtin-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'roofix-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rtin-insurance-tab .rtin-item .rtin-content .rtin-title' => 'color: {{VALUE}}',
				),
			),


			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {

		$data = $this->get_settings();

		$template = 'rt-tab';

		return $this->rt_template( $template, $data );
	}
}