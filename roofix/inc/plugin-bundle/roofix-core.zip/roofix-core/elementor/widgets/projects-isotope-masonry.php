<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
if ( ! defined( 'ABSPATH' ) ) exit;
class Projects_isotope_masonry extends Custom_Widget_Base {
	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Project Isotope Masonry', 'roofix-core' );
		$this->rt_base = 'rt-projects-isotope-masonry';
		$this->rt_translate = array(
			'cols'  => array(
				'12' => esc_html__( '1 Col', 'roofix-core' ),
				'6'  => esc_html__( '2 Col', 'roofix-core' ),
				'4'  => esc_html__( '3 Col', 'roofix-core' ),
				'3'  => esc_html__( '4 Col', 'roofix-core' ),
				'2'  => esc_html__( '6 Col', 'roofix-core' ),
			),
		);
		parent::__construct( $data, $args );
	}
	private function rt_load_scripts(){
		wp_enqueue_script( 'isotope-pkgd' );
	}
	public function rt_fields(){
		$cpt 								= ROOFIX_CORE_CPT;
		$category_dropdown = "";
		$terms  						= get_terms( array( 'taxonomy' => "{$cpt}_projects_category", 'fields' => 'id=>name' ) );	
		foreach ( $terms as $id => $name ) {
			$category_dropdown[$id] = $name;
		}
		$fields = array(	

			// Layout
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_layout',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1', 'roofix-core' ),
					'style2' => esc_html__( 'Style 2', 'roofix-core' ),
					'style3' => esc_html__( 'Style 3', 'roofix-core' ),
					'style4' => esc_html__( 'Style 4', 'roofix-core' ),
				),
				'default' => 'style1',
			),			

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'filter',
				'label'       => esc_html__( 'Filter Tabs', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Filter Tabs. Default: On', 'roofix-core' ),
			),	
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'category_display',
				'label'       => esc_html__( 'Category Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Categorys. Default: On', 'roofix-core' ),
				'condition' => array( 'style' => array( 'style1','style3','style4' )),	
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'excerpt_display',
				'label'       => esc_html__( 'Excerpt Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'no',
				'description' => esc_html__( 'Categorys. Default: On', 'roofix-core' ),
				'condition' => array( 'style' => array( 'style1' )),	
			),
			 array(
        'type'    => Controls_Manager::SELECT2,
        'id'      => 'no_of_excerpt_words',
        'label'   => esc_html__( 'Number Of words for excerpt', 'roofix-core' ),
        'options' => array(
          '10' => esc_html__( 10, 'roofix-core' ),
          '15' => esc_html__( 15, 'roofix-core' ),
          '20' => esc_html__( 20, 'roofix-core' ),
          '25' => esc_html__( 25, 'roofix-core' ),
          '30' => esc_html__( 30, 'roofix-core' ),
          '35' => esc_html__( 35, 'roofix-core' ),
          '40' => esc_html__( 40, 'roofix-core' ),
          '45' => esc_html__( 45, 'roofix-core' ),
          '50' => esc_html__( 50, 'roofix-core' ),
          '55' => esc_html__( 55, 'roofix-core' ),
        ),
        'default' => 25,
        'condition' => array( 'excerpt_display' => array( 'yes'),'style' => array( 'style1' ) ),

      ),
	array(
		'mode' => 'section_end',
	),
	

			// Data Query
			array(
			'mode'    => 'section_start',
			'id'      => 'sec_query',
			'label'   => esc_html__( 'Query', 'roofix-core' ),
			),			
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'category_list',
					'label'   =>esc_html__( 'Categories', 'roofix-core' ),
					'options' => $category_dropdown,
					'default' => '0',
					'multiple' => true,
				),			
				array(
					'type'    => Controls_Manager::NUMBER,
					'id'      => 'number',
					'label'   =>esc_html__( 'Total number of Projects', 'roofix-core' ),
					'default' => 6,
					'description' =>esc_html__( 'Write -1 to show all', 'roofix-core' ),
				),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'orderby',
					'label'   => esc_html__( 'Order By', 'roofix-core' ),
					'options' => array(
						'date'        => esc_html__( 'Date (Recents comes first)', 'roofix-core' ),
						'title'       => esc_html__( 'Title', 'roofix-core' ),
						'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'roofix-core' ),
					),
					'default' => 'date',
				),
			array(
			'mode' => 'section_end',
			),
			// Button Display
			array(
					'mode'    => 'section_start',
					'id'      => 'sec_button',
					'label'   => esc_html__( 'Button', 'roofix-core' ),				
				),
							array(
								'type'        => Controls_Manager::SWITCHER,
								'id'          => 'btn_display',
								'label'       => esc_html__( 'Button Display', 'roofix-core' ),
								'label_on'    => esc_html__( 'On', 'roofix-core' ),
								'label_off'   => esc_html__( 'Off', 'roofix-core' ),
								'default'     => 'yes',
								'description' => esc_html__( 'Button. Default: On', 'roofix-core' ),
							),
							array(
							'id'        => 'button_type',
							'label'     => esc_html__( 'Button Type', 'roofix-core' ),
							'type'      => Controls_Manager::SELECT,
							'condition' => array( 'btn_display' => array( 'yes' ) ),
							'options' => array(
							  '1' => esc_html__( 'Default Button', 'roofix-core' ),
							  '2' => esc_html__( 'Custom Button', 'roofix-core' ),							 
							),
							'default'   => '1',                    
							),
							array(
								'type'  => Controls_Manager::TEXT,
								'id'    => 'url_text',
								'label' => esc_html__( 'Botton Text (Optional)', 'roofix-core' ),
								'default' => 'DETAILS',		
								 'condition' => array( 'button_type' => array( '2' ),'btn_display' => array( 'yes' ) ),					
							),

							array(
							'type'    => Controls_Manager::ICON,
							'id'      => 'button_icon',
							'label'   => esc_html__( 'Button Icon', 'roofix-core' ),
							'default' => 'fas fa-chevron-right',		
							'condition' => array( 'button_type' => array( '2' ),'btn_display' => array( 'yes' ) ),				
							),	
							array(					 
							 'type'    => Controls_Manager::CHOOSE,
							 'options' => [
							   'icon' => [
							    'before' => esc_html__( 'Before', 'roofix-core' ),
							   	'icon' => 'eicon-text-align-left',
							   ],
							   'after' => [
							     'title' => esc_html__( 'After', 'roofix-core' ),
							     'icon' => 'eicon-text-align-right',
							   ],		     
							 ],
							 'id'      => 'button_icon_position',				 
							 'label'   => esc_html__( 'Icon Position', 'roofix-core' ),
							 'default' => 'after',
							 'label_block' => false,
							 'toggle' => false,	
								'condition' => [
									'button_icon!' => '',
									'button_type' =>  '2' ,
									'btn_display' => 'yes', 

								],			 
							),
							array(
							'type' 				=> Controls_Manager::SLIDER,
							'mode' 				=> 'responsive',
							'id'      		=> 'button_icon_spacing',
							'label'   		=> __( 'Position Icon', 'roofix-core' ),
							'condition' 	=> [
								'	button_icon!' => '',
									'button_type' =>  '2' ,
									'btn_display' => 'yes', 
									],
							'size_units' => array( 'px' ),
								'range' => array(
									'px' => array(
									'min' => 0,
									'max' => 100,
									),
								),
							'default' => array(
							'unit' => 'px',
							'size' => 5,
							),
								'selectors' => array(
									'{{WRAPPER}} .item-btn-wrap .item-btn.before i' => 'margin-right: {{SIZE}}{{UNIT}};',
									'{{WRAPPER}} .item-btn-wrap .item-btn.after i' => 'margin-left: {{SIZE}}{{UNIT}};',
								)
							),
				array(
					'mode' => 'section_end',
				),

			// Title Style
				
			array(
					'mode'    => 'section_start',
					'id'      => 'sec_title_style',
					'label'   => esc_html__( 'Title', 'roofix-core' ),
					'tab'     => Controls_Manager::TAB_STYLE,
				),
						array(
							'type'        => Controls_Manager::SWITCHER,
							'id'          => 'title_style',
							'label'       =>esc_html__( 'Title Style', 'roofix-core' ),
							'label_on'    =>esc_html__( 'On', 'roofix-core' ),
							'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
							'default'     => 'no',
							'description' =>esc_html__( 'Show or Hide Title Style. Default: Off', 'roofix-core' ),
							),	
						array(
							'type'    => Controls_Manager::COLOR,
							'id'      => 'title_color',
							'label'   => esc_html__( 'Title Color', 'roofix-core' ),
							'default' => '#111111',
							'condition'   => array('title_style' => array( 'yes' ) ),
							'selectors' => array(
									'{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
									'{{WRAPPER}} .item-title a' => 'color: {{VALUE}}',
								),
							),	
						array(
							'type'    => Controls_Manager::COLOR,
							'id'      => 'title_hover_color',
							'label'   => esc_html__( 'Title Hover Color', 'roofix-core' ),
							'default' => '#333333',
							'condition'   => array('title_style' => array( 'yes' ) ),
							'selectors' => array(					
									'{{WRAPPER}} .item-title a:hover' => 'color: {{VALUE}}',
								),
							),	
						array(
						  'type'    => Controls_Manager::CHOOSE,
						  'id'      => 'title_tag',
						  'label'   => esc_html__( 'Title HTML Tag', 'roofix-core' ),
						  'condition'   => array('title_style' => array( 'yes' ) ),
						  'options' => array(
						      'h1'  => [
						          'title' => esc_html__( 'H1', 'roofix-core' ),
						          'icon' => 'eicon-editor-h1'
						      ],
						      'h2'  => [
						          'title' => esc_html__( 'H2', 'roofix-core' ),
						          'icon' => 'eicon-editor-h2'
						      ],
						      'h3'  => [
						          'title' => esc_html__( 'H3', 'roofix-core' ),
						          'icon' => 'eicon-editor-h3'
						      ],
						      'h4'  => [
						          'title' => esc_html__( 'H4', 'roofix-core' ),
						          'icon' => 'eicon-editor-h4'
						      ],
						      'h5'  => [
						          'title' => esc_html__( 'H5', 'roofix-core' ),
						          'icon' => 'eicon-editor-h5'
						      ],
						      'h6'  => [
						          'title' => esc_html__( 'H6', 'roofix-core' ),
						          'icon' => 'eicon-editor-h6'
						      ],
						      'div'  => [
						          'title' => esc_html__( 'div', 'roofix-core' ),
						          'icon' => 'eicon-font'
						      ]
						  ),
						  'default' => 'h3',
						  
						),  
						array( 
							'mode'      => 'group',
							'type'      => Group_Control_Typography::get_type(),
							'name'      => 'title_typo',
							'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
							'selector'  => '{{WRAPPER}} .item-title',
							'condition'   => array('title_style' => array( 'yes' ) ),
						),

			array(
				'mode' => 'section_end',
			),	

			// Category Style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_cat_style',
				'label'   => esc_html__( 'Category', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition' => array( 'category_display' => array( 'yes') ),
			),
					array(
						'type'        => Controls_Manager::SWITCHER,
						'id'          => 'cat_style',
						'label'       =>esc_html__( 'Categories Style', 'roofix-core' ),
						'label_on'    =>esc_html__( 'On', 'roofix-core' ),
						'label_off'   =>esc_html__( 'Off', 'roofix-core' ),
						'default'     => 'no',
						'description' =>esc_html__( 'Show or Hide Title Style. Default: Off', 'roofix-core' ),
					),	
					array(
						'type'    => Controls_Manager::COLOR,
						'id'      => 'cat_color',
						'label'   => esc_html__( 'Categories Color', 'roofix-core' ),
						'default' => '#111111',
						'condition'   => array('cat_style' => array( 'yes' ) ),
						'selectors' => array(
								'{{WRAPPER}} .item-subtitle a' => 'color: {{VALUE}}',						
							),
					),	
					array(
						'type'    => Controls_Manager::COLOR,
						'id'      => 'cat_hover_color',
						'label'   => esc_html__( 'Categories Hover Color', 'roofix-core' ),
						'default' => '#333333',
						'condition'   => array('cat_style' => array( 'yes' ) ),
						'selectors' => array(					
									'{{WRAPPER}} .item-subtitle a:hover' => 'color: {{VALUE}}',	
							),
					),				 
					array( 
							'mode'      => 'group',
							'type'      => Group_Control_Typography::get_type(),
							'name'      => 'cat_typo',
							'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
							'selector'  => '{{WRAPPER}} .item-subtitle a',
							'condition'   => array('cat_style' => array( 'yes' ) ),
						),
			array(
				'mode' => 'section_end',
			),

			// Content Style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition' => array( 'excerpt_display' => array( 'yes') ),
			),
					array(
						'type'        => Controls_Manager::SWITCHER,
						'id'          => 'content_style',
						'label'       => esc_html__( 'Content Style', 'roofix-core' ),
						'label_on'    => esc_html__( 'On', 'roofix-core' ),
						'label_off'   => esc_html__( 'Off', 'roofix-core' ),
						'default'     => 'no',
						'description' => esc_html__( 'Show or Hide Title Style. Default: Off', 'roofix-core' ),
					),	
					array(
							'type'    => Controls_Manager::COLOR,
							'id'      => 'content_color',
							'label'   => esc_html__( 'Content Color', 'roofix-core' ),
							'default' => '#cccccc',
							'condition'   => array('content_style' => array( 'yes' ) ),
							'selectors' => array(
									'{{WRAPPER}} p.item-content' => 'color: {{VALUE}}',							
								),
						),	
					array( 
						'mode'      => 'group',
						'type'      => Group_Control_Typography::get_type(),
						'condition'   => array('content_style' => array( 'yes' ) ),
						'name'      => 'content_typo',
						'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
						'selector'  => '{{WRAPPER}} p.project-excerpt',
					),
			array(
				'mode' => 'section_end',
			),

			// Button Style
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_btn_style',
				'label'   => esc_html__( 'Button', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
				'condition' => array( 'btn_display' => array( 'yes') ),
			),
				array( 
						'mode'      => 'group',
						'type'      => Group_Control_Typography::get_type(),
						'name'      => 'button_typo',
						'label'     => esc_html__( 'Button Typography', 'roofix-core' ),
						'selector'  => '{{WRAPPER}} .item-btn-wrap .item-btn, {{WRAPPER}} .item-btn-wrap .item-btn i' ,
						
					),
			array(
				'mode' => 'section_end',
			),

			// Responsive Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   => esc_html__( 'Number of Responsive Columns', 'roofix-core' ),
			),
					array(
						'type'    => Controls_Manager::SELECT2,
						'id'      => 'col_lg',
						'label'   => esc_html__( 'Desktops: > 1199px', 'roofix-core' ),
						'options' => $this->rt_translate['cols'],
						'default' => '4',
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'id'      => 'col_md',
						'label'   => esc_html__( 'Desktops: > 991px', 'roofix-core' ),
						'options' => $this->rt_translate['cols'],
						'default' => '4',
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'id'      => 'col_sm',
						'label'   => esc_html__( 'Tablets: > 767px', 'roofix-core' ),
						'options' => $this->rt_translate['cols'],
						'default' => '6',
					),
					array(
						'type'    => Controls_Manager::SELECT2,
						'id'      => 'col_xs',
						'label'   => esc_html__( 'Phones: < 768px', 'roofix-core' ),
						'options' => $this->rt_translate['cols'],
						'default' => '12',
					),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		$this->rt_load_scripts();
		$template 	= 'projects-isotope-' . str_replace("style", "", $data['style']);		
		return $this->rt_template( $template, $data );
	}
}