<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;
use radiustheme\Roofix\Helper;

if ( ! defined( 'ABSPATH' ) ) exit;

class CTA extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = __( 'Call to Action', 'roofix-core' );
		$this->rt_base = 'rt-cta';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(		
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_layout',
				'label'   => esc_html__( 'General', 'roofix-core' ),
			),
				array(
					'type'    => Controls_Manager::SELECT2,
					'id'      => 'layout',
					'label'   => esc_html__( 'Layout', 'roofix-core' ),
					'options' => array(
						'layout1' => esc_html__( 'Layout 1', 'roofix-core' ),
						'layout2' => esc_html__( 'Layout 2', 'roofix-core' ),	
                        'layout3' => esc_html__( 'Layout 3', 'roofix-core' ),  
                        'layout4' => esc_html__( 'Layout 4', 'roofix-core' ),  
					),
					'default' => 'layout1',
				),
			array(
            'type'    => Controls_Manager::CHOOSE,
            'id'      => 'icon-alignment',
            'label'   => esc_html__( 'Align Style', 'roofix-core' ),
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'roofix-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'roofix-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'roofix-core' ),
                        'icon' => 'fa fa-align-right',
                    ],                   
                ],
                 'condition' => array( 'layout' => array( 'layout1', 'layout2', 'layout3' ) ),  
             'default' => 'left',
            ),

			array(
				'mode' => 'section_end',
			),	

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_title_content',
				'label'   => esc_html__( 'Title / Content', 'roofix-core' ),
			),	
				array(
					'type'    => Controls_Manager::TEXTAREA,
					'id'      => 'title',
					'label'   => esc_html__( 'Title', 'roofix-core' ),
					'default' => 'Lorem Ipsum has been standard daand scrambled',
				),
					array(
					'type'    => Controls_Manager::TEXTAREA,
					'id'      => 'subtitle',
					'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
					'default' => 'Lorem Ipsum has been standard daand scrambled',			
					 'condition' => array( 'layout' => array( 'layout2', 'layout3' , 'layout4' ) ),				
				),	
			
			array(
				'mode' => 'section_end',
			),

			array(
				'mode'    => 'section_start',
				'id'      => 'sec_button',
				'label'   => esc_html__( 'Button', 'roofix-core' ),
                 'condition' => array( 'layout' => array( 'layout1', 'layout2', 'layout3' ) ),         
			),
				array(
					'type'    => Controls_Manager::TEXT,
					'id'      => 'buttontext',
					'label'   => esc_html__( 'Button Text', 'roofix-core' ),
					'default' => 'GET A QUOTE',
				),
				array(
					'type'    => Controls_Manager::URL,
					'id'      => 'buttonurl',
					'label'   => esc_html__( 'Button URL', 'roofix-core' ),
					'placeholder' => 'https://your-link.com',
				),
			array(
				'mode' => 'section_end',
			),		

         // Title style
        array(
            'mode'    => 'section_start',
            'id'      => 'sec_title_style',
            'label'   => esc_html__( 'Title', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,

        ),
       

        array(
            'type'    => Controls_Manager::COLOR,
            'id'      => 'title_color',
            'label'   => esc_html__( 'Color', 'roofix-core' ),
            'default' => '#111111',                       
            'selectors' => array(
                    '{{WRAPPER}} .item-title' => 'color: {{VALUE}}',                           
                ),
        ),  
        array( 
            'mode'      => 'group',
            'type'      => Group_Control_Typography::get_type(),
            'name'      => 'title_font_size',                
            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  => '{{WRAPPER}} .item-title',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
             'mode'          => 'responsive',
            'id'      => 'title_padding',
            'label'   => esc_html__( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
            ),
            'separator' => 'before',
        ),  
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
             'mode'          => 'responsive',
            'id'      => 'title_margin',
            'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors' => array(
                '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator' => 'before',
        ),  

      array(
          'mode' => 'section_end',
      ),  

       // Title style
        array(
            'mode'    => 'section_start',
            'id'      => 'sec_sub_title_style',
            'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
             'condition' => array( 'layout' => array( 'layout2', 'layout3' , 'layout4' ) ),	
        ),
       

        array(
            'type'    => Controls_Manager::COLOR,
            'id'      => 'sub_title_color',
            'label'   => esc_html__( 'Color', 'roofix-core' ),
            'default' => '#111111',                       
            'selectors' => array(
                    '{{WRAPPER}} .item-sub-title' => 'color: {{VALUE}}',                           
                ),
        ),  
        array( 
            'mode'      => 'group',
            'type'      => Group_Control_Typography::get_type(),
            'name'      => 'sub_title_font_size',                
            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
            'selector'  => '{{WRAPPER}} .item-sub-title',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
             'mode'          => 'responsive',
            'id'      => 'sub_title_padding',
            'label'   => esc_html__( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .item-sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                   
            ),
            'separator' => 'before',
        ),  
        array(
            'type'    => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em' ],
             'mode'          => 'responsive',
            'id'      => 'sub_title_margin',
            'label'   => esc_html__( 'Margin', 'roofix-core' ),                 
            'selectors' => array(
                '{{WRAPPER}} .item-sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
            ),
            'separator' => 'before',
        ),  

      array(
          'mode' => 'section_end',
      ),  

      
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		switch ( $data['layout'] ) {
			case 'layout2':
				$template = 'cta-2';
			break;	
			case 'layout3':
				$template = 'cta-3';
			break;	
			case 'layout4':
				$template = 'cta-4';
			break;			
			default:
				$template = 'cta-1';
		break;
		}
		return $this->rt_template( $template, $data );
	}
}