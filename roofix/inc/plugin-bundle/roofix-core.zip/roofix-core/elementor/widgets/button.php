<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit;

class Button extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'Roofix Button', 'roofix-core' );
		$this->rt_base = 'rt-button';	
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'roofix-core' ),
				'options' => array(
					'1' => esc_html__( 'Style 1', 'roofix-core' ),
					'2' => esc_html__( 'Style 2', 'roofix-core' ),
					'3' => esc_html__( 'Style 3', 'roofix-core' ),
					'4' => esc_html__( 'Style 4', 'roofix-core' ),
				),
				'default' => '1',
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'btntext',
				'label'   => esc_html__( 'Button Text', 'roofix-core' ),
				'default' => 'Lorem Ipsum',
			),
			array(
				'type'  => Controls_Manager::URL,
				'id'    => 'url',
				'label' => esc_html__( 'Button Link', 'roofix-core' ),
				'placeholder' => 'https://your-link.com',
			),
			array(
				'type' 				=> Controls_Manager::SLIDER,
				'mode' 				=> 'responsive',
				'id'      		=> 'btn_width',
				'label'   		=> esc_html__( 'Icon Box Width', 'roofix-core' ),

				'size_units' => array( 'px' ),		
					'range' => [
				 'px' => [
				   'min' => 0,
				   'max' => 300,
				 ],
				],		
				'default' => array(
				'unit' => 'px',
				'size' => 120,
				),
					'selectors' => array(
						'{{WRAPPER}} .rten-button-lg' => 'width: {{SIZE}}{{UNIT}};',						
					)
				),

			array(
				'type'    => Controls_Manager::CHOOSE,
				'mode'    => 'responsive',
				'id'      => 'align',
				'label'   => esc_html__( 'Alignment', 'roofix-core' ),

					'options' => array(

					'left'    => array(
						'title' => esc_html__( 'Left', 'roofix-core' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'roofix-core' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => esc_html__( 'Right', 'roofix-core' ),
						'icon' => 'eicon-text-align-right',
					),

				),
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'prefix_class' => 'content-align-%s',
				'default' => 'left',
				'selectors' => array(
					'{{WRAPPER}} .rt-el-btn' => 'text-align: {{VALUE}};',
				),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}
	protected function render() {
		$data 		= $this->get_settings();	
		$template 	= 'button';
		return $this->rt_template( $template, $data );		
	}
}