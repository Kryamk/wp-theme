<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) exit;

class Testimonials extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){

		$this->rt_name = esc_html__( 'Testimonials Slider', 'roofix-core' );
		$this->rt_base = 'rt-testimonials';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
            'image',
            [
                'type' => Controls_Manager::MEDIA,
				'label'   => esc_html__( 'Image', 'roofix-core' ),
				'description' => esc_html__( 'Image size should be 90x90 px', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label'   => esc_html__( 'Title', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'subtitle',
            [
                'type' => Controls_Manager::TEXT,
                'label'   => esc_html__( 'Subtitle', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'content',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label'   => esc_html__( 'Testimonials Content', 'roofix-core' ),
            ]
        );

		$repeater->add_control(
            'rating',
            [
                'type' => Controls_Manager::SELECT2,
                'label'   => esc_html__( 'Rating', 'roofix-core' ),
				'options' => array(
					'1' => esc_html__( 'Rating 1', 'roofix-core' ),
					'2' => esc_html__( 'Rating 2', 'roofix-core' ),
					'3' => esc_html__( 'Rating 3', 'roofix-core' ),
					'4' => esc_html__( 'Rating 4', 'roofix-core' ),
					'5' => esc_html__( 'Rating 5', 'roofix-core' ),
				),
            ]
        );

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'roofix-core' ),

			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Layout', 'roofix-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Layout 1', 'roofix-core' ),
					'layout2' => esc_html__( 'Layout 2', 'roofix-core' ),
					'layout3' => esc_html__( 'Layout 3', 'roofix-core' ),
					'layout4' => esc_html__( 'Layout 4', 'roofix-core' ),
					'layout5' => esc_html__( 'Layout 5', 'roofix-core' ),
					'layout6' => esc_html__( 'Layout 6', 'roofix-core' ),
					'layout7' => esc_html__( 'Layout 7', 'roofix-core' ),
					'layout8' => esc_html__( 'Layout 8', 'roofix-core' ),
					'layout9' => esc_html__( 'Layout 9', 'roofix-core' ),
				),
				'default' => 'layout1',
			),

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'rating_display',
				'label'       => esc_html__( 'Rating Display', 'roofix-core' ),
				'label_on'    => esc_html__( 'On', 'roofix-core' ),
				'label_off'   => esc_html__( 'Off', 'roofix-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Rating. Default: On', 'roofix-core' ),
				'condition'   => array( 'layout' => array( 'layout2')),
			),

			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'testimonials',
				'label'   => esc_html__( 'Add as many testimonials as you want', 'roofix-core' ),
				'condition'   => array( 'layout' => array( 'layout1' ,'layout4' ,'layout2','layout5','layout6','layout7','layout8','layout9')),
				'fields'  => $repeater->get_controls(),
				'default' => array(
					array('title' => 'Robert Adison', 'subtitle' => 'Professor', 'content' => 'Rimply dummy text of the printing and tRimply dummy text of the printing and typesetting industry.
                                psum has been the industry.', 'rating' => 5 ),
					array('title' => 'Robert Adison', 'subtitle' => 'Professor', 'content' => 'Rimply dummy text of the printing and tRimply dummy text of the printing and typesetting industry.
                                psum has been the industry.', 'rating' => 5 ),

				),
			),
			array(
				'mode' => 'section_end',
			),

			// Slider options
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider',
				'label'       => esc_html__( 'Slider Options', 'roofix-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_nav',
				'label'       => esc_html__( 'Navigation Arrow', 'roofix-core' ),
			),

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'vertical',
				'label'       => esc_html__( 'Vertical slide', 'roofix-core' ),
			),

			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_autoplay',
				'label'       => esc_html__( 'Autoplay', 'roofix-core' ),
				'default'     => 'yes',
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'id'          => 'speed',
				'label'       => esc_html__( 'Autoplay speed', 'roofix-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10000,
                        'step' => 500,
                    ],
                ],
                'size_units' => [ 'px'],
                'default' => [
                    'size' => 2500,
                ],
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'id'          => 'space',
				'label'       => esc_html__( 'Inter slider spacing', 'roofix-core' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'size_units' => [ 'px'],
                'default' => [
                    'size' => 15,
                ],
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'id'          => 'item',
				'label'       => esc_html__( 'Desktop items', 'roofix-core' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'size_units' => [ 'px'],
                'default' => [
                    'size' => 3,
                ],
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'id'          => 'item_tablet',
				'label'       => esc_html__( 'Tablet items', 'roofix-core' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'size_units' => [ 'px'],
                'default' => [
                    'size' => 3,
                ],
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'id'          => 'item_mobile',
				'label'       => esc_html__( 'Mobile items', 'roofix-core' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'size_units' => [ 'px'],
                'default' => [
                    'size' => 1,
                ],
			),

			array(
				'type'        => Controls_Manager::SLIDER,
				'mode'      => 'responsive',
				'id'          => 'vertical_slide_height',
				'label'       => esc_html__( 'Slider height', 'roofix-core' ),
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                        'step' => 1,
                    ],
                ],
                'size_units' => [ 'px'],
                'condition'   => array( 'layout' => array( 'layout8')),
                'default' => [
                    'size' => 470,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                ],
			),

			array(
				'mode' => 'section_end',
			),

			// Title style
	        array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_title_style',
	            'label'   => esc_html__( 'Title', 'roofix-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),


	        array(
	            'type'    => Controls_Manager::COLOR,
	            'id'      => 'title_color',
	            'label'   => __( 'Color', 'roofix-core' ),
	            'default' => '#111111',
	            'selectors' => array(
	                    '{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
	                ),
	        ),
	        array(
	            'mode'      => 'group',
	            'type'      => Group_Control_Typography::get_type(),
	            'name'      => 'title_font_size',
	            'label'     => esc_html__( 'Icon Typography', 'roofix-core' ),
	            'selector'  => '{{WRAPPER}} .item-title',
	        ),
	        [
	            'type'    => Controls_Manager::DIMENSIONS,
	            'size_units' => [ 'px', '%', 'em' ],
	             'mode'          => 'responsive',
	            'id'      => 'title_padding',
	            'label'   => __( 'Padding', 'roofix-core' ),
	            'selectors' => [
	                '{{WRAPPER}} .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
	            ],
	            'separator' => 'before',
	        ],
	        [
	            'type'    => Controls_Manager::DIMENSIONS,
	            'size_units' => [ 'px', '%', 'em' ],
	             'mode'          => 'responsive',
	            'id'      => 'title_margin',
	            'label'   => __( 'Margin', 'roofix-core' ),
	            'selectors' => [
	                '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
	            ],
	            'separator' => 'before',
	        ],
	        [
                'mode' => 'section_end',
            ],

        // section subtitle  style
        array(
            'mode'    => 'section_start',
            'id'      => 'sec_subtitle_style',
            'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
            'tab'     => Controls_Manager::TAB_STYLE,
        ),


        array(
            'type'    => Controls_Manager::COLOR,
            'id'      => 'subtitle_color',
            'label'   => __( 'Color', 'roofix-core' ),
            'default' => '#646464',
            'selectors' => array(
                '{{WRAPPER}} .item-subtitle' => 'color: {{VALUE}}',
            ),
        ),
        array(
            'mode'      => 'group',
            'type'      => Group_Control_Typography::get_type(),
            'name'      => 'subtitle_font_size',
            'label'     => esc_html__( 'Typography', 'roofix-core' ),
            'selector'  => '{{WRAPPER}} .item-subtitle',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
             'mode'          => 'responsive',
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'subtitle_padding',
            'label'   => __( 'Padding', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .item-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
            ),
            'separator' => 'before',
        ),
        array(
            'type'    => Controls_Manager::DIMENSIONS,
             'mode'          => 'responsive',
            'size_units' => [ 'px', '%', 'em' ],
            'id'      => 'subtitle_margin',
            'label'   => __( 'Margin', 'roofix-core' ),
            'selectors' => array(
                '{{WRAPPER}} .item-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
            ),
            'separator' => 'before',
        ),

        array(
            'mode' => 'section_end',
        ),
        array(
				'mode'    => 'section_start',
				'id'      => 'sec_content_style',
				'label'   => esc_html__( 'Content', 'roofix-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			array(
					'type'    => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'id'      => 'content_padding',
					'label'   => esc_html__( 'Padding', 'roofix-core' ),

					'selectors' => array(
							'{{WRAPPER}} p.tcontent' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
						),
					'separator' => 'before',
				),
			array(
					'type'    => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'id'      => 'content_margin',
					'label'   => esc_html__( 'Margin', 'roofix-core' ),
					'selectors' => array(
							'{{WRAPPER}} p.tcontent' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
						),
					'separator' => 'before',
				),
			array(
					'type'    => Controls_Manager::COLOR,
					'id'      => 'content_color',
					'label'   => esc_html__( 'Content Color', 'roofix-core' ),
					'default' => '',
					'selectors' => array(
							'{{WRAPPER}} p.tcontent' => 'color: {{VALUE}}',
						),
				),
				array(
					'mode'      => 'group',
					'type'      => Group_Control_Typography::get_type(),
					'name'      => 'content_typo',
					'label'     => esc_html__( 'Title Typography', 'roofix-core' ),
					'selector'  => '{{WRAPPER}} p.tcontent',
				),

			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {

		$data = $this->get_settings();
		$owl_data = array(

			'autoplay' => $data['slider_autoplay'] == 'yes' ? true : false,
			'speed'  => $data['speed']['size'],
			'space' => $data['space']['size'],
			'items'  => $data['item']['size'],
			'items_tablet'  => $data['item_tablet']['size'],
			'items_mobile'  => $data['item_mobile']['size'],
			'direction' => $data['vertical'] == 'yes' ? 'vertical' : 'horizontal',
		);

		$data['owl_data'] = json_encode( $owl_data );
		$template = 'testimonial/'.$data['layout'];
		return $this->rt_template( $template, $data );
	}

}