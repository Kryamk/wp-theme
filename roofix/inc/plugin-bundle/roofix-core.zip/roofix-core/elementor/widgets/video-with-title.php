<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Roofix_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class Video_With_Title extends Custom_Widget_Base
{
    public function __construct($data = [], $args = null)
    {
        $this->rt_name = esc_html__('Video With Content', 'roofix-core');
        $this->rt_base = 'rt-video-with-title';
        parent::__construct($data, $args);
    }

    public function rt_fields()
    {

		$r5 = new \Elementor\Repeater();

		$r5->add_control(
            'subtitle',
            [
                'type' => Controls_Manager::TEXTAREA,
				'label'   => esc_html__( 'Sub Title', 'roofix-core' ),
            ]
        );

		$r5->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
				'label'   => esc_html__( 'Title', 'roofix-core' ),
				'label_block' => true,
            ]
        );

        $r5->add_control(
            'content',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label'   => esc_html__( 'Content', 'roofix-core' ),
            ]
        );

        $r5->add_control(
            'content_list',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label'   => esc_html__( 'List', 'roofix-core' ),
            ]
        );

		$r123 = new \Elementor\Repeater();

        $r123->add_control(
            'list_title',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label'   => esc_html__( 'List Title', 'roofix-core' ),
            ]
        );

        $r123->add_control(
            'url',
            [
                'type' => Controls_Manager::URL,
                'label'   => esc_html__( 'Link (Optional', 'roofix-core' ),
            ]
        );

        $fields = array(

            array(
                'mode'  => 'section_start',
                'id'    => 'sec_layout',
                'label' => esc_html__('Layout', 'roofix-core'),
            ),

            array(
                'type'    => Controls_Manager::SELECT2,
                'id'      => 'layout',
                'label'   => esc_html__('Layout', 'roofix-core'),
                'options' => array(
                    'layout1' => esc_html__('Layout 1', 'roofix-core'),
                    'layout2' => esc_html__('Layout 2', 'roofix-core'),
                    'layout3' => esc_html__('Layout 3', 'roofix-core'),
                    'layout4' => esc_html__('Layout 4', 'roofix-core'),
                    'layout5' => esc_html__('Layout 5', 'roofix-core'),
                    'layout6' => esc_html__('Layout 6', 'roofix-core'),

                ),
                'default' => 'layout1',
            ),

            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'      => 'section_start',
                'id'        => 'sec_content_item',
                'label'     => esc_html__('Content Items', 'roofix-core'),
                'condition' => array('layout' => array('layout5')),
            ),

            array(
                'type'      => Controls_Manager::REPEATER,
                'id'        => 'content_slide_item',
                'label'     => esc_html__('Add as many list as you want', 'roofix-core'),
                'condition' => array('layout' => array('layout5')),
                'fields'  => $r5->get_controls(),

                'default'   => [
                    ['subtitle' => 'Why Choose Us'],
                    ['title' => 'What Reasons For People Choosing'],
                    ['content' => 'Mintech has been helping organizations throughout
					the World to manage their IT with our unique appr
					been helping organizations.'],
                ],
            ),

            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'      => 'section_start',
                'id'        => 'sec_title',
                'label'     => esc_html__('Title / Content', 'roofix-core'),
                'condition' => array('layout' => array('layout1', 'layout2', 'layout3', 'layout4')),
            ),

            array(
                'type'    => Controls_Manager::TEXTAREA,
                'id'      => 'subtitle',
                'label'   => esc_html__('Sub Title', 'roofix-core'),
                'default' => 'Lorem Ipsum',
            ),

            array(
                'type'    => Controls_Manager::TEXTAREA,
                'id'      => 'title',
                'label'   => esc_html__('Title', 'roofix-core'),
                'default' => 'Lorem Ipsum Dummy Text',
            ),
            array(
                'type'    => Controls_Manager::TEXTAREA,
                'id'      => 'content',
                'label'   => esc_html__('Content', 'roofix-core'),
                'default' => 'Bhen an unknown printer took a galley of type and are scrambled it to make a type specimen book. It haeys urvived notbut also the leap electronic type setting remaining essentially.Bhen an unknown printer took a galley of type and are scrambled it to make a type specnotbut also the leap electronic.',
            ),

            array(
                'type'      => Controls_Manager::REPEATER,
                'id'        => 'list',
                'label'     => esc_html__('Add as many list as you want', 'roofix-core'),
                'condition' => array('layout' => array('layout1', 'layout2', 'layout3')),
                'fields'    => $r123->get_controls(),

                'default'   => [
                    ['list_title' => 'Expert & Professional Engineers'],
                    ['list_title' => 'We are Award Winning Company'],
                    ['list_title' => 'Fully Satisfaction Guarantee'],
                    ['list_title' => '35 + Successfull Projects done'],
                ],
            ),
            array(
                'mode' => 'section_end',
            ),

            array(
                'mode'  => 'section_start',
                'id'    => 'sec_video',
                'label' => esc_html__('Video / Image', 'roofix-core'),
            ),
            array(
                'type'        => Controls_Manager::MEDIA,
                'id'          => 'image',
                'label'       => esc_html__('Image', 'roofix-core'),
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'description' => esc_html__('Recommended full image', 'roofix-core'),
            ),
            array(
                'type'      => Group_Control_Image_Size::get_type(),
                'mode'      => 'group',
                'label'     => esc_html__('image size', 'roofix-core'),
                'name'      => 'image_size',
                'separator' => 'none',
            ),

            array(
                'type'    => Controls_Manager::TEXTAREA,
                'id'      => 'videourl',
                'label'   => esc_html__('Video URL', 'roofix-core'),
                'default' => 'http://www.youtube.com/watch?v=1iIZeIy7TqM',
            ),
            array(
                'mode' => 'section_end',
            ),

            // Title style
            array(
                'mode'  => 'section_start',
                'id'    => 'sec_title_style',
                'label' => esc_html__('Title', 'roofix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ),

            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_color',
                'label'     => __('Color', 'roofix-core'),
                'default'   => '#111111',
                'selectors' => array(
                    '{{WRAPPER}} .item-title' => 'color: {{VALUE}}',
                ),
            ),
            array(
                'mode'     => 'group',
                'type'     => Group_Control_Typography::get_type(),
                'name'     => 'title_font_size',
                'label'    => esc_html__('Icon Typography', 'roofix-core'),
                'selector' => '{{WRAPPER}} .item-title',
            ),

            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'id'         => 'title_padding',
                'label'      => __('Padding', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),
            array(
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'id'         => 'title_margin',
                'label'      => __('Margin', 'roofix-core'),
                'selectors'  => array(
                    '{{WRAPPER}} .item-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ),
                'separator'  => 'before',
            ),

            array(
                'type'        => Controls_Manager::SWITCHER,
                'id'          => 'title_style',
                'label'       => esc_html__('Title Style', 'roofix-core'),
                'label_on'    => esc_html__('On', 'roofix-core'),
                'label_off'   => esc_html__('Off', 'roofix-core'),
                'default'     => 'no',
                'description' => esc_html__('Show or Hide Title Style. Default: On', 'roofix-core'),
            ),
            array(
                'type'      => Controls_Manager::COLOR,
                'id'        => 'title_style_color',
                'label'     => __('Title Style Color', 'roofix-core'),
                'default'   => '#ee212b',
                'condition' => array('title_style' => array('yes')),
                'selectors' => array(
                    '{{WRAPPER}} .title-style::after' => 'background-color: {{VALUE}}',

                ),
            ),

            array(
                'mode' => 'section_end',
            ),

        );
        return $fields;
    }

    protected function render()
    {
        $data     = $this->get_settings();
        $template = 'video-title/video-with-title-' . str_replace("layout", "", $data['layout']);
        return $this->rt_template($template, $data);
    }
}
