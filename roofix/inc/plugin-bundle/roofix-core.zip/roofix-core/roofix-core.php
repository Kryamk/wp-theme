<?php
/*
Plugin Name: Roofix-Core
Plugin URI: https://www.radiustheme.com
Description: Roofix Core Plugin for Roofix Theme
Version: 1.5.3
Author: RadiusTheme
Author URI: https://www.radiustheme.com
*/

if ( ! defined( 'ABSPATH' ) ) exit;
	if ( ! defined( 'ROOFIX_CORE' ) ) {

		define( 'ROOFIX_CORE',  ( WP_DEBUG ) ? time() : '1.3' );
		define( 'ROOFIX_CORE_THEME',      'roofix' );
		define( 'ROOFIX_CORE_THEME_VAR',  'roofix' );
		define( 'ROOFIX_CORE_CPT', 		  'roofix' );

		define( 'ROOFIX_CORE_DIR', plugin_dir_path( __FILE__ ) );
		define( 'ROOFIX_CORE_URL', plugin_dir_url( __FILE__ ) );
		define( 'ROOFIX_CORE_ASSETS', trailingslashit( ROOFIX_CORE_URL . 'assets' ) );

	}

class Roofix_Core {
	public $plugin  = 'roofix-core';
	public $action  = 'roofix_theme_init';
	public function __construct() {
		$prefix = ROOFIX_CORE_THEME_VAR;
		add_action( 'plugins_loaded', 		array( $this, 'demo_importer' ), 15 );
		add_action( 'plugins_loaded', 		array( $this, 'load_textdomain' ), 16 );
		add_action( 'after_setup_theme', 	array( $this, 'post_types' ), 15 );
		add_action( $this->action,          array( $this, 'after_theme_loaded' ) );
		// Redux Flash permalink after options changed
		add_action( "redux/options/{$prefix}/saved", 			array( $this, 'flush_redux_saved' ), 10, 2 );
		add_action( "redux/options/{$prefix}/section/reset", 	array( $this, 'flush_redux_reset' ) );
		add_action( "redux/options/{$prefix}/reset", 			array( $this, 'flush_redux_reset' ) );
		add_action( 'init', 									array( $this, 'rewrite_flush_check' ) );
		add_action( 'show_user_profile',        [ $this, 'extra_profile_fields'], 10 );
		add_action( 'edit_user_profile',        [ $this, 'extra_profile_fields'], 10 );
		add_action( 'personal_options_update',  [ $this, 'save_extra_profile_fields' ] );
		add_action( 'edit_user_profile_update', [ $this, 'save_extra_profile_fields' ] );
		add_action( 'bcn_after_fill', 			[ $this, 'rt_hseparator_breadcrumb_trail' ], 1 );

	}

	public function rt_hseparator_breadcrumb_trail($object){
	    $object->opt['hseparator'] = '<span class="dvdr"> - </span>';
	    return $object;
	}
	public function demo_importer() {
		require_once ROOFIX_CORE_DIR . 'inc/demo-importer.php';
	}
	public function load_textdomain() {
		load_plugin_textdomain( $this->plugin , false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	public function after_theme_loaded() {
		require_once ROOFIX_CORE_DIR . 'lib/wp-svg/init.php'; // SVG support
	}
	public function post_types(){
		if ( !did_action( $this->action ) || ! defined( 'RT_FRAMEWORK_VERSION' ) ) {
			return;
		}

		require_once 'post-types.php';
		require_once 'post-meta.php';
		require_once 'widgets/init.php';
		require_once 'sidebar-generator.php';
		require_once 'elementor/init.php';
	}

	// Flush rewrites
	public function flush_redux_saved( $saved_options, $changed_options ){
		if ( empty( $changed_options ) ) {
			return;
		}
		$prefix = ROOFIX_CORE_THEME_VAR;
		$flush  = false;
		if ( $flush ) {
			update_option( "{$prefix}_rewrite_flash", true );
		}
	}

	public function flush_redux_reset(){
		$prefix = ROOFIX_CORE_THEME_VAR;
		update_option( "{$prefix}_rewrite_flash", true );
	}

	public function rewrite_flush_check() {
		$prefix = ROOFIX_CORE_THEME_VAR;
		if ( get_option( "{$prefix}_rewrite_flash" ) == true ) {
			flush_rewrite_rules();
			update_option( "{$prefix}_rewrite_flash", false );
		}
	}
	public function extra_profile_fields( $user ) { ?>
	    <h3><?php esc_html_e( 'Social Profiles', 'roofix-core' );?></h3>
	    <table class="form-table">
	      <?php
	      $socials = [
	        'facebook',
	        'twitter',
	        'linkedin',
	        'instagram',
	        'pinterest',
	        'tumblr',
	        'reddit',
	      ];
	      ?>
	      <?php foreach ($socials as $key): ?>
	        <tr>
	          <th><label for="<?php echo esc_attr( $key ); ?>"><?php esc_html_e( $key, 'roofix-core' );?></label></th>
	          <td>
	            <input type="text" name="<?php echo esc_attr( $key ); ?>" id="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( get_the_author_meta( $key, $user->ID ) ); ?>" class="regular-text" /><br />
	            <span class="description"><?php esc_html_e( "Enter your {$key} profile url.", 'roofix-core' );?></span>
	          </td>
	        </tr>
	      <?php endforeach ?>
	    </table>
	  <?php
	  }
	  public function save_extra_profile_fields( $user_id ) {
	    if ( !current_user_can( 'edit_user', $user_id ) ) {
	      return false;
	    }
	    /* Edit the following lines according to your set fields */
	    update_usermeta( $user_id, 'facebook', $_POST['facebook'] );
	    update_usermeta( $user_id, 'twitter', $_POST['twitter'] );
	    update_usermeta( $user_id, 'linkedin', $_POST['linkedin'] );
	    update_usermeta( $user_id, 'pinterest', $_POST['pinterest'] );
	    update_usermeta( $user_id, 'pinterest', $_POST['pinterest'] );
	    update_usermeta( $user_id, 'tumblr', $_POST['tumblr'] );
	    update_usermeta( $user_id, 'reddit', $_POST['reddit'] );
	  }
	}
new Roofix_Core;
// Plugin Hooks
require_once ROOFIX_CORE_DIR . 'plugin-hooks.php';
require_once ROOFIX_CORE_DIR . 'lib/optimization/__init__.php';

