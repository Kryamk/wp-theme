<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;
use \WP_Widget;
use \RT_Widget_Fields;

class Make_An_Appointment extends WP_Widget {
	public function __construct() {
		$id = 'make_appointment';
		parent::__construct(
            $id, // Base ID
            esc_html__( 'roofix: Make An Appointment', 'roofix-core' ), // Name
            array( 'description' => esc_html__( 'roofix: Make An Appointment', 'roofix-core' )
            	) );
	}
	public function widget( $args, $instance ){
		echo wp_kses_post( $args['before_widget'] );
		?>
		<div class="widget-banner">
		  <div class="banner-img">
		     <?php echo wp_get_attachment_image( $instance['banner'], 'full' );?>
		      <div class="item-content">
		          <div class="big-text"><?php echo esc_attr( $instance['title'] ); ?></div>
		          <div class="sub-text"><?php echo esc_attr( $instance['sub_title'] ); ?></div>
		          <a href="<?php echo esc_url( $instance['url'] ); ?>" class="item-btn"><?php echo esc_attr( $instance['btn_txt'] ); ?></a>
		      </div>
		  </div>
		</div>
		<?php
			echo wp_kses_post( $args['after_widget'] );
		}
	public function update( $new_instance, $old_instance ){
		$instance   									= array();
		$instance['title']         		= ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['sub_title']        = ( ! empty( $new_instance['sub_title'] ) ) ? sanitize_text_field( $new_instance['sub_title'] ) : '';
		$instance['banner']        		= ( ! empty( $new_instance['banner'] ) ) ? sanitize_text_field( $new_instance['banner'] ) : '';
		$instance['url']          		= ( ! empty( $new_instance['url'] ) ) ? sanitize_text_field( $new_instance['url'] ) : '';	
		$instance['btn_txt']     			= ( ! empty( $new_instance['btn_txt'] ) ) ? sanitize_text_field( $new_instance['btn_txt'] ) : '';
	
		return $instance;
	}

	public function form( $instance ){
		$defaults = array(
			'title'         					=> 'Available',
			'sub_title'         				=> 'for any type of Roof construction',
			'banner'          					=> '',
			'url'          						=> '',
			'btn_txt'           				=> 'Make An Appointment',
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		$fields = array(
			'title'       => array(
				'label'     => esc_html__( 'Title', 		'roofix-core' ),
				'type'      => 'text',
			),	
			'sub_title' 	=> array(
				'label'   	=> esc_html__( 'Sub Title', 'roofix-core' ),
				'type'    	=> 'text',
			),
			'banner'        => array(
				'label'   => esc_html__( 'Banner', 'roofix-core' ),
				'type'    => 'image',
			),
			'url'         => array(
				'label'     => esc_html__( 'Button Url', 'roofix-core' ),
				'type'      => 'url',
			),				
			'btn_txt'   	=> array(
				'label'   	=> esc_html__( 'Button Text', 'roofix-core' ),
				'type'    	=> 'text',
			),	
		);
		RT_Widget_Fields::display( $fields, $instance, $this );
	}
}