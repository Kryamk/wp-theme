<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Roofix_Core;

use \RT_Postmeta;
use radiustheme\roofix\Helper;

if (!defined('ABSPATH')) exit;

if (!class_exists('RT_Postmeta')) {
  return;
}
$roofix_Postmeta = RT_Postmeta::getInstance();
$prefix = ROOFIX_CORE_CPT;
$nav_menus = wp_get_nav_menus(array('fields' => 'id=>name'));
$nav_menus = array('default' => esc_html__('Default', 'roofix-core')) + $nav_menus;
$sidebars = array('default' => esc_html__('Default', 'roofix-core')) + Helper::custom_sidebar_fields();

$roofix_Postmeta->add_meta_box('custom_page_title', __('Custom Page Title', 'roofix-core'), array('page', 'post', "{$prefix}_team", "{$prefix}_projects", "{$prefix}_services"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_custom_page_title" => array(
      'label' => __('Title', 'roofix-core'),
      'type'  => 'text',
    ),
  )
));

$roofix_Postmeta->add_meta_box('page_settings', esc_html__('Layout Settings', 'roofix-core'), array('page', 'post', "{$prefix}_team", "{$prefix}_projects", "{$prefix}_services"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_layout"               => array(
      'label'   => esc_html__('Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default'       => esc_html__('Default', 'roofix-core'),
        'full-width'    => esc_html__('Full Width', 'roofix-core'),
        'left-sidebar'  => esc_html__('Left Sidebar', 'roofix-core'),
        'right-sidebar' => esc_html__('Right Sidebar', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_sidebar"              => array(
      'label'   => esc_html__('Custom Sidebar', 'roofix-core'),
      'type'    => 'select',
      'options' => $sidebars,
      'default' => 'default',
    ),
    "{$prefix}_page_menu"            => array(
      'label'   => esc_html__('Main Menu', 'roofix-core'),
      'type'    => 'select',
      'options' => $nav_menus,
      'default' => 'default',
    ),
    "{$prefix}_tr_header"            => array(
      'label'   => esc_html__('Transparent Header', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'on'      => esc_html__('Enabled', 'roofix-core'),
        'off'     => esc_html__('Disabled', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_top_bar"              => array(
      'label'   => __('Top Bar', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => __('Default', 'roofix-core'),
        'on'      => __('Enabled', 'roofix-core'),
        'off'     => __('Disabled', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_top_bar_style"        => array(
      'label'   => esc_html__('Top Bar Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '1'       => esc_html__('Layout 1', 'roofix-core'),
        '2'       => esc_html__('Layout 2', 'roofix-core'),
        '3'       => esc_html__('Layout 3', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_header"               => array(
      'label'   => esc_html__('Header Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '1'       => esc_html__('Layout 1', 'roofix-core'),
        '2'       => esc_html__('Layout 2', 'roofix-core'),
        '3'       => esc_html__('Layout 3', 'roofix-core'),
        '4'       => esc_html__('Layout 4', 'roofix-core'),
        '5'       => esc_html__('Layout 5', 'roofix-core'),

      ),
      'default' => 'default',
    ),
    "{$prefix}_header_opt" => array(
      'label'     => __( 'Header On/Off', 'ranna-core' ),
      'type'      => 'select',
      'options' => array(
        'default' => __( 'Default', 'ranna-core' ),
        'on'      => __( 'Enabled', 'ranna-core' ),
        'off'     => __( 'Disabled', 'ranna-core' ),
      ),
      'default'     => 'default',
    ),
    "{$prefix}_footer"               => array(
      'label'   => esc_html__('Footer Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '1'       => esc_html__('Layout 1', 'roofix-core'),

      ),
      'default' => 'default',
    ),
    "{$prefix}_footer_area" => array(
      'label'     => __( 'Footer Area', 'ranna-core' ),
      'type'      => 'select',
      'options' => array(
        'default' => __( 'Default', 'ranna-core' ),
        'on'      => __( 'Enabled', 'ranna-core' ),
        'off'     => __( 'Disabled', 'ranna-core' ),
      ),
      'default'     => 'default',
    ),
    "{$prefix}_top_padding"          => array(
      'label'   => esc_html__('Content Padding Top', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '0px'     => '0px',
        '10'      => '10px',
        '20'      => '20px',
        '30'      => '30px',
        '40'      => '40px',
        '50'      => '50px',
        '60'      => '60px',
        '70'      => '70px',
        '80'      => '80px',
        '90'      => '90px',
        '100'     => '100px',
      ),
      'default' => 'default',
    ),
    "{$prefix}_bottom_padding"       => array(
      'label'   => esc_html__('Content Padding Bottom', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '0px'     => '0px',
        '10'      => '10px',
        '20'      => '20px',
        '30'      => '30px',
        '40'      => '40px',
        '50'      => '50px',
        '60'      => '60px',
        '70'      => '70px',
        '80'      => '80px',
        '90'      => '90px',
        '100'     => '100px',
      ),
      'default' => 'default',
    ),
    "{$prefix}_banner"               => array(
      'label'   => esc_html__('Banner', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'on'      => esc_html__('Enable', 'roofix-core'),
        'off'     => esc_html__('Disable', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_breadcrumb"           => array(
      'label'   => esc_html__('Breadcrumb', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'on'      => esc_html__('Enable', 'roofix-core'),
        'off'     => esc_html__('Disable', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_banner_type"          => array(
      'label'   => esc_html__('Banner Background Type', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'bgimg'   => esc_html__('Background Image', 'roofix-core'),
        'bgcolor' => esc_html__('Background Color', 'roofix-core'),
      ),
      'default' => 'default',
    ),
    "{$prefix}_banner_bgimg"         => array(
      'label' => esc_html__('Banner Background Image', 'roofix-core'),
      'type'  => 'image',
      'desc'  => esc_html__('If not selected, default will be used', 'roofix-core'),
    ),
    "{$prefix}_banner_bgcolor"       => array(
      'label' => esc_html__('Banner Background Color', 'roofix-core'),
      'type'  => 'color_picker',
      'desc'  => esc_html__('If not selected, default will be used', 'roofix-core'),
    ),
    "{$prefix}_inner_padding_top"    => array(
      'label'   => esc_html__('Banner Padding Top', 'roofix-core'),
      'type'    => 'text',
      'default' => '',
      'desc'    => esc_html__('If not selected, default will be used 120 "px"', 'roofix-core'),
    ),
    "{$prefix}_inner_padding_bottom" => array(
      'label'   => esc_html__('Banner Padding Bottom', 'roofix-core'),
      'type'    => 'text',
      'default' => '',
      'desc'    => esc_html__('If not selected, default will be used 120 "px" ', 'roofix-core'),
    ),
  ),
)
);

$roofix_Postmeta->add_meta_box('member_info', esc_html__('Personal Info', 'roofix-core'), array("{$prefix}_team"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_about_title" => array(
      'label'   => esc_html__('About Me Title', 'roofix-core'),
      'type'    => 'text',
      'default' => 'About Me:',
    ),
    "{$prefix}_designation" => array(
      'label' => esc_html__('Designation', 'roofix-core'),
      'type'  => 'text',
    ),
    "{$prefix}_about"       => array(
      'label'   => esc_html__('About', 'roofix-core'),
      'type'    => 'textarea_html',
      'default' => '',
    ),

    "{$prefix}_phone" => array(
      'label' => esc_html__('Phone', 'roofix-core'),
      'type'  => 'text',
    ),
    "{$prefix}_email" => array(
      'label' => esc_html__('E-mail ', 'roofix-core'),
      'type'  => 'text',
    ),
  )
)
);


$roofix_Postmeta->add_meta_box('team_socials', esc_html__('Team Socials', 'roofix-core'), array("{$prefix}_team"), '', '', 'high', array(
 'fields' => array(
   "{$prefix}_team_socials_header" => array(
     'label' => esc_html__('Socials', 'roofix-core'),
     'type'  => 'header',
     'desc'  => esc_html__('Put your Team links here', 'roofix-core'),
   ),
   "{$prefix}_team_social"         => array(
     'type'  => 'group',
     'value' => Helper::team_socials()
   ),
 )
)
);

// Testimonial //
$roofix_Postmeta->add_meta_box('testimonial_info',
 esc_html__('Testimonial Information', 'roofix-core'), array("{$prefix}_testimonial"), '', '', 'high', array(
   'fields' => array(
     "{$prefix}_testimonial_rating"      => array(
       'label'   => esc_html__('Select the Rating', 'roofix-core'),
       'type'    => 'select',
       'options' => array(
         'default' => esc_html__('Default', 'roofix-core'),
         '0'       => '',
         '1'       => '1',
         '2'       => '2',
         '3'       => '3',
         '4'       => '4',
         '5'       => '5'
       ),
       'default' => 'default',
     ),
     "{$prefix}_testimonial_designation" => array(
       'label'   => esc_html__('Designation', 'roofix-core'),
       'type'    => 'text',
       'default' => '',
     )
   )
 )
);

$roofix_Postmeta->add_meta_box('services_single_layout', esc_html__('Services Layout', 'roofix-core'), array("{$prefix}_services"), '', '', 'high', array(
  'fields' => array(

    "{$prefix}_single_services_arc_style" => array(
      'label'   => esc_html__('Services Single Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'style1'  => esc_html__('Layout 1', 'roofix-core'),
        'style2'  => esc_html__('Layout 2', 'roofix-core'),
        'style3'  => esc_html__('Layout 3', 'roofix-core'),
      ),
      'default' => 'default',
    ),
  )
));


$roofix_Postmeta->add_meta_box('services_info', esc_html__('Services Info', 'roofix-core'), array("{$prefix}_services"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_slider_title" => array(
      'label'   => esc_html__('Slider Sub Title', 'roofix-core'),
      'type'    => 'textarea_html',
      'default' => '',
    ),
    "{$prefix}_sub_title"    => array(
      'label'   => esc_html__('Sub Title', 'roofix-core'),
      'type'    => 'text',
      'default' => '',
    ),
    "{$prefix}_short_detail" => array(
      'label' => esc_html__('Short Detail', 'roofix-core'),
      'type'  => 'textarea_html',
    ),
    "{$prefix}_doc_pdf"      => array(
      'label' => esc_html__('Document .pdf', 'roofix-core'),
      'type'  => 'file',
    ),
    "{$prefix}_doc_Word"     => array(
      'label' => esc_html__('Document .Word', 'roofix-core'),
      'type'  => 'file',
    ),
    "{$prefix}_video_link"   => array(
      'label' => esc_html__('Video link', 'roofix-core'),
      'type'  => 'text',
    ),
  )
));

/*-------------------------------------
#. Services
#. It should be first appeared before
#. general.
---------------------------------------*/

$roofix_Postmeta->add_meta_box(
  "{$prefix}_service_icon", __('Service Icon image', 'roofix-core'),
  array("{$prefix}_services"), '',
  'side',
  'default', array(
    'fields' => array(
      "{$prefix}_service_icon"  => array(
        'label'   => __('Service Icon', 'roofix-core'),
        'type'    => 'icon_select',
        'desc'    => __("Choose a Icon for your service", 'roofix-core'),
        'options' => Helper::get_icons(),
      ),
      "{$prefix}_service_image" => array(
        'label' => __('Service Image', 'roofix-core'),
        'type'  => 'image',
        'desc'  => __("Upload service image in case of icon not selected", 'roofix-core'),
      ),
    )
  ));


$roofix_Postmeta->add_meta_box('services_additional_image', esc_html__('Additional Image', 'roofix-core'), array("{$prefix}_services"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_services_image" => array(
      'type'   => 'repeater',
      'button' => esc_html__('Add New Image', 'roofix-core'),
      'value'  => array(
        "service_additional_img" => array(
          'label'   => esc_html__('Additional Image', 'roofix-core'),
          'type'    => 'image',
          'default' => '',
        ),
      )
    ),
  )
));


$roofix_Postmeta->add_meta_box('project_info', esc_html__('Project Information', 'roofix-core'), array("{$prefix}_projects"), '', '', 'high', array(
  'fields' => array(

    "{$prefix}_short_detail_title" => array(
      'label' => esc_html__('Short Detail Title', 'roofix-core'),
      'type'  => 'textarea_html',
    ),
    "{$prefix}_single_project_arc_style" => array(
      'label'   => esc_html__('Project Content Layout', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        'style1'  => esc_html__('Layout 1', 'roofix-core'),
        'style2'  => esc_html__('Layout 2', 'roofix-core'),
        'style3'  => esc_html__('Layout 3', 'roofix-core'),
      ),
      'default' => 'default',
    ),

    "{$prefix}_short_detail" => array(
      'label' => esc_html__('Short Detail', 'roofix-core'),
      'type'  => 'textarea_html',
    ),
    "{$prefix}_client"       => array(
      'label'   => esc_html__('Client', 'roofix-core'),
      'type'    => 'text',
      'default' => '',
    ),
    "{$prefix}_start_date"   => array(
      'label'   => esc_html__('Start Date', 'roofix-core'),
      'type'    => 'date_picker',
            //'format'  => 'mm/dd/yy',
      'default' => '',
    ),
    "{$prefix}_end_date"     => array(
      'label'   => esc_html__('End Date', 'roofix-core'),
      'type'    => 'date_picker',
            //'format'  => 'mm/dd/yy',
      'default' => '',
    ),
    "{$prefix}_website"      => array(
      'label'   => esc_html__('Website', 'roofix-core'),
      'type'    => 'text',
      'default' => '',
    ),
    "{$prefix}_rating"       => array(
      'label'   => esc_html__('Select the Rating', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        'default' => esc_html__('Default', 'roofix-core'),
        '0'       => '',
        '1'       => '1',
        '2'       => '2',
        '3'       => '3',
        '4'       => '4',
        '5'       => '5'
      ),
      'default' => 'default',
    ),

  )
));


$roofix_Postmeta->add_meta_box('additional_image', esc_html__('Additional Image', 'roofix-core'), array("{$prefix}_projects"), '', '', 'high', array(
  'fields' => array(
    "{$prefix}_additional_image" => array(
      'type'   => 'repeater',
      'button' => esc_html__('Add New Image', 'roofix-core'),
      'value'  => array(
        "additional_img"     => array(
          'label'   => esc_html__('Additional Image', 'roofix-core'),
          'type'    => 'image',
          'default' => '',
        ),
        "title"              => array(
          'label'   => esc_html__('Title', 'roofix-core'),
          'type'    => 'text',
          'default' => '',
        ),
        "title_short_detail" => array(
          'label' => esc_html__('Short Detail', 'roofix-core'),
          'type'  => 'textarea_html',
        ),

      )
    ),
  )
));


$roofix_Postmeta->add_meta_box('additional_isotope', esc_html__('isotope masonry section', 'roofix-core'), array("{$prefix}_projects"), '', '', 'high', array(
  'fields' => array(

    "{$prefix}_col_lg" => array(
      'label'   => esc_html__('Desktops', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        '1'  => esc_html__('1 Col', 'roofix-core'),
        '2'  => esc_html__('2 Col', 'roofix-core'),
        '3'  => esc_html__('3 Col', 'roofix-core'),
        '4'  => esc_html__('4 Col', 'roofix-core'),
        '5'  => esc_html__('5 Col', 'roofix-core'),
        '6'  => esc_html__('6 Col', 'roofix-core'),
        '7'  => esc_html__('7 Col', 'roofix-core'),
        '8'  => esc_html__('8 Col', 'roofix-core'),
        '9'  => esc_html__('9 Col', 'roofix-core'),
        '10' => esc_html__('10 Col', 'roofix-core'),
        '11' => esc_html__('11 Col', 'roofix-core'),
        '12' => esc_html__('12 Col', 'roofix-core'),
      ),
      'default' => '3',
    ),

    "{$prefix}_col_md" => array(
      'label'   => esc_html__('Tablets', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        '1'  => esc_html__('1 Col', 'roofix-core'),
        '2'  => esc_html__('2 Col', 'roofix-core'),
        '3'  => esc_html__('3 Col', 'roofix-core'),
        '4'  => esc_html__('4 Col', 'roofix-core'),
        '5'  => esc_html__('5 Col', 'roofix-core'),
        '6'  => esc_html__('6 Col', 'roofix-core'),
        '7'  => esc_html__('7 Col', 'roofix-core'),
        '8'  => esc_html__('8 Col', 'roofix-core'),
        '9'  => esc_html__('9 Col', 'roofix-core'),
        '10' => esc_html__('10 Col', 'roofix-core'),
        '11' => esc_html__('11 Col', 'roofix-core'),
        '12' => esc_html__('12 Col', 'roofix-core'),
      ),
      'default' => '6',
    ),

    "{$prefix}_col_sm" => array(
      'label'   => esc_html__('Mobile', 'roofix-core'),
      'type'    => 'select',
      'options' => array(
        '1'  => esc_html__('1 Col', 'roofix-core'),
        '2'  => esc_html__('2 Col', 'roofix-core'),
        '3'  => esc_html__('3 Col', 'roofix-core'),
        '4'  => esc_html__('4 Col', 'roofix-core'),
        '5'  => esc_html__('5 Col', 'roofix-core'),
        '6'  => esc_html__('6 Col', 'roofix-core'),
        '7'  => esc_html__('7 Col', 'roofix-core'),
        '8'  => esc_html__('8 Col', 'roofix-core'),
        '9'  => esc_html__('9 Col', 'roofix-core'),
        '10' => esc_html__('10 Col', 'roofix-core'),
        '11' => esc_html__('11 Col', 'roofix-core'),
        '12' => esc_html__('12 Col', 'roofix-core'),
      ),
      'default' => '12',
    ),

  )
));